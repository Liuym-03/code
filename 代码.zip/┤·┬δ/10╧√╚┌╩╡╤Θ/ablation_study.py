"""
消融实验 - 古诗题材分类模型
验证各个模块对模型性能的贡献
"""

import json
import os
import random
from collections import Counter

import numpy as np
import torch
import torch.nn as nn
from torch.backends import cudnn
from torch.utils.data import Dataset, DataLoader
from transformers import BertTokenizer, BertModel
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score, precision_recall_fscore_support
import matplotlib.pyplot as plt
import warnings
warnings.filterwarnings('ignore')

# 设置中文字体
plt.rcParams['font.sans-serif'] = ['SimHei', 'Microsoft YaHei']
plt.rcParams['axes.unicode_minus'] = False

print("="*80)
print("消融实验 - 古诗题材分类模型")
print("="*80)
print()


# 设置随机种子
SEED = 42
os.environ["PYTHONHASHSEED"] = str(SEED)


def set_global_seed(seed: int):
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    torch.cuda.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)
    cudnn.deterministic = True
    cudnn.benchmark = False


def seed_worker(worker_id):
    worker_seed = SEED + worker_id
    np.random.seed(worker_seed)
    random.seed(worker_seed)


set_global_seed(SEED)

# 题材列表
THEMES = ['边塞战争', '山水田园', '交友送别', '羁旅思乡', '爱情婚姻', '咏史怀古']
LABEL_MAP = {theme: idx for idx, theme in enumerate(THEMES)}

# ========== 1. 数据集定义 ==========

class PoetryDataset(Dataset):
    """古诗数据集"""
    def __init__(self, data, tokenizer=None, max_length=128, use_word2vec=False, vocab=None):
        self.data = data
        self.tokenizer = tokenizer
        self.max_length = max_length
        self.use_word2vec = use_word2vec
        self.vocab = vocab or {}
    
    def __len__(self):
        return len(self.data)
    
    def __getitem__(self, idx):
        item = self.data[idx]
        
        # 获取诗词文本
        text = item.get('poem', '').replace('|', '')
        
        # 获取标签
        label = LABEL_MAP.get(item.get('theme', '其他'), 0)
        
        # 获取韵律特征
        rhythm_features = item.get('rhythm_features', {}).get('rhythm_vector', [0.0]*11)
        rhythm_features = np.array(rhythm_features, dtype=np.float32)
        if len(rhythm_features) != 11:
            rhythm_features = np.zeros(11, dtype=np.float32)
        
        if self.use_word2vec:
            tokens = list(text)
            token_ids = [self.vocab.get(token, self.vocab.get('<unk>', 1)) for token in tokens]
            if len(token_ids) > self.max_length:
                token_ids = token_ids[:self.max_length]
            
            padded = np.zeros(self.max_length, dtype=np.int64)
            attention_mask = np.zeros(self.max_length, dtype=np.int64)
            length = min(len(token_ids), self.max_length)
            if length > 0:
                padded[:length] = np.array(token_ids[:length], dtype=np.int64)
                attention_mask[:length] = 1
            
            return {
                'input_ids': torch.tensor(padded, dtype=torch.long),
                'attention_mask': torch.tensor(attention_mask, dtype=torch.long),
                'rhythm_features': torch.tensor(rhythm_features, dtype=torch.float32),
                'label': torch.tensor(label, dtype=torch.long),
                'text': text
            }
        else:
            # BERT编码
            encoding = self.tokenizer(
                text,
                max_length=self.max_length,
                padding='max_length',
                truncation=True,
                return_tensors='pt'
            )
            
            return {
                'input_ids': encoding['input_ids'].squeeze(0),
                'attention_mask': encoding['attention_mask'].squeeze(0),
                'rhythm_features': torch.tensor(rhythm_features, dtype=torch.float32),
                'label': torch.tensor(label, dtype=torch.long),
                'text': text
            }


def build_char_vocab(dataset, min_freq=1):
    counter = Counter()
    for item in dataset:
        text = item.get('poem', '').replace('|', '')
        if text:
            counter.update(list(text))
    vocab = {'<pad>': 0, '<unk>': 1}
    for char, freq in counter.items():
        if freq >= min_freq and char not in vocab:
            vocab[char] = len(vocab)
    return vocab


# ========== 2. Word2Vec特征提取器（用于消融实验） ==========

class SimpleWord2VecEncoder(nn.Module):
    """简单的Word2Vec编码器（替代BERT）"""
    def __init__(self, vocab_size=50000, embed_dim=256):
        super().__init__()
        self.embedding = nn.Embedding(vocab_size, embed_dim, padding_idx=0)
        self.embed_dim = embed_dim
    
    def forward(self, input_ids, attention_mask=None):
        embedded = self.embedding(input_ids)  # (batch, seq_len, embed_dim)
        if attention_mask is not None:
            mask = attention_mask.unsqueeze(-1).type_as(embedded)
            embedded = embedded * mask
        return embedded


# ========== 3. 模型定义 ==========

class CompleteModel(nn.Module):
    """
    变体1：完整模型
    BERT + 韵律特征 + M-BiLSTM + 多头注意力 + 特征融合交互
    """
    def __init__(self, bert_model, num_classes=6, rhythm_dim=11, 
                 lstm_hidden=256, num_heads=8, dropout=0.3):
        super().__init__()
        self.bert = bert_model
        # 确保BERT参数可训练
        for param in self.bert.parameters():
            param.requires_grad = True
        self.bert_hidden = 768
        
        # M-BiLSTM (长链接机制)
        self.lstm1 = nn.LSTM(self.bert_hidden, lstm_hidden, batch_first=True, bidirectional=True)
        self.lstm2 = nn.LSTM(lstm_hidden * 2, lstm_hidden, batch_first=True, bidirectional=True)
        
        # 多头注意力
        self.multihead_attn = nn.MultiheadAttention(
            embed_dim=lstm_hidden * 2,
            num_heads=num_heads,
            dropout=dropout,
            batch_first=True
        )
        
        # 特征融合交互（加权融合 + 门控机制）
        self.rhythm_proj = nn.Linear(rhythm_dim, 128)
        self.gate = nn.Sequential(
            nn.Linear(lstm_hidden * 2 + 128, 256),
            nn.Sigmoid()
        )
        self.fusion = nn.Sequential(
            nn.Linear(lstm_hidden * 2 + 128, 512),
            nn.ReLU(),
            nn.Dropout(dropout),
            nn.Linear(512, 256)
        )
        
        # 分类器
        self.classifier = nn.Sequential(
            nn.Linear(256, 128),
            nn.ReLU(),
            nn.Dropout(dropout),
            nn.Linear(128, num_classes)
        )
    
    def forward(self, input_ids, attention_mask, rhythm_features):
        # BERT编码
        bert_output = self.bert(input_ids=input_ids, attention_mask=attention_mask)
        sequence_output = bert_output.last_hidden_state  # (batch, seq_len, 768)
        
        # M-BiLSTM (长链接)
        lstm1_out, _ = self.lstm1(sequence_output)  # (batch, seq_len, 512)
        lstm2_out, _ = self.lstm2(lstm1_out)  # (batch, seq_len, 512)
        
        # 多头注意力
        attn_out, _ = self.multihead_attn(lstm2_out, lstm2_out, lstm2_out)
        
        # 池化
        context_vector = torch.mean(attn_out, dim=1)  # (batch, 512)
        
        # 韵律特征投影
        rhythm_repr = self.rhythm_proj(rhythm_features)  # (batch, 128)
        
        # 特征融合交互（门控机制）
        combined = torch.cat([context_vector, rhythm_repr], dim=-1)  # (batch, 640)
        gate_weight = self.gate(combined)  # (batch, 256)
        fused = self.fusion(combined)  # (batch, 256)
        gated_features = fused * gate_weight  # (batch, 256)
        
        # 分类
        logits = self.classifier(gated_features)
        return logits


class AblationModel_NoMultiheadAttn(nn.Module):
    """
    变体3：移除多头注意力
    直接跳过多头注意力层
    """
    def __init__(self, bert_model, num_classes=6, rhythm_dim=11, 
                 lstm_hidden=256, dropout=0.3):
        super().__init__()
        self.bert = bert_model
        for param in self.bert.parameters():
            param.requires_grad = True
        self.bert_hidden = 768
        
        # M-BiLSTM
        self.lstm1 = nn.LSTM(self.bert_hidden, lstm_hidden, batch_first=True, bidirectional=True)
        self.lstm2 = nn.LSTM(lstm_hidden * 2, lstm_hidden, batch_first=True, bidirectional=True)
        
        # 特征融合交互
        self.rhythm_proj = nn.Linear(rhythm_dim, 128)
        self.gate = nn.Sequential(
            nn.Linear(lstm_hidden * 2 + 128, 256),
            nn.Sigmoid()
        )
        self.fusion = nn.Sequential(
            nn.Linear(lstm_hidden * 2 + 128, 512),
            nn.ReLU(),
            nn.Dropout(dropout),
            nn.Linear(512, 256)
        )
        
        # 分类器
        self.classifier = nn.Sequential(
            nn.Linear(256, 128),
            nn.ReLU(),
            nn.Dropout(dropout),
            nn.Linear(128, num_classes)
        )
    
    def forward(self, input_ids, attention_mask, rhythm_features):
        # BERT编码
        bert_output = self.bert(input_ids=input_ids, attention_mask=attention_mask)
        sequence_output = bert_output.last_hidden_state
        
        # M-BiLSTM
        lstm1_out, _ = self.lstm1(sequence_output)
        lstm2_out, _ = self.lstm2(lstm1_out)
        
        # 直接池化（跳过注意力）
        context_vector = torch.mean(lstm2_out, dim=1)
        
        # 韵律特征
        rhythm_repr = self.rhythm_proj(rhythm_features)
        
        # 特征融合
        combined = torch.cat([context_vector, rhythm_repr], dim=-1)
        gate_weight = self.gate(combined)
        fused = self.fusion(combined)
        gated_features = fused * gate_weight
        
        # 分类
        logits = self.classifier(gated_features)
        return logits


class AblationModel_NoMBiLSTM(nn.Module):
    """
    变体4：移除M-BiLSTM（长链接机制）
    替换为普通单层BiLSTM
    """
    def __init__(self, bert_model, num_classes=6, rhythm_dim=11, 
                 lstm_hidden=256, num_heads=8, dropout=0.3):
        super().__init__()
        self.bert = bert_model
        for param in self.bert.parameters():
            param.requires_grad = True
        self.bert_hidden = 768
        
        # 单层BiLSTM（替代M-BiLSTM）
        self.lstm = nn.LSTM(self.bert_hidden, lstm_hidden, batch_first=True, bidirectional=True)
        
        # 多头注意力
        self.multihead_attn = nn.MultiheadAttention(
            embed_dim=lstm_hidden * 2,
            num_heads=num_heads,
            dropout=dropout,
            batch_first=True
        )
        
        # 特征融合交互
        self.rhythm_proj = nn.Linear(rhythm_dim, 128)
        self.gate = nn.Sequential(
            nn.Linear(lstm_hidden * 2 + 128, 256),
            nn.Sigmoid()
        )
        self.fusion = nn.Sequential(
            nn.Linear(lstm_hidden * 2 + 128, 512),
            nn.ReLU(),
            nn.Dropout(dropout),
            nn.Linear(512, 256)
        )
        
        # 分类器
        self.classifier = nn.Sequential(
            nn.Linear(256, 128),
            nn.ReLU(),
            nn.Dropout(dropout),
            nn.Linear(128, num_classes)
        )
    
    def forward(self, input_ids, attention_mask, rhythm_features):
        # BERT编码
        bert_output = self.bert(input_ids=input_ids, attention_mask=attention_mask)
        sequence_output = bert_output.last_hidden_state
        
        # 单层BiLSTM
        lstm_out, _ = self.lstm(sequence_output)
        
        # 多头注意力
        attn_out, _ = self.multihead_attn(lstm_out, lstm_out, lstm_out)
        
        # 池化
        context_vector = torch.mean(attn_out, dim=1)
        
        # 韵律特征
        rhythm_repr = self.rhythm_proj(rhythm_features)
        
        # 特征融合
        combined = torch.cat([context_vector, rhythm_repr], dim=-1)
        gate_weight = self.gate(combined)
        fused = self.fusion(combined)
        gated_features = fused * gate_weight
        
        # 分类
        logits = self.classifier(gated_features)
        return logits


class AblationModel_NoFusionInteraction(nn.Module):
    """
    变体5：移除特征融合交互
    用简单特征拼接替代加权融合和门控机制
    """
    def __init__(self, bert_model, num_classes=6, rhythm_dim=11, 
                 lstm_hidden=256, num_heads=8, dropout=0.3):
        super().__init__()
        self.bert = bert_model
        for param in self.bert.parameters():
            param.requires_grad = True
        self.bert_hidden = 768
        
        # M-BiLSTM
        self.lstm1 = nn.LSTM(self.bert_hidden, lstm_hidden, batch_first=True, bidirectional=True)
        self.lstm2 = nn.LSTM(lstm_hidden * 2, lstm_hidden, batch_first=True, bidirectional=True)
        
        # 多头注意力
        self.multihead_attn = nn.MultiheadAttention(
            embed_dim=lstm_hidden * 2,
            num_heads=num_heads,
            dropout=dropout,
            batch_first=True
        )
        
        # 简单拼接（替代门控融合）
        self.simple_fusion = nn.Sequential(
            nn.Linear(lstm_hidden * 2 + rhythm_dim, 256),
            nn.ReLU(),
            nn.Dropout(dropout)
        )
        
        # 分类器
        self.classifier = nn.Sequential(
            nn.Linear(256, 128),
            nn.ReLU(),
            nn.Dropout(dropout),
            nn.Linear(128, num_classes)
        )
    
    def forward(self, input_ids, attention_mask, rhythm_features):
        # BERT编码
        bert_output = self.bert(input_ids=input_ids, attention_mask=attention_mask)
        sequence_output = bert_output.last_hidden_state
        
        # M-BiLSTM
        lstm1_out, _ = self.lstm1(sequence_output)
        lstm2_out, _ = self.lstm2(lstm1_out)
        
        # 多头注意力
        attn_out, _ = self.multihead_attn(lstm2_out, lstm2_out, lstm2_out)
        
        # 池化
        context_vector = torch.mean(attn_out, dim=1)
        
        # 简单拼接（无门控）
        combined = torch.cat([context_vector, rhythm_features], dim=-1)
        fused = self.simple_fusion(combined)
        
        # 分类
        logits = self.classifier(fused)
        return logits


class AblationModel_Word2Vec(nn.Module):
    """
    变体2：移除BERT
    使用Word2Vec+RNN替代BERT预训练模型
    """
    def __init__(self, vocab_size=50000, embed_dim=256, num_classes=6, rhythm_dim=11, 
                 lstm_hidden=256, num_heads=8, dropout=0.3):
        super().__init__()
        
        # Word2Vec编码器（替代BERT）
        self.word2vec_encoder = SimpleWord2VecEncoder(vocab_size, embed_dim)
        
        # M-BiLSTM
        self.lstm1 = nn.LSTM(embed_dim, lstm_hidden, batch_first=True, bidirectional=True)
        self.lstm2 = nn.LSTM(lstm_hidden * 2, lstm_hidden, batch_first=True, bidirectional=True)
        
        # 多头注意力
        self.multihead_attn = nn.MultiheadAttention(
            embed_dim=lstm_hidden * 2,
            num_heads=num_heads,
            dropout=dropout,
            batch_first=True
        )
        
        # 特征融合交互
        self.rhythm_proj = nn.Linear(rhythm_dim, 128)
        self.gate = nn.Sequential(
            nn.Linear(lstm_hidden * 2 + 128, 256),
            nn.Sigmoid()
        )
        self.fusion = nn.Sequential(
            nn.Linear(lstm_hidden * 2 + 128, 512),
            nn.ReLU(),
            nn.Dropout(dropout),
            nn.Linear(512, 256)
        )
        
        # 分类器
        self.classifier = nn.Sequential(
            nn.Linear(256, 128),
            nn.ReLU(),
            nn.Dropout(dropout),
            nn.Linear(128, num_classes)
        )
    
    def forward(self, input_ids, attention_mask, rhythm_features):
        # Word2Vec编码
        sequence_output = self.word2vec_encoder(input_ids, attention_mask)  # (batch, seq_len, embed_dim)
        
        # M-BiLSTM
        lstm1_out, _ = self.lstm1(sequence_output)
        lstm2_out, _ = self.lstm2(lstm1_out)
        
        # 多头注意力
        attn_out, _ = self.multihead_attn(lstm2_out, lstm2_out, lstm2_out)
        
        # 池化
        context_vector = torch.mean(attn_out, dim=1)
        
        # 韵律特征
        rhythm_repr = self.rhythm_proj(rhythm_features)
        
        # 特征融合
        combined = torch.cat([context_vector, rhythm_repr], dim=-1)
        gate_weight = self.gate(combined)
        fused = self.fusion(combined)
        gated_features = fused * gate_weight
        
        # 分类
        logits = self.classifier(gated_features)
        return logits


# ========== 4. 训练函数 ==========

def train_epoch(model, data_loader, criterion, optimizer, device):
    """训练一个epoch"""
    model.train()
    total_loss = 0
    all_preds = []
    all_labels = []
    
    for batch in data_loader:
        input_ids = batch['input_ids'].to(device)
        attention_mask = batch['attention_mask'].to(device)
        rhythm_features = batch['rhythm_features'].to(device)
        labels = batch['label'].to(device)
        
        # 前向传播
        outputs = model(input_ids, attention_mask, rhythm_features)
        loss = criterion(outputs, labels)
        
        # 反向传播
        optimizer.zero_grad()
        loss.backward()
        torch.nn.utils.clip_grad_norm_(model.parameters(), max_norm=1.0)
        optimizer.step()
        
        # 统计
        total_loss += loss.item()
        preds = torch.argmax(outputs, dim=1).cpu().numpy()
        all_preds.extend(preds)
        all_labels.extend(labels.cpu().numpy())
    
    avg_loss = total_loss / len(data_loader)
    accuracy = accuracy_score(all_labels, all_preds)
    
    return avg_loss, accuracy


def evaluate(model, data_loader, criterion, device):
    """评估模型"""
    model.eval()
    total_loss = 0
    all_preds = []
    all_labels = []
    
    with torch.no_grad():
        for batch in data_loader:
            input_ids = batch['input_ids'].to(device)
            attention_mask = batch['attention_mask'].to(device)
            rhythm_features = batch['rhythm_features'].to(device)
            labels = batch['label'].to(device)
            
            # 前向传播
            outputs = model(input_ids, attention_mask, rhythm_features)
            loss = criterion(outputs, labels)
            
            # 统计
            total_loss += loss.item()
            preds = torch.argmax(outputs, dim=1).cpu().numpy()
            all_preds.extend(preds)
            all_labels.extend(labels.cpu().numpy())
    
    avg_loss = total_loss / len(data_loader)
    accuracy = accuracy_score(all_labels, all_preds)
    precision, recall, f1, _ = precision_recall_fscore_support(
        all_labels, all_preds, average='macro', zero_division=0
    )
    
    return avg_loss, accuracy, precision, recall, f1, all_preds, all_labels


# ========== 5. 主函数 ==========

def main():
    # 设置设备
    device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
    print(f"使用设备: {device}")
    print()
    
    # 1. 加载数据
    print("1. 加载数据...")
    with open('总文件/poems_preprocessed.json', 'r', encoding='utf-8') as f:
        all_data = json.load(f)
    
    # 筛选有效数据
    valid_data = [item for item in all_data if item.get('theme') in THEMES]
    print(f"   总样本数: {len(all_data)}")
    print(f"   有效样本数: {len(valid_data)}")
    
    # 统计各类别数量
    print("\n   各类别样本分布:")
    for theme in THEMES:
        count = sum(1 for item in valid_data if item.get('theme') == theme)
        print(f"     {theme}: {count}")
    
    # 划分数据集 (80% train, 10% val, 10% test)
    train_data, temp_data = train_test_split(valid_data, test_size=0.2, random_state=SEED, stratify=[item['theme'] for item in valid_data])
    val_data, test_data = train_test_split(temp_data, test_size=0.5, random_state=SEED, stratify=[item['theme'] for item in temp_data])
    
    print(f"\n   训练集: {len(train_data)}")
    print(f"   验证集: {len(val_data)}")
    print(f"   测试集: {len(test_data)}")
    print()
    
    # 2. 初始化tokenizer和BERT
    print("2. 初始化BERT模型...")
    tokenizer = BertTokenizer.from_pretrained('bert-base-chinese')
    bert_model = BertModel.from_pretrained('bert-base-chinese')
    print("   BERT模型加载完成")
    print()
    
    # 3. 创建数据集和加载器
    print("3. 创建数据集...")
    batch_size = 32
    max_length = 128
    
    bert_train_dataset = PoetryDataset(train_data, tokenizer, max_length=max_length)
    bert_val_dataset = PoetryDataset(val_data, tokenizer, max_length=max_length)
    bert_test_dataset = PoetryDataset(test_data, tokenizer, max_length=max_length)
    
    # Word2Vec 数据集
    word2vec_vocab = build_char_vocab(train_data)
    vocab_size = len(word2vec_vocab)
    print(f"   Word2Vec字符词表大小: {vocab_size}")
    
    w2v_train_dataset = PoetryDataset(train_data, tokenizer=None, max_length=max_length, use_word2vec=True, vocab=word2vec_vocab)
    w2v_val_dataset = PoetryDataset(val_data, tokenizer=None, max_length=max_length, use_word2vec=True, vocab=word2vec_vocab)
    w2v_test_dataset = PoetryDataset(test_data, tokenizer=None, max_length=max_length, use_word2vec=True, vocab=word2vec_vocab)
    
    del bert_model
    
    def create_dataloaders(train_dataset, val_dataset, test_dataset, seed):
        generator = torch.Generator()
        generator.manual_seed(seed)
        train_loader = DataLoader(
            train_dataset,
            batch_size=batch_size,
            shuffle=True,
            num_workers=0,
            worker_init_fn=seed_worker,
            generator=generator
        )
        val_loader = DataLoader(
            val_dataset,
            batch_size=batch_size,
            shuffle=False,
            num_workers=0,
            worker_init_fn=seed_worker
        )
        test_loader = DataLoader(
            test_dataset,
            batch_size=batch_size,
            shuffle=False,
            num_workers=0,
            worker_init_fn=seed_worker
        )
        return train_loader, val_loader, test_loader
    
    print(f"   批次大小: {batch_size}")
    print()
    
    # 4. 定义消融实验的5个变体
    print("4. 定义消融实验变体...")
    variants = [
        {
            'name': '完整模型',
            'description': 'BERT + 韵律 + M-BiLSTM + 多头注意力 + 门控融合'
        },
        {
            'name': '移除BERT',
            'description': 'Word2Vec + 韵律 + M-BiLSTM + 多头注意力 + 门控融合'
        },
        {
            'name': '移除多头注意力',
            'description': 'BERT + 韵律 + M-BiLSTM + 门控融合'
        },
        {
            'name': '移除M-BiLSTM',
            'description': 'BERT + 韵律 + 单层BiLSTM + 多头注意力 + 门控融合'
        },
        {
            'name': '移除特征融合交互',
            'description': 'BERT + 韵律 + M-BiLSTM + 多头注意力 + 简单拼接'
        }
    ]
    
    for i, variant in enumerate(variants):
        print(f"   变体{i+1}: {variant['name']}")
        print(f"      {variant['description']}")
    print()
    
    # 5. 训练和评估每个变体（运行3次取平均）
    print("5. 开始消融实验（每个变体运行3次）...")
    print("="*80)
    print()
    
    results = {
        'variants': [],
        'accuracies': [],
        'precisions': [],
        'recalls': [],
        'f1s': []
    }
    
    num_runs = int(os.getenv('ABLATION_NUM_RUNS', 3))
    num_epochs = int(os.getenv('ABLATION_NUM_EPOCHS', 10))
    print(f"   配置: 每个变体运行 {num_runs} 次, 每次 {num_epochs} 个 epoch")
    
    for variant_idx, variant in enumerate(variants):
        print(f"\n{'='*80}")
        print(f"变体 {variant_idx+1}/{len(variants)}: {variant['name']}")
        print(f"{'='*80}")
        
        run_accuracies = []
        run_precisions = []
        run_recalls = []
        run_f1s = []
        
        for run in range(num_runs):
            print(f"\n第 {run+1}/{num_runs} 次运行:")
            print("-"*80)
            
            set_global_seed(SEED + run + variant_idx * 10)
            
            # 重新初始化模型
            dataloader_seed = SEED + run + variant_idx * 100
            
            if variant['name'] == '移除BERT':
                train_loader, val_loader, test_loader = create_dataloaders(
                    w2v_train_dataset,
                    w2v_val_dataset,
                    w2v_test_dataset,
                    dataloader_seed
                )
                model = AblationModel_Word2Vec(
                    vocab_size=vocab_size,
                    embed_dim=256,
                    num_classes=6
                ).to(device)
            elif variant['name'] == '完整模型':
                bert_temp = BertModel.from_pretrained('bert-base-chinese')
                model = CompleteModel(bert_temp, num_classes=6).to(device)
                train_loader, val_loader, test_loader = create_dataloaders(
                    bert_train_dataset,
                    bert_val_dataset,
                    bert_test_dataset,
                    dataloader_seed
                )
            elif variant['name'] == '移除多头注意力':
                bert_temp = BertModel.from_pretrained('bert-base-chinese')
                model = AblationModel_NoMultiheadAttn(bert_temp, num_classes=6).to(device)
                train_loader, val_loader, test_loader = create_dataloaders(
                    bert_train_dataset,
                    bert_val_dataset,
                    bert_test_dataset,
                    dataloader_seed
                )
            elif variant['name'] == '移除M-BiLSTM':
                bert_temp = BertModel.from_pretrained('bert-base-chinese')
                model = AblationModel_NoMBiLSTM(bert_temp, num_classes=6).to(device)
                train_loader, val_loader, test_loader = create_dataloaders(
                    bert_train_dataset,
                    bert_val_dataset,
                    bert_test_dataset,
                    dataloader_seed
                )
            else:  # 移除特征融合交互
                bert_temp = BertModel.from_pretrained('bert-base-chinese')
                model = AblationModel_NoFusionInteraction(bert_temp, num_classes=6).to(device)
                train_loader, val_loader, test_loader = create_dataloaders(
                    bert_train_dataset,
                    bert_val_dataset,
                    bert_test_dataset,
                    dataloader_seed
                )
            
            # 使用标准交叉熵损失（暂时移除类别权重，等基础训练稳定后再添加）
            criterion = nn.CrossEntropyLoss()
            
            if variant['name'] == '移除BERT':
                optimizer = torch.optim.AdamW(
                    model.parameters(),
                    lr=1e-3,
                    weight_decay=0.01
                )
            else:
                bert_parameters = []
                other_parameters = []
                for name, param in model.named_parameters():
                    if not param.requires_grad:
                        continue
                    if 'bert' in name:
                        bert_parameters.append(param)
                    else:
                        other_parameters.append(param)
                optimizer = torch.optim.AdamW(
                    [
                        {'params': bert_parameters, 'lr': 2e-5, 'weight_decay': 0.01},
                        {'params': other_parameters, 'lr': 5e-4, 'weight_decay': 0.01}
                    ]
                )
            
            # 暂时移除学习率调度器，使用固定学习率确保稳定训练
            # from torch.optim.lr_scheduler import CosineAnnealingLR
            # scheduler = CosineAnnealingLR(optimizer, T_max=num_epochs, eta_min=1e-6)
            
            # 训练
            best_val_acc = float('-inf')
            best_model_state = None
            
            for epoch in range(num_epochs):
                train_loss, train_acc = train_epoch(model, train_loader, criterion, optimizer, device)
                val_loss, val_acc, _, _, _, _, _ = evaluate(model, val_loader, criterion, device)
                
                print(f"  Epoch {epoch+1}/{num_epochs}: "
                      f"Train Loss={train_loss:.4f}, Train Acc={train_acc:.4f}, "
                      f"Val Loss={val_loss:.4f}, Val Acc={val_acc:.4f}")
                
                # 保存最佳模型
                if val_acc > best_val_acc:
                    best_val_acc = val_acc
                    best_model_state = {k: v.detach().cpu().clone() for k, v in model.state_dict().items()}
            
            # 加载最佳模型并在测试集上评估
            if best_model_state is None:
                best_model_state = {k: v.detach().cpu().clone() for k, v in model.state_dict().items()}
            model.load_state_dict(best_model_state)
            test_loss, test_acc, test_prec, test_rec, test_f1, preds, labels = evaluate(
                model, test_loader, criterion, device
            )
            
            print(f"\n  测试集结果:")
            print(f"    准确率: {test_acc:.4f}")
            print(f"    精确率: {test_prec:.4f}")
            print(f"    召回率: {test_rec:.4f}")
            print(f"    F1分数: {test_f1:.4f}")
            
            run_accuracies.append(test_acc * 100)
            run_precisions.append(test_prec * 100)
            run_recalls.append(test_rec * 100)
            run_f1s.append(test_f1 * 100)
        
        # 计算3次运行的平均值
        avg_acc = np.mean(run_accuracies)
        avg_prec = np.mean(run_precisions)
        avg_rec = np.mean(run_recalls)
        avg_f1 = np.mean(run_f1s)
        
        print(f"\n{variant['name']} - 3次运行平均结果:")
        print(f"  准确率: {avg_acc:.2f}%")
        print(f"  精确率: {avg_prec:.2f}%")
        print(f"  召回率: {avg_rec:.2f}%")
        print(f"  F1分数: {avg_f1:.2f}%")
        
        results['variants'].append(variant['name'])
        results['accuracies'].append(avg_acc)
        results['precisions'].append(avg_prec)
        results['recalls'].append(avg_rec)
        results['f1s'].append(avg_f1)
    
    # 6. 保存结果
    print("\n\n" + "="*80)
    print("消融实验完成！")
    print("="*80)
    print()
    
    # 打印结果表格
    print("实验结果汇总表:")
    print("-"*100)
    print(f"{'变体':<20} {'准确率':<12} {'精确率':<12} {'召回率':<12} {'F1分数':<12}")
    print("-"*100)
    for i in range(len(results['variants'])):
        print(f"{results['variants'][i]:<20} "
              f"{results['accuracies'][i]:>10.2f}%  "
              f"{results['precisions'][i]:>10.2f}%  "
              f"{results['recalls'][i]:>10.2f}%  "
              f"{results['f1s'][i]:>10.2f}%")
    print("-"*100)
    print()
    
    # 保存为JSON
    with open('ablation_results.json', 'w', encoding='utf-8') as f:
        json.dump(results, f, ensure_ascii=False, indent=2)
    print("结果已保存到: ablation_results.json")
    
    # 7. 生成可视化图表
    print("\n7. 生成可视化图表...")
    plot_ablation_results(results)
    print()
    print("="*80)
    print("消融实验全部完成！")
    print("="*80)


def plot_ablation_results(results):
    """
    绘制消融实验结果图表
    1. 横向柱状图
    2. 结果表格
    """
    variants = results['variants']
    accuracies = results['accuracies']
    precisions = results['precisions']
    recalls = results['recalls']
    f1s = results['f1s']
    
    # 设置颜色
    colors = ['#4CAF50', '#FFA726', '#42A5F5', '#AB47BC', '#EF5350']
    
    # 创建图形
    fig, (ax1, ax2) = plt.subplots(2, 1, figsize=(14, 12))
    
    # ========== 图1: 横向柱状图 ==========
    y_pos = np.arange(len(variants))
    bar_height = 0.2
    
    # 绘制4个指标的柱状图
    ax1.barh(y_pos - 1.5*bar_height, f1s, bar_height, label='F1', color='#4CAF50', alpha=0.9)
    ax1.barh(y_pos - 0.5*bar_height, recalls, bar_height, label='召回率', color='#FFA726', alpha=0.9)
    ax1.barh(y_pos + 0.5*bar_height, precisions, bar_height, label='精确率', color='#42A5F5', alpha=0.9)
    ax1.barh(y_pos + 1.5*bar_height, accuracies, bar_height, label='准确率', color='#AB47BC', alpha=0.9)
    
    # 设置标签和标题
    ax1.set_yticks(y_pos)
    ax1.set_yticklabels(variants, fontsize=11)
    ax1.set_xlabel('性能指标 (%)', fontsize=12, fontweight='bold')
    ax1.set_title('消融实验结果', fontsize=16, fontweight='bold', pad=20)
    ax1.legend(loc='lower right', fontsize=10)
    min_score = min(min(accuracies), min(precisions), min(recalls), min(f1s))
    max_score = max(max(accuracies), max(precisions), max(recalls), max(f1s))
    margin = max(2.0, (max_score - min_score) * 0.1)
    lower_bound = max(0.0, min_score - margin)
    upper_bound = min(100.0, max_score + margin)
    if lower_bound >= upper_bound:
        lower_bound = 0.0
        upper_bound = 100.0
    ax1.set_xlim(lower_bound, upper_bound)
    ax1.grid(axis='x', linestyle='--', alpha=0.3)
    
    # 在柱状图上添加数值标签
    for i, (acc, prec, rec, f1) in enumerate(zip(accuracies, precisions, recalls, f1s)):
        ax1.text(acc + 0.2, i + 1.5*bar_height, f'{acc:.2f}', va='center', fontsize=8)
        ax1.text(prec + 0.2, i + 0.5*bar_height, f'{prec:.2f}', va='center', fontsize=8)
        ax1.text(rec + 0.2, i - 0.5*bar_height, f'{rec:.2f}', va='center', fontsize=8)
        ax1.text(f1 + 0.2, i - 1.5*bar_height, f'{f1:.2f}', va='center', fontsize=8)
    
    # ========== 图2: 结果表格 ==========
    ax2.axis('tight')
    ax2.axis('off')
    
    # 准备表格数据
    table_data = [['模型变体', '准确率', '精确率', '召回率', 'F1分数']]
    for i in range(len(variants)):
        table_data.append([
            variants[i],
            f'{accuracies[i]:.2f}',
            f'{precisions[i]:.2f}',
            f'{recalls[i]:.2f}',
            f'{f1s[i]:.2f}'
        ])
    
    # 创建表格
    table = ax2.table(
        cellText=table_data,
        cellLoc='center',
        loc='center',
        bbox=[0, 0, 1, 1]
    )
    
    table.auto_set_font_size(False)
    table.set_fontsize(11)
    table.scale(1, 2.5)
    
    # 设置表头样式
    for i in range(5):
        cell = table[(0, i)]
        cell.set_facecolor('#4A90E2')
        cell.set_text_props(weight='bold', color='white', fontsize=12)
    
    # 设置数据行样式
    for i in range(1, 6):
        for j in range(5):
            cell = table[(i, j)]
            if i % 2 == 0:
                cell.set_facecolor('#F5F5F5')
            else:
                cell.set_facecolor('white')
            
            # 第一列（模型名称）加粗
            if j == 0:
                cell.set_text_props(weight='bold', fontsize=11)
    
    # 高亮最佳结果
    max_acc_idx = accuracies.index(max(accuracies))
    max_prec_idx = precisions.index(max(precisions))
    max_rec_idx = recalls.index(max(recalls))
    max_f1_idx = f1s.index(max(f1s))
    
    table[(max_acc_idx + 1, 1)].set_facecolor('#C8E6C9')
    table[(max_prec_idx + 1, 2)].set_facecolor('#C8E6C9')
    table[(max_rec_idx + 1, 3)].set_facecolor('#C8E6C9')
    table[(max_f1_idx + 1, 4)].set_facecolor('#C8E6C9')
    
    ax2.set_title('消融实验结果汇总表', fontsize=14, fontweight='bold', pad=30)
    
    # 保存图表
    plt.tight_layout()
    plt.savefig('ablation_study_results.png', dpi=300, bbox_inches='tight', facecolor='white')
    plt.savefig('ablation_study_results.pdf', bbox_inches='tight', facecolor='white')
    
    print("  可视化图表已保存:")
    print("    - ablation_study_results.png")
    print("    - ablation_study_results.pdf")


if __name__ == '__main__':
    main()



