"""
实验2扩展：跨朝代迁移学习实验
测试模型在不同朝代间的泛化能力

实验设计：
1. 唐诗训练 → 宋诗测试
2. 宋诗训练 → 唐诗测试
3. 与完整训练模型对比
"""

import json
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
from collections import Counter
import os

# 设置中文字体
plt.rcParams['font.sans-serif'] = ['SimHei']
plt.rcParams['axes.unicode_minus'] = False

# 创建输出目录
output_dir = 'dynasty_transfer_results'
os.makedirs(output_dir, exist_ok=True)

print("=" * 80)
print("实验2扩展：跨朝代迁移学习实验")
print("=" * 80)

# ==================== 1. 加载数据和预测结果 ====================
print("\n[步骤1] 加载数据...")

# 注意：这里使用模拟数据演示
# 实际实验需要：
# 1. 用唐诗训练数据训练模型 → 在宋诗测试集上评估
# 2. 用宋诗训练数据训练模型 → 在唐诗测试集上评估
# 3. 用全部数据训练模型（基线）→ 在唐诗和宋诗测试集上分别评估

# 模拟实验结果数据
np.random.seed(42)

themes = ['边塞战争', '山水田园', '交友送别', '羁旅思乡', '爱情婚姻', '咏史怀古']

# 模拟不同训练场景的性能
# 格式：{场景: {朝代: 准确率}}
transfer_results = {
    '完整训练': {
        '唐诗测试': 90.5 + np.random.randn() * 0.5,
        '宋诗测试': 91.2 + np.random.randn() * 0.5
    },
    '唐诗训练': {
        '唐诗测试': 89.8 + np.random.randn() * 0.5,  # 同域测试
        '宋诗测试': 82.3 + np.random.randn() * 0.5   # 跨域测试（性能下降）
    },
    '宋诗训练': {
        '唐诗测试': 81.7 + np.random.randn() * 0.5,  # 跨域测试（性能下降）
        '宋诗测试': 90.1 + np.random.randn() * 0.5   # 同域测试
    }
}

# 各题材的迁移性能（F1分数）
theme_transfer_results = {}
for theme in themes:
    theme_transfer_results[theme] = {
        '完整训练_唐': 85 + np.random.randn() * 5,
        '完整训练_宋': 87 + np.random.randn() * 5,
        '唐训练_唐测试': 84 + np.random.randn() * 5,
        '唐训练_宋测试': 75 + np.random.randn() * 5,  # 跨域下降
        '宋训练_唐测试': 73 + np.random.randn() * 5,  # 跨域下降
        '宋训练_宋测试': 86 + np.random.randn() * 5
    }

print("✅ 数据加载完成（使用模拟数据）")
print("\n⚠️  注意：这是演示代码，实际实验需要真实训练3个模型：")
print("   1. 仅用唐诗训练数据训练的模型")
print("   2. 仅用宋诗训练数据训练的模型")
print("   3. 用完整数据训练的模型（已有）")

# ==================== 2. 计算性能下降幅度 ====================
print("\n[步骤2] 计算性能下降幅度...")

# 唐诗训练 → 宋诗测试 vs 完整训练
tang_to_song_drop = transfer_results['完整训练']['宋诗测试'] - transfer_results['唐诗训练']['宋诗测试']

# 宋诗训练 → 唐诗测试 vs 完整训练
song_to_tang_drop = transfer_results['完整训练']['唐诗测试'] - transfer_results['宋诗训练']['唐诗测试']

print(f"\n跨朝代迁移性能下降：")
print(f"  唐诗训练 → 宋诗测试：{transfer_results['唐诗训练']['宋诗测试']:.2f}%")
print(f"  完整训练 → 宋诗测试：{transfer_results['完整训练']['宋诗测试']:.2f}%")
print(f"  性能下降：{tang_to_song_drop:.2f}个百分点")
print()
print(f"  宋诗训练 → 唐诗测试：{transfer_results['宋诗训练']['唐诗测试']:.2f}%")
print(f"  完整训练 → 唐诗测试：{transfer_results['完整训练']['唐诗测试']:.2f}%")
print(f"  性能下降：{song_to_tang_drop:.2f}个百分点")

# ==================== 3. 生成Origin数据文件 ====================
print("\n[步骤3] 生成Origin数据文件...")

# 3.1 总体迁移性能对比
transfer_comparison = pd.DataFrame({
    '训练数据': ['完整训练', '完整训练', '唐诗训练', '唐诗训练', '宋诗训练', '宋诗训练'],
    '测试数据': ['唐诗', '宋诗', '唐诗', '宋诗', '唐诗', '宋诗'],
    '准确率': [
        transfer_results['完整训练']['唐诗测试'],
        transfer_results['完整训练']['宋诗测试'],
        transfer_results['唐诗训练']['唐诗测试'],
        transfer_results['唐诗训练']['宋诗测试'],
        transfer_results['宋诗训练']['唐诗测试'],
        transfer_results['宋诗训练']['宋诗测试']
    ],
    '是否跨域': ['否', '否', '否', '是', '是', '否']
})

transfer_comparison.to_csv(f'{output_dir}/transfer_comparison_origin.txt', 
                           sep='\t', index=False, encoding='utf-8')
print(f"✅ 已生成：{output_dir}/transfer_comparison_origin.txt")

# 3.2 性能下降幅度
performance_drop = pd.DataFrame({
    '迁移方向': ['唐→宋', '宋→唐'],
    '完整训练准确率': [
        transfer_results['完整训练']['宋诗测试'],
        transfer_results['完整训练']['唐诗测试']
    ],
    '单域训练准确率': [
        transfer_results['唐诗训练']['宋诗测试'],
        transfer_results['宋诗训练']['唐诗测试']
    ],
    '性能下降': [tang_to_song_drop, song_to_tang_drop]
})

performance_drop.to_csv(f'{output_dir}/performance_drop_origin.txt', 
                        sep='\t', index=False, encoding='utf-8')
print(f"✅ 已生成：{output_dir}/performance_drop_origin.txt")

# 3.3 各题材迁移性能矩阵
theme_transfer_matrix = []
for theme in themes:
    theme_transfer_matrix.append({
        '题材': theme,
        '完整_唐': theme_transfer_results[theme]['完整训练_唐'],
        '完整_宋': theme_transfer_results[theme]['完整训练_宋'],
        '唐训练_唐测试': theme_transfer_results[theme]['唐训练_唐测试'],
        '唐训练_宋测试': theme_transfer_results[theme]['唐训练_宋测试'],
        '宋训练_唐测试': theme_transfer_results[theme]['宋训练_唐测试'],
        '宋训练_宋测试': theme_transfer_results[theme]['宋训练_宋测试']
    })

theme_transfer_df = pd.DataFrame(theme_transfer_matrix)
theme_transfer_df.to_csv(f'{output_dir}/theme_transfer_matrix_origin.txt', 
                         sep='\t', index=False, encoding='utf-8')
print(f"✅ 已生成：{output_dir}/theme_transfer_matrix_origin.txt")

# ==================== 4. 生成可视化图表 ====================
print("\n[步骤4] 生成可视化图表...")

# 4.1 迁移学习性能对比图
fig, ax = plt.subplots(figsize=(12, 6))

scenarios = ['完整训练\n唐诗测试', '完整训练\n宋诗测试', 
             '唐诗训练\n唐诗测试', '唐诗训练\n宋诗测试',
             '宋诗训练\n唐诗测试', '宋诗训练\n宋诗测试']

accuracies = [
    transfer_results['完整训练']['唐诗测试'],
    transfer_results['完整训练']['宋诗测试'],
    transfer_results['唐诗训练']['唐诗测试'],
    transfer_results['唐诗训练']['宋诗测试'],
    transfer_results['宋诗训练']['唐诗测试'],
    transfer_results['宋诗训练']['宋诗测试']
]

colors = ['#2ECC71', '#2ECC71', '#3498DB', '#E74C3C', '#E74C3C', '#3498DB']
bar_labels = ['基线', '基线', '同域', '跨域', '跨域', '同域']

bars = ax.bar(range(len(scenarios)), accuracies, color=colors, alpha=0.7, edgecolor='black', linewidth=1.5)

# 标注数值
for i, (bar, acc) in enumerate(zip(bars, accuracies)):
    height = bar.get_height()
    ax.text(bar.get_x() + bar.get_width()/2., height + 0.5,
            f'{acc:.2f}%\n({bar_labels[i]})',
            ha='center', va='bottom', fontsize=10, fontweight='bold')

ax.set_ylabel('准确率 (%)', fontsize=12)
ax.set_title('跨朝代迁移学习性能对比', fontsize=14, fontweight='bold')
ax.set_xticks(range(len(scenarios)))
ax.set_xticklabels(scenarios, fontsize=10)
ax.set_ylim(70, 95)
ax.grid(axis='y', alpha=0.3)

# 添加图例
from matplotlib.patches import Patch
legend_elements = [
    Patch(facecolor='#2ECC71', alpha=0.7, label='完整训练（基线）'),
    Patch(facecolor='#3498DB', alpha=0.7, label='单域训练-同域测试'),
    Patch(facecolor='#E74C3C', alpha=0.7, label='单域训练-跨域测试')
]
ax.legend(handles=legend_elements, loc='lower right', fontsize=10)

plt.tight_layout()
plt.savefig(f'{output_dir}/transfer_performance_comparison.png', dpi=300, bbox_inches='tight')
plt.close()
print(f"✅ 已生成：{output_dir}/transfer_performance_comparison.png")

# 4.2 性能下降幅度对比图
fig, ax = plt.subplots(figsize=(10, 6))

x = np.arange(2)
width = 0.35

full_acc = [transfer_results['完整训练']['宋诗测试'], 
            transfer_results['完整训练']['唐诗测试']]
transfer_acc = [transfer_results['唐诗训练']['宋诗测试'],
                transfer_results['宋诗训练']['唐诗测试']]

ax.bar(x - width/2, full_acc, width, label='完整训练', color='#2ECC71', alpha=0.7)
ax.bar(x + width/2, transfer_acc, width, label='单域训练（跨域测试）', color='#E74C3C', alpha=0.7)

# 标注性能下降
for i in range(2):
    drop = full_acc[i] - transfer_acc[i]
    mid_y = (full_acc[i] + transfer_acc[i]) / 2
    ax.annotate('', xy=(i + width/2, transfer_acc[i]), xytext=(i - width/2, full_acc[i]),
                arrowprops=dict(arrowstyle='<->', color='red', lw=2))
    ax.text(i, mid_y, f'↓{drop:.2f}%', ha='center', va='center', 
            fontsize=11, fontweight='bold', color='red',
            bbox=dict(boxstyle='round,pad=0.3', facecolor='white', edgecolor='red'))

ax.set_ylabel('准确率 (%)', fontsize=12)
ax.set_title('跨朝代迁移性能下降分析', fontsize=14, fontweight='bold')
ax.set_xticks(x)
ax.set_xticklabels(['唐诗训练→宋诗测试', '宋诗训练→唐诗测试'], fontsize=11)
ax.legend(fontsize=11)
ax.set_ylim(75, 95)
ax.grid(axis='y', alpha=0.3)

plt.tight_layout()
plt.savefig(f'{output_dir}/transfer_performance_drop.png', dpi=300, bbox_inches='tight')
plt.close()
print(f"✅ 已生成：{output_dir}/transfer_performance_drop.png")

# 4.3 各题材迁移性能热力图
fig, ax = plt.subplots(figsize=(14, 8))

# 准备热力图数据
heatmap_data = np.array([
    [theme_transfer_results[t]['完整训练_唐'] for t in themes],
    [theme_transfer_results[t]['完整训练_宋'] for t in themes],
    [theme_transfer_results[t]['唐训练_唐测试'] for t in themes],
    [theme_transfer_results[t]['唐训练_宋测试'] for t in themes],
    [theme_transfer_results[t]['宋训练_唐测试'] for t in themes],
    [theme_transfer_results[t]['宋训练_宋测试'] for t in themes]
]).T

sns.heatmap(heatmap_data, annot=True, fmt='.1f', cmap='RdYlGn', 
            xticklabels=['完整_唐', '完整_宋', '唐训练\n唐测试', '唐训练\n宋测试', '宋训练\n唐测试', '宋训练\n宋测试'],
            yticklabels=themes,
            cbar_kws={'label': 'F1分数 (%)'}, ax=ax, vmin=65, vmax=95,
            linewidths=0.5, linecolor='gray')

ax.set_title('各题材跨朝代迁移性能热力图', fontsize=14, fontweight='bold', pad=20)
ax.set_xlabel('训练-测试场景', fontsize=12)
ax.set_ylabel('题材', fontsize=12)

plt.tight_layout()
plt.savefig(f'{output_dir}/theme_transfer_heatmap.png', dpi=300, bbox_inches='tight')
plt.close()
print(f"✅ 已生成：{output_dir}/theme_transfer_heatmap.png")

# ==================== 5. 生成综合报告 ====================
print("\n[步骤5] 生成综合报告...")

report = f"""
{'='*80}
实验2扩展：跨朝代迁移学习 - 综合报告
{'='*80}

一、实验设计
{'='*80}
本实验旨在评估模型在不同历史时期古诗间的泛化能力。

实验场景：
1. 完整训练（基线）：使用唐宋混合数据训练，分别在唐诗和宋诗上测试
2. 唐诗单域训练：仅使用唐诗训练，在唐诗（同域）和宋诗（跨域）上测试
3. 宋诗单域训练：仅使用宋诗训练，在宋诗（同域）和唐诗（跨域）上测试

二、总体性能对比
{'='*80}
{'训练数据':<15s} {'测试数据':<12s} {'准确率':<12s} {'类型':<15s}
{'-'*60}
{'完整训练':<15s} {'唐诗':<12s} {transfer_results['完整训练']['唐诗测试']:<12.2f} {'基线':<15s}
{'完整训练':<15s} {'宋诗':<12s} {transfer_results['完整训练']['宋诗测试']:<12.2f} {'基线':<15s}
{'唐诗训练':<15s} {'唐诗':<12s} {transfer_results['唐诗训练']['唐诗测试']:<12.2f} {'同域测试':<15s}
{'唐诗训练':<15s} {'宋诗':<12s} {transfer_results['唐诗训练']['宋诗测试']:<12.2f} {'跨域测试':<15s}
{'宋诗训练':<15s} {'唐诗':<12s} {transfer_results['宋诗训练']['唐诗测试']:<12.2f} {'跨域测试':<15s}
{'宋诗训练':<15s} {'宋诗':<12s} {transfer_results['宋诗训练']['宋诗测试']:<12.2f} {'同域测试':<15s}

三、跨域性能下降分析
{'='*80}
1. 唐诗训练 → 宋诗测试：
   - 完整训练准确率：{transfer_results['完整训练']['宋诗测试']:.2f}%
   - 单域训练准确率：{transfer_results['唐诗训练']['宋诗测试']:.2f}%
   - 性能下降：{tang_to_song_drop:.2f}个百分点 ({'严重' if tang_to_song_drop > 10 else '中等' if tang_to_song_drop > 5 else '轻微'})

2. 宋诗训练 → 唐诗测试：
   - 完整训练准确率：{transfer_results['完整训练']['唐诗测试']:.2f}%
   - 单域训练准确率：{transfer_results['宋诗训练']['唐诗测试']:.2f}%
   - 性能下降：{song_to_tang_drop:.2f}个百分点 ({'严重' if song_to_tang_drop > 10 else '中等' if song_to_tang_drop > 5 else '轻微'})

平均跨域性能下降：{(tang_to_song_drop + song_to_tang_drop) / 2:.2f}个百分点

四、关键发现
{'='*80}
1. 跨朝代迁移存在显著性能下降：
   - 平均下降幅度约{(tang_to_song_drop + song_to_tang_drop) / 2:.1f}个百分点
   - 说明唐诗和宋诗在语言风格、题材特征上存在差异

2. 不同题材的迁移能力差异：
   - 某些题材（如山水田园）可能具有更强的跨时代迁移能力
   - 某些题材（如边塞战争）可能受历史背景影响更大，迁移能力较弱

3. 完整训练的优势：
   - 在两个朝代上均表现最优
   - 证明混合训练有助于提升模型的时间泛化能力

五、实用意义
{'='*80}
1. 对于实际应用：
   - 建议使用多朝代混合数据训练，以提升跨时代泛化能力
   - 如果只有单一朝代数据，需警惕在其他朝代上的性能下降

2. 对于数据标注：
   - 应尽量收集不同历史时期的标注数据
   - 平衡各朝代的样本量，避免模型偏向某一时期

3. 对于模型改进：
   - 可考虑引入朝代特征或时代注意力机制
   - 使用域适应技术减少跨朝代性能下降

{'='*80}
实验完成时间：{pd.Timestamp.now()}
输出目录：{output_dir}/
{'='*80}

⚠️  注意：本报告使用模拟数据演示，实际实验需要：
   1. 用唐诗训练数据训练模型
   2. 用宋诗训练数据训练模型
   3. 分别在唐诗和宋诗测试集上评估
"""

# 保存报告
with open(f'{output_dir}/transfer_experiment_report.txt', 'w', encoding='utf-8') as f:
    f.write(report)

print(report)
print(f"\n✅ 综合报告已保存：{output_dir}/transfer_experiment_report.txt")

print("\n" + "=" * 80)
print("✅ 跨朝代迁移学习实验完成！")
print("=" * 80)
print(f"\n生成的文件：")
print(f"  📊 Origin数据文件：")
print(f"     - {output_dir}/transfer_comparison_origin.txt")
print(f"     - {output_dir}/performance_drop_origin.txt")
print(f"     - {output_dir}/theme_transfer_matrix_origin.txt")
print(f"  📈 可视化图表：")
print(f"     - {output_dir}/transfer_performance_comparison.png")
print(f"     - {output_dir}/transfer_performance_drop.png")
print(f"     - {output_dir}/theme_transfer_heatmap.png")
print(f"  📝 综合报告：")
print(f"     - {output_dir}/transfer_experiment_report.txt")
print("\n" + "=" * 80)

