# -*- coding: utf-8 -*-
"""
对唐宋古诗数据集进行分词处理
1. 先将诗中所有标点符号替换为|
2. 再使用jieba分词

处理文件：
- poems_600each_tang.json（唐代古诗数据集）
- poems_600each_song.json（宋代古诗数据集）

输出格式参照：poems_jieba_merged.json
"""

import json
import jieba
import re
from tqdm import tqdm

# 定义所有可能的中文标点符号
CHINESE_PUNCTUATION = '，。！？；：""''（）《》、…—·【】『』「」'

def replace_punctuation_with_pipe(text):
    """
    将文本中的所有标点符号替换为|
    :param text: 原始文本
    :return: 替换后的文本
    """
    # 替换中文标点符号
    for punct in CHINESE_PUNCTUATION:
        text = text.replace(punct, '|')
    
    # 替换英文标点符号
    english_punctuation = ',.!?;:\'"()[]{}…-'
    for punct in english_punctuation:
        text = text.replace(punct, '|')
    
    # 去除连续的|，只保留一个
    text = re.sub(r'\|+', '|', text)
    
    # 去除首尾的|
    text = text.strip('|')
    
    return text

def segment_poem_jieba(poem_text):
    """
    对诗词文本进行jieba分词
    :param poem_text: 已经将标点替换为|的诗词文本
    :return: 分词后的文本（保持|分隔，词之间用空格分隔）
    """
    # 按|分割诗句
    verses = poem_text.split('|')
    
    # 对每句诗进行分词
    segmented_verses = []
    for verse in verses:
        if verse.strip():  # 如果诗句不为空
            # 使用jieba分词
            words = jieba.cut(verse.strip())
            # 用空格连接分词结果
            segmented_verse = ' '.join(words)
            segmented_verses.append(segmented_verse)
    
    # 用|连接所有诗句
    return '|'.join(segmented_verses)

def process_poetry_dataset(input_file, output_file, dynasty_name):
    """
    处理整个诗词数据集
    :param input_file: 输入的JSON文件路径
    :param output_file: 输出的JSON文件路径
    :param dynasty_name: 朝代名称（用于显示）
    """
    print("=" * 80)
    print(f"开始处理{dynasty_name}古诗数据集：{input_file}")
    print("=" * 80)
    
    # 加载数据
    print("\n[步骤1] 加载数据...")
    with open(input_file, 'r', encoding='utf-8') as f:
        poems_data = json.load(f)
    
    print(f"[OK] 共加载 {len(poems_data)} 首诗")
    
    # 显示原始数据示例
    print("\n[原始数据示例]")
    sample = poems_data[0]
    print(f"诗人：{sample['poet']}")
    print(f"标题：{sample['title']}")
    print(f"原始诗句：{sample['poem']}")
    
    # 处理每首诗
    print(f"\n[步骤2] 处理{len(poems_data)}首诗...")
    
    for poem_item in tqdm(poems_data, desc=f"处理{dynasty_name}诗"):
        original_poem = poem_item['poem']
        
        # 步骤1：将标点符号替换为|
        poem_with_pipe = replace_punctuation_with_pipe(original_poem)
        poem_item['poem'] = poem_with_pipe
        
        # 步骤2：jieba分词
        segmented_poem = segment_poem_jieba(poem_with_pipe)
        poem_item['segmented_poem_jieba'] = segmented_poem
    
    # 保存结果
    print(f"\n[步骤3] 保存结果到 {output_file}...")
    with open(output_file, 'w', encoding='utf-8') as f:
        json.dump(poems_data, f, ensure_ascii=False, indent=2)
    
    print(f"[OK] 已保存 {len(poems_data)} 首诗")
    
    # 显示处理后的示例
    print("\n" + "=" * 80)
    print(f"【{dynasty_name}古诗】分词示例（前3首）：")
    print("=" * 80)
    
    for i in range(min(3, len(poems_data))):
        poem_item = poems_data[i]
        print(f"\n第 {i+1} 首：《{poem_item['title']}》 - {poem_item['poet']} ({poem_item['dynasty']})")
        print(f"题材：{poem_item['theme']}")
        print(f"处理后诗句：{poem_item['poem']}")
        print(f"分词结果：{poem_item['segmented_poem_jieba']}")
        print("-" * 80)
    
    print(f"\n[OK] {dynasty_name}古诗数据集处理完成！\n")
    return len(poems_data)

def main():
    """
    主函数：处理唐宋两个数据集
    """
    print("\n" + "=" * 80)
    print("唐宋古诗数据集 - Jieba分词处理")
    print("=" * 80)
    print("\n功能说明：")
    print("1. 将诗中所有标点符号替换为 |")
    print("2. 使用jieba分词工具进行分词")
    print("3. 输出格式参照 poems_jieba_merged.json")
    print("\n" + "=" * 80)
    
    # 检查jieba是否安装
    try:
        import jieba
        print("\n[OK] jieba分词工具已安装")
    except ImportError:
        print("\n[ERROR] 错误：未安装jieba分词工具")
        print("请运行以下命令安装：")
        print("  pip install jieba")
        return
    
    # 处理唐代数据集
    tang_count = process_poetry_dataset(
        input_file='poems_600each_tang.json',
        output_file='poems_600each_tang_jieba.json',
        dynasty_name='唐代'
    )
    
    # 处理宋代数据集
    song_count = process_poetry_dataset(
        input_file='poems_600each_song.json',
        output_file='poems_600each_song_jieba.json',
        dynasty_name='宋代'
    )
    
    # 总结
    print("\n" + "=" * 80)
    print("[OK] 全部处理完成！")
    print("=" * 80)
    print(f"\n处理统计：")
    print(f"  唐代诗歌：{tang_count} 首 → poems_600each_tang_jieba.json")
    print(f"  宋代诗歌：{song_count} 首 → poems_600each_song_jieba.json")
    print(f"  总计：{tang_count + song_count} 首")
    
    print("\n输出文件：")
    print("  1. poems_600each_tang_jieba.json（唐代古诗，已分词）")
    print("  2. poems_600each_song_jieba.json（宋代古诗，已分词）")
    
    print("\n文件格式（与poems_jieba_merged.json一致）：")
    print("""  {
    "poet": "诗人名",
    "poem": "诗句内容（标点已替换为|）",
    "dynasty": "朝代",
    "title": "诗词标题",
    "theme": "题材",
    "segmented_poem_jieba": "jieba分词结果（空格分隔词，|分隔句）"
  }""")
    
    print("\n" + "=" * 80)

if __name__ == '__main__':
    main()

