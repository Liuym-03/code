# -*- coding: utf-8 -*-
"""
古诗词数据清洗脚本
功能：去除数据集中的无效信息，如特殊字符、表情符号和HTML标签等
"""

import json
import re
import html
import sys
import io
from pathlib import Path

# 设置标准输出编码为UTF-8（Windows控制台支持）
if sys.platform == 'win32':
    sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8', errors='replace')
    sys.stderr = io.TextIOWrapper(sys.stderr.buffer, encoding='utf-8', errors='replace')


def remove_html_tags(text):
    """移除HTML标签"""
    if not isinstance(text, str):
        return text
    # 移除所有HTML标签
    text = re.sub(r'<[^>]+>', '', text)
    return text


def remove_html_entities(text):
    """移除或转换HTML实体"""
    if not isinstance(text, str):
        return text
    # 将HTML实体转换为普通字符（如 &nbsp; -> 空格，&lt; -> <）
    text = html.unescape(text)
    return text


def remove_emoji(text):
    """移除表情符号（精确匹配，避免误删中文字符）"""
    if not isinstance(text, str):
        return text
    # 只匹配真正的表情符号范围
    # 注意：避免使用可能包含中文字符的大范围（如 \U000024C2-\U0001F251）
    # 中文字符在 U+4E00 到 U+9FFF 范围，我们的表情符号范围都在这个范围之外
    emoji_pattern = re.compile(
        "["
        "\U0001F600-\U0001F64F"  # Emoticons (表情符号)
        "\U0001F300-\U0001F5FF"  # Symbols & Pictographs (符号和象形文字)
        "\U0001F680-\U0001F6FF"  # Transport & Map Symbols (交通和地图符号)
        "\U0001F1E0-\U0001F1FF"  # Flags (旗帜)
        "\U0001F900-\U0001F9FF"  # Supplemental Symbols and Pictographs (补充符号)
        "\U0001FA00-\U0001FA6F"  # Chess Symbols (象棋符号)
        "\U0001FA70-\U0001FAFF"  # Symbols and Pictographs Extended-A (扩展符号A)
        "]+",
        flags=re.UNICODE
    )
    text = emoji_pattern.sub('', text)
    return text


def remove_special_chars(text):
    """移除特殊字符，保留中文、英文、数字和基本标点"""
    if not isinstance(text, str):
        return text
    
    # 保留：中文（包括扩展）、英文、数字、基本标点、空格、换行、制表符
    # 以及诗句分隔符 | 和常见的其他标点
    # 使用更宽松的匹配：保留所有可见的Unicode字符、空格、标点等
    # 只移除明显的控制字符、不可见字符等
    # 匹配中文字符范围扩展到包含扩展A区和B区
    pattern = r'[^\u4e00-\u9fff\u3400-\u4dbf\uf900-\ufaff\w\s，。！？；：、\|\n\t\r\(\)\[\]【】（）《》""''「」『』]'
    text = re.sub(pattern, '', text)
    return text


def remove_control_chars(text):
    """移除控制字符（但保留换行符、制表符等常用空白字符）"""
    if not isinstance(text, str):
        return text
    # 移除除了常见空白字符（空格、制表符、换行符、回车符）之外的控制字符
    # 控制字符范围：\x00-\x1f (除了 \t\n\r) 和 \x7f-\x9f
    text = re.sub(r'[\x00-\x08\x0b\x0c\x0e-\x1f\x7f-\x9f]', '', text)
    return text


def clean_text(text):
    """综合清洗文本"""
    if not isinstance(text, str):
        return text
    
    # 步骤1: 移除HTML标签
    text = remove_html_tags(text)
    
    # 步骤2: 转换HTML实体
    text = remove_html_entities(text)
    
    # 步骤3: 移除表情符号
    text = remove_emoji(text)
    
    # 步骤4: 移除控制字符
    text = remove_control_chars(text)
    
    # 注意：不再进行激进的特殊字符移除，因为可能误删正常字符
    # 如果需要，可以在这里添加更精细的过滤规则
    
    # 步骤5: 清理多余的空白字符
    # 将多个连续空格替换为单个空格（但保留诗句分隔符前后的空格处理）
    text = re.sub(r' +', ' ', text)
    # 移除行首行尾空白
    text = text.strip()
    
    return text


def clean_poetry_data(input_file, output_file):
    """清洗古诗词数据"""
    print(f"开始读取数据文件: {input_file}")
    
    # 读取JSON文件
    with open(input_file, 'r', encoding='utf-8') as f:
        data = json.load(f)
    
    print(f"原始数据条目数: {len(data)}")
    
    # 统计清洗信息
    cleaned_count = 0
    removed_count = 0
    
    # 清洗数据
    cleaned_data = []
    for idx, item in enumerate(data):
        original_item = json.dumps(item, ensure_ascii=False)
        
        # 清洗各个字段
        if 'poet' in item:
            item['poet'] = clean_text(item['poet']) if item['poet'] else item['poet']
        if 'poem' in item:
            item['poem'] = clean_text(item['poem']) if item['poem'] else item['poem']
        if 'title' in item:
            item['title'] = clean_text(item['title']) if item['title'] else item['title']
        if 'dynasty' in item:
            item['dynasty'] = clean_text(item['dynasty']) if item['dynasty'] else item['dynasty']
        
        # 清洗setiments字段中的值（如果有字符串类型的话）
        if 'setiments' in item and isinstance(item['setiments'], dict):
            for key, value in item['setiments'].items():
                if isinstance(value, str):
                    item['setiments'][key] = clean_text(value)
        
        # 检查是否为空或无效
        cleaned_item = json.dumps(item, ensure_ascii=False)
        
        # 如果关键字段都为空或清洗后为空，则跳过
        poet = str(item.get('poet', '')).strip() if item.get('poet') is not None else ''
        poem = str(item.get('poem', '')).strip() if item.get('poem') is not None else ''
        title = str(item.get('title', '')).strip() if item.get('title') is not None else ''
        
        if not poet or not poem or not title:
            removed_count += 1
            continue
        
        # 检查是否有变化
        if original_item != cleaned_item:
            cleaned_count += 1
        
        cleaned_data.append(item)
        
        # 每处理1000条显示进度
        if (idx + 1) % 1000 == 0:
            print(f"已处理 {idx + 1}/{len(data)} 条数据...")
    
    print(f"\n数据清洗完成！")
    print(f"原始数据: {len(data)} 条")
    print(f"清洗后数据: {len(cleaned_data)} 条")
    print(f"被修改的数据: {cleaned_count} 条")
    print(f"被移除的数据: {removed_count} 条")
    
    # 保存清洗后的数据
    print(f"\n正在保存清洗后的数据到: {output_file}")
    with open(output_file, 'w', encoding='utf-8') as f:
        json.dump(cleaned_data, f, ensure_ascii=False, indent=2)
    
    print(f"[完成] 数据清洗完成！输出文件: {output_file}")
    return cleaned_data


if __name__ == '__main__':
    # 输入和输出文件路径
    input_file = 'FSPC_V1.0.json'
    output_file = 'FSPC_V1.0_cleaned.json'
    
    # 执行清洗
    cleaned_data = clean_poetry_data(input_file, output_file)
    
    # 显示一些清洗后的示例数据
    print("\n清洗后的数据示例（前3条）:")
    for i, item in enumerate(cleaned_data[:3]):
        print(f"\n示例 {i+1}:")
        print(f"  诗人: {item.get('poet', '')}")
        print(f"  标题: {item.get('title', '')}")
        print(f"  朝代: {item.get('dynasty', '')}")
        print(f"  诗句: {item.get('poem', '')[:50]}...")  # 只显示前50个字符

