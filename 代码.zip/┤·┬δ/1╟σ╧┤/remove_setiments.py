# -*- coding: utf-8 -*-
"""
删除古诗词数据中的 setiments 字段
功能：删除所有数据条目中的 setiments 字段（包括 holistic、line1-line4 等）
"""

import json
import sys
import io
from pathlib import Path

# 设置标准输出编码为UTF-8（Windows控制台支持）
if sys.platform == 'win32':
    sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8', errors='replace')
    sys.stderr = io.TextIOWrapper(sys.stderr.buffer, encoding='utf-8', errors='replace')


def remove_setiments(input_file, output_file):
    """删除数据中的所有 setiments 字段"""
    print(f"开始读取数据文件: {input_file}")
    
    # 读取JSON文件
    with open(input_file, 'r', encoding='utf-8') as f:
        data = json.load(f)
    
    print(f"原始数据条目数: {len(data)}")
    
    # 统计信息
    removed_count = 0
    
    # 删除 setiments 字段
    for idx, item in enumerate(data):
        if 'setiments' in item:
            del item['setiments']
            removed_count += 1
        
        # 每处理1000条显示进度
        if (idx + 1) % 1000 == 0:
            print(f"已处理 {idx + 1}/{len(data)} 条数据...")
    
    print(f"\n数据删除完成！")
    print(f"总数据条目: {len(data)} 条")
    print(f"删除 setiments 字段的条目: {removed_count} 条")
    
    # 保存修改后的数据
    print(f"\n正在保存修改后的数据到: {output_file}")
    with open(output_file, 'w', encoding='utf-8') as f:
        json.dump(data, f, ensure_ascii=False, indent=2)
    
    print(f"[完成] 数据删除完成！输出文件: {output_file}")
    return data


if __name__ == '__main__':
    # 输入和输出文件路径
    input_file = 'FSPC_V1.0_cleaned.json'  # 使用清洗后的文件
    output_file = 'FSPC_V1.0_final.json'  # 最终输出文件
    
    # 如果需要处理原始文件，可以改为：
    # input_file = 'FSPC_V1.0.json'
    
    # 执行删除
    cleaned_data = remove_setiments(input_file, output_file)
    
    # 显示一些示例数据
    print("\n删除后的数据示例（前2条）:")
    for i, item in enumerate(cleaned_data[:2]):
        print(f"\n示例 {i+1}:")
        print(f"  诗人: {item.get('poet', '')}")
        print(f"  标题: {item.get('title', '')}")
        print(f"  朝代: {item.get('dynasty', '')}")
        print(f"  诗句: {item.get('poem', '')[:50]}...")
        print(f"  是否还有setiments字段: {'setiments' in item}")


