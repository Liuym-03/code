"""
使用jieba对themed_poems.json中的古诗词进行分词
示例：原始文本："金樽清酒斗十千|玉盘珍羞直万钱|停杯投箸不能食|拔剑四顾心茫然"
     分词结果："金樽 清酒 斗 十千 玉盘 珍羞 直 万钱 停杯 投箸 不能 食 拔剑 四顾 心 茫然"
"""
import json
import jieba
from tqdm import tqdm

def segment_poem(poem_text):
    """
    对古诗词文本进行分词
    
    Args:
        poem_text: 诗词文本，句子之间用|分隔
    
    Returns:
        分词后的文本，词之间用空格分隔，句子之间用|分隔
    """
    # 按|分割句子
    lines = poem_text.split('|')
    
    # 对每个句子进行分词
    segmented_lines = []
    for line in lines:
        # 使用jieba分词
        words = jieba.cut(line.strip())
        # 用空格连接分词结果
        segmented_line = ' '.join(words)
        segmented_lines.append(segmented_line)
    
    # 用|连接所有句子
    return '|'.join(segmented_lines)


def main():
    print("=" * 60)
    print("使用jieba对古诗词进行分词")
    print("=" * 60)
    
    # 读取原始数据
    input_file = 'themed_poems.json'
    output_file = 'themed_poems_jieba_segmented.json'
    
    print(f"\n读取数据文件: {input_file}")
    with open(input_file, 'r', encoding='utf-8') as f:
        poems = json.load(f)
    
    print(f"共加载 {len(poems)} 首古诗词\n")
    
    # 对每首诗进行分词
    print("开始分词处理...")
    segmented_poems = []
    
    for poem in tqdm(poems, desc="分词进度"):
        # 复制原始数据
        new_poem = poem.copy()
        
        # 对诗词文本进行分词
        original_text = poem['poem']
        segmented_text = segment_poem(original_text)
        
        # 添加分词结果字段
        new_poem['segmented_poem_jieba'] = segmented_text
        
        segmented_poems.append(new_poem)
    
    # 保存结果
    print(f"\n保存分词结果到: {output_file}")
    with open(output_file, 'w', encoding='utf-8') as f:
        json.dump(segmented_poems, f, ensure_ascii=False, indent=2)
    
    print(f"\n[完成] 成功处理 {len(segmented_poems)} 首古诗词")
    
    # 显示示例
    print("\n" + "=" * 60)
    print("分词示例（前3首）:")
    print("=" * 60)
    
    for i, poem in enumerate(segmented_poems[:3], 1):
        print(f"\n【示例 {i}】")
        print(f"诗人: {poem['poet']}")
        print(f"标题: {poem['title']}")
        print(f"朝代: {poem['dynasty']}")
        print(f"主题: {poem['theme']}")
        print(f"\n原始文本:")
        print(f"  {poem['poem']}")
        print(f"\n分词结果:")
        print(f"  {poem['segmented_poem_jieba']}")
    
    # 统计信息
    print("\n" + "=" * 60)
    print("统计信息:")
    print("=" * 60)
    
    # 统计各主题的诗词数量
    theme_count = {}
    for poem in segmented_poems:
        theme = poem.get('theme', '未知')
        theme_count[theme] = theme_count.get(theme, 0) + 1
    
    print("\n各主题诗词数量:")
    for theme, count in sorted(theme_count.items(), key=lambda x: x[1], reverse=True):
        print(f"  {theme}: {count}首")
    
    print("\n" + "=" * 60)
    print(f"分词结果已保存到: {output_file}")
    print("=" * 60)


if __name__ == '__main__':
    main()



