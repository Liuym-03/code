"""
合并两个jieba分词结果文件，并去除重复的古诗词
"""
import json
from tqdm import tqdm

def create_poem_key(poem_data):
    """
    创建诗词的唯一标识
    使用诗人、标题、诗词内容作为判断依据
    """
    poet = poem_data.get('poet', '')
    title = poem_data.get('title', '')
    poem = poem_data.get('poem', '')
    
    # 组合成唯一键
    return f"{poet}|{title}|{poem}"


def normalize_poem_data(poem_data):
    """
    标准化诗词数据结构
    统一分词字段名为 segmented_poem_jieba
    """
    normalized = poem_data.copy()
    
    # 如果有 segmented_poem 字段但没有 segmented_poem_jieba，则重命名
    if 'segmented_poem' in normalized and 'segmented_poem_jieba' not in normalized:
        normalized['segmented_poem_jieba'] = normalized['segmented_poem']
        del normalized['segmented_poem']
    
    return normalized


def merge_and_deduplicate(file1, file2, output_file):
    """
    合并两个JSON文件并去重
    """
    print("=" * 70)
    print("合并jieba分词结果文件并去重")
    print("=" * 70)
    
    # 读取第一个文件
    print(f"\n读取文件1: {file1}")
    with open(file1, 'r', encoding='utf-8') as f:
        poems1 = json.load(f)
    print(f"  加载了 {len(poems1)} 首古诗词")
    
    # 读取第二个文件
    print(f"\n读取文件2: {file2}")
    with open(file2, 'r', encoding='utf-8') as f:
        poems2 = json.load(f)
    print(f"  加载了 {len(poems2)} 首古诗词")
    
    # 使用字典去重（键为诗词唯一标识）
    print("\n开始合并和去重...")
    unique_poems = {}
    
    # 处理第一个文件的诗词
    print("  处理文件1的诗词...")
    for poem in tqdm(poems1, desc="  文件1"):
        key = create_poem_key(poem)
        if key not in unique_poems:
            unique_poems[key] = normalize_poem_data(poem)
    
    # 处理第二个文件的诗词
    print("  处理文件2的诗词...")
    duplicates_count = 0
    for poem in tqdm(poems2, desc="  文件2"):
        key = create_poem_key(poem)
        if key not in unique_poems:
            unique_poems[key] = normalize_poem_data(poem)
        else:
            duplicates_count += 1
    
    # 转换为列表
    merged_poems = list(unique_poems.values())
    
    # 保存结果
    print(f"\n保存合并结果到: {output_file}")
    with open(output_file, 'w', encoding='utf-8') as f:
        json.dump(merged_poems, f, ensure_ascii=False, indent=2)
    
    # 统计信息
    print("\n" + "=" * 70)
    print("合并统计:")
    print("=" * 70)
    print(f"文件1数量: {len(poems1)} 首")
    print(f"文件2数量: {len(poems2)} 首")
    print(f"总计: {len(poems1) + len(poems2)} 首")
    print(f"重复数量: {duplicates_count} 首")
    print(f"去重后: {len(merged_poems)} 首")
    print(f"保留率: {len(merged_poems) / (len(poems1) + len(poems2)) * 100:.2f}%")
    
    # 按朝代统计
    print("\n" + "=" * 70)
    print("朝代分布:")
    print("=" * 70)
    dynasty_count = {}
    for poem in merged_poems:
        dynasty = poem.get('dynasty', '未知')
        dynasty_count[dynasty] = dynasty_count.get(dynasty, 0) + 1
    
    for dynasty, count in sorted(dynasty_count.items(), key=lambda x: x[1], reverse=True):
        print(f"  {dynasty}: {count}首")
    
    # 按主题统计（如果有theme字段）
    print("\n" + "=" * 70)
    print("主题分布:")
    print("=" * 70)
    theme_count = {}
    no_theme = 0
    for poem in merged_poems:
        if 'theme' in poem:
            theme = poem['theme']
            theme_count[theme] = theme_count.get(theme, 0) + 1
        else:
            no_theme += 1
    
    if theme_count:
        for theme, count in sorted(theme_count.items(), key=lambda x: x[1], reverse=True):
            print(f"  {theme}: {count}首")
    if no_theme > 0:
        print(f"  无主题标签: {no_theme}首")
    
    # 显示示例
    print("\n" + "=" * 70)
    print("合并结果示例（前3首）:")
    print("=" * 70)
    
    for i, poem in enumerate(merged_poems[:3], 1):
        print(f"\n【示例 {i}】")
        print(f"诗人: {poem['poet']}")
        print(f"标题: {poem['title']}")
        print(f"朝代: {poem['dynasty']}")
        if 'theme' in poem:
            print(f"主题: {poem['theme']}")
        print(f"原始: {poem['poem'][:50]}{'...' if len(poem['poem']) > 50 else ''}")
        print(f"分词: {poem['segmented_poem_jieba'][:50]}{'...' if len(poem['segmented_poem_jieba']) > 50 else ''}")
    
    print("\n" + "=" * 70)
    print(f"[OK] 合并完成！结果已保存到: {output_file}")
    print("=" * 70)


if __name__ == '__main__':
    # 输入文件
    file1 = 'themed_poems_jieba_segmented.json'
    file2 = 'poems_jieba_segmented.json'
    
    # 输出文件
    output_file = 'poems_jieba_merged.json'
    
    # 执行合并和去重
    merge_and_deduplicate(file1, file2, output_file)

