"""
古诗数据预处理：停用词过滤 + 句式韵律特征标注
"""
import json
import re
import jieba.posseg as pseg
from tqdm import tqdm
import numpy as np

class PoetryPreprocessor:
    """古诗预处理器"""
    
    def __init__(self, stopwords_file='古诗停用词表.txt'):
        """初始化"""
        # 加载停用词
        with open(stopwords_file, 'r', encoding='utf-8') as f:
            self.stopwords = set([line.strip() for line in f if line.strip()])
        
        print(f"加载停用词表: {len(self.stopwords)} 个停用词")
        
        # 意象词和动作词（保留词）- 示例词表
        self.image_words = {
            '孤烟', '茅舍', '沙场', '东篱', '菊花', '征人', '羌笛', '桑麻',
            '大漠', '长河', '边塞', '落日', '关山', '戍楼', '城楼', '戍所',
            '青山', '绿树', '村边', '郭外', '江南', '烟雨', '明月', '清风'
        }
        
        self.action_words = {
            '戍', '耕', '望', '采', '游', '行', '归', '去', '来', '饮',
            '醉', '笑', '哭', '思', '忆', '梦', '愁', '别', '送', '迎'
        }
    
    def filter_stopwords(self, segmented_text):
        """
        停用词过滤
        
        Args:
            segmented_text: 分词后的文本，如 "吾爱 吾 庐 事事 幽"
        
        Returns:
            过滤后的文本，如 "吾爱 庐 事事 幽"
        """
        words = segmented_text.split()
        filtered_words = []
        
        for word in words:
            # 保留意象词和动作词
            if word in self.image_words or word in self.action_words:
                filtered_words.append(word)
            # 过滤停用词
            elif word not in self.stopwords:
                filtered_words.append(word)
        
        return ' '.join(filtered_words)
    
    def detect_poem_type(self, poem_line):
        """
        检测诗句类型（五言或七言）
        
        Args:
            poem_line: 单句诗，如 "大漠孤烟直"
        
        Returns:
            'wuyan' (五言) 或 'qiyan' (七言) 或 'other'
        """
        # 去除标点
        clean_line = re.sub(r'[，。！？；：、]', '', poem_line)
        length = len(clean_line)
        
        if length == 5:
            return 'wuyan'
        elif length == 7:
            return 'qiyan'
        else:
            return 'other'
    
    def extract_rhythm_features(self, poem_line, poem_type):
        """
        提取节奏特征
        
        五言诗: 2+3 节奏 (如 "大漠 / 孤烟直")
        七言诗: 2+2+3 节奏 (如 "劝君 / 更尽 / 一杯酒")
        
        Args:
            poem_line: 单句诗
            poem_type: 'wuyan' 或 'qiyan'
        
        Returns:
            10维 One-Hot 向量 (R1-R5 各占2维)
        """
        rhythm_vector = np.zeros(10)
        
        clean_line = re.sub(r'[，。！？；：、]', '', poem_line)
        
        if poem_type == 'wuyan' and len(clean_line) == 5:
            # 五言: 2+3 节奏
            # R2 出现在位置0 (索引0-1)
            rhythm_vector[2] = 1  # R2 第一次出现
            # R3 出现在位置1 (索引4-5)
            rhythm_vector[5] = 1  # R3 第一次出现
            
        elif poem_type == 'qiyan' and len(clean_line) == 7:
            # 七言: 2+2+3 节奏
            # R2 出现两次
            rhythm_vector[2] = 1  # R2 第一次
            rhythm_vector[3] = 1  # R2 第二次
            # R3 出现一次
            rhythm_vector[5] = 1  # R3 第一次
        
        return rhythm_vector
    
    def detect_duizhang(self, line1, line2, words1, words2):
        """
        检测对仗特征
        
        通过词性匹配识别对仗句
        如 "绿树村边合，青山郭外斜"
        
        Args:
            line1, line2: 两句诗文本
            words1, words2: 两句诗的分词结果（列表）
        
        Returns:
            对仗向量（1维二进制）
        """
        # 简化版对仗检测：检查词性是否匹配
        try:
            # 使用jieba词性标注
            pos1 = [(w.word, w.flag) for w in pseg.cut(line1)]
            pos2 = [(w.word, w.flag) for w in pseg.cut(line2)]
            
            # 如果两句词数相同，检查词性匹配度
            if len(pos1) == len(pos2) and len(pos1) >= 3:
                match_count = sum(1 for p1, p2 in zip(pos1, pos2) if p1[1] == p2[1])
                # 如果超过70%的词性匹配，认为是对仗
                if match_count / len(pos1) >= 0.7:
                    return np.array([1.0])
        except:
            pass
        
        return np.array([0.0])
    
    def extract_rhythm_features_for_poem(self, poem_text, segmented_lines):
        """
        为整首诗提取韵律特征
        
        Args:
            poem_text: 原始诗文，如 "吾爱吾庐事事幽|此生随分得优游"
            segmented_lines: 分词后的诗句列表
        
        Returns:
            韵律特征字典
        """
        lines = poem_text.split('|')
        rhythm_features = []
        duizhang_features = []
        
        for i, line in enumerate(lines):
            if not line.strip():
                continue
            
            # 检测诗句类型
            poem_type = self.detect_poem_type(line)
            
            # 提取节奏特征
            rhythm_vec = self.extract_rhythm_features(line, poem_type)
            rhythm_features.append(rhythm_vec)
            
            # 检测对仗（相邻两句）
            if i > 0 and i < len(lines):
                duizhang_vec = self.detect_duizhang(
                    lines[i-1], line,
                    segmented_lines[i-1] if i-1 < len(segmented_lines) else [],
                    segmented_lines[i] if i < len(segmented_lines) else []
                )
            else:
                duizhang_vec = np.array([0.0])
            
            duizhang_features.append(duizhang_vec)
        
        # 平均所有句子的特征作为整首诗的特征
        if rhythm_features:
            avg_rhythm = np.mean(rhythm_features, axis=0)
        else:
            avg_rhythm = np.zeros(10)
        
        if duizhang_features:
            avg_duizhang = np.mean(duizhang_features, axis=0)
        else:
            avg_duizhang = np.array([0.0])
        
        # 拼接为11维向量
        rhythm_vector_11d = np.concatenate([avg_rhythm, avg_duizhang])
        
        return {
            'rhythm_vector': rhythm_vector_11d.tolist(),
            'rhythm_dim': 10,
            'duizhang_dim': 1,
            'total_dim': 11
        }
    
    def preprocess_dataset(self, input_file, output_file):
        """
        预处理整个数据集
        
        Args:
            input_file: 输入文件（poems_jieba_merged.json）
            output_file: 输出文件
        """
        print("=" * 70)
        print("古诗数据预处理")
        print("=" * 70)
        
        # 读取数据
        print(f"\n读取数据: {input_file}")
        with open(input_file, 'r', encoding='utf-8') as f:
            poems = json.load(f)
        
        print(f"共 {len(poems)} 首古诗")
        
        # 预处理
        print("\n开始预处理...")
        processed_poems = []
        
        for poem in tqdm(poems, desc="预处理进度"):
            try:
                # 1. 停用词过滤
                if 'segmented_poem_jieba' in poem:
                    segmented_text = poem['segmented_poem_jieba']
                    
                    # 按句子分割
                    segmented_lines = segmented_text.split('|')
                    
                    # 对每句进行停用词过滤
                    filtered_lines = [
                        self.filter_stopwords(line) 
                        for line in segmented_lines
                    ]
                    
                    # 合并
                    filtered_text = '|'.join(filtered_lines)
                    
                    # 2. 提取韵律特征
                    rhythm_features = self.extract_rhythm_features_for_poem(
                        poem['poem'], 
                        [line.split() for line in filtered_lines]
                    )
                    
                    # 3. 保存结果
                    processed_poem = poem.copy()
                    processed_poem['segmented_filtered'] = filtered_text
                    processed_poem['rhythm_features'] = rhythm_features
                    
                    processed_poems.append(processed_poem)
                else:
                    # 没有分词结果，跳过
                    continue
                    
            except Exception as e:
                print(f"\n处理出错: {poem.get('title', 'Unknown')} - {e}")
                continue
        
        # 保存结果
        print(f"\n保存处理后的数据: {output_file}")
        with open(output_file, 'w', encoding='utf-8') as f:
            json.dump(processed_poems, f, ensure_ascii=False, indent=2)
        
        # 统计信息
        print("\n" + "=" * 70)
        print("预处理统计:")
        print("=" * 70)
        print(f"成功处理: {len(processed_poems)} 首")
        print(f"失败/跳过: {len(poems) - len(processed_poems)} 首")
        
        # 显示示例
        if processed_poems:
            print("\n" + "=" * 70)
            print("预处理示例（前3首）:")
            print("=" * 70)
            
            for i, poem in enumerate(processed_poems[:3], 1):
                print(f"\n【示例 {i}】")
                print(f"标题: {poem['title']}")
                print(f"诗人: {poem['poet']}")
                print(f"朝代: {poem['dynasty']}")
                if 'theme' in poem:
                    print(f"题材: {poem['theme']}")
                print(f"\n原始分词:")
                print(f"  {poem.get('segmented_poem_jieba', '')[:80]}...")
                print(f"\n停用词过滤后:")
                print(f"  {poem.get('segmented_filtered', '')[:80]}...")
                print(f"\n韵律特征向量 (11维):")
                rhythm_vec = poem['rhythm_features']['rhythm_vector']
                print(f"  {[f'{x:.2f}' for x in rhythm_vec]}")
        
        print("\n" + "=" * 70)
        print("预处理完成！")
        print("=" * 70)


if __name__ == '__main__':
    # 初始化预处理器
    preprocessor = PoetryPreprocessor('古诗停用词表.txt')
    
    # 预处理数据集
    preprocessor.preprocess_dataset(
        input_file='poems_jieba_merged.json',
        output_file='poems_preprocessed.json'
    )


