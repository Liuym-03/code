import json
import re
from collections import Counter
from wordcloud import WordCloud
import matplotlib.pyplot as plt
import numpy as np
from PIL import Image, ImageOps

# ===== 配置 =====
file_path = r"D:\pythonproject66666\pythonProject\poems_jieba_merged.json"

# 人物与头像图片路径（白底、黑色人物）
poet_masks = {
    "李白": r"D:\pythonproject66666\pythonProject\mask_libai.png",
    "白居易": r"D:\pythonproject66666\pythonProject\mask_bai.png"
}

# 中文字体路径（推荐楷体）
font_path = r"C:\Windows\Fonts\STKAITI.TTF"

# 匹配恰好两个汉字
_cn2_re = re.compile(r'^[\u4e00-\u9fff]{2}$')

# 常用停用词
stopwords = {
    "之", "其", "也", "于", "不", "无", "人", "我", "你", "他", "此", "已", "为",
    "有", "且", "者", "中", "来", "去"
}

# ===== 读取数据 =====
with open(file_path, "r", encoding="utf-8") as f:
    data = json.load(f)

# ===== 提取“李白”“白居易”的诗句 =====
poets = ["李白", "白居易"]
poet_counters = {p: Counter() for p in poets}

for item in data:
    poet = item.get("poet", "")
    if poet not in poets:
        continue
    seg = item.get("segmented_poem_jieba") or item.get("segmented") or ""
    tokens = seg.replace("|", " ").split()
    for tok in tokens:
        tok = tok.strip()
        if _cn2_re.match(tok) and tok not in stopwords:
            poet_counters[poet][tok] += 1

# ===== 生成词云（去除轮廓线 & 干净mask）=====
for poet, counter in poet_counters.items():
    if not counter:
        print(f"⚠️ 未找到 {poet} 的词数据，跳过。")
        continue

    print(f"正在为 {poet} 生成人物词云，二字词数={len(counter)}")

    # 读取人物头像遮罩图
    mask_path = poet_masks[poet]
    mask_img = Image.open(mask_path).convert("L")

    # 如果人物是白色、背景是黑色，可取消下面注释进行反转
    # mask_img = ImageOps.invert(mask_img)

    # 二值化（去除灰度导致的外轮廓线）
    mask_arr = np.array(mask_img)
    mask_bin = np.where(mask_arr > 128, 255, 0).astype(np.uint8)

    # 如果你的词云出现在背景上（人物空白），说明反了，取消下面注释：
    # mask_bin = 255 - mask_bin

    # 生成词云（无轮廓线）
    wc = WordCloud(
        font_path=font_path,
        background_color="white",
        max_words=150,
        mask=mask_bin,
        max_font_size=180,
        min_font_size=10,
        relative_scaling=0.6,
        scale=6,
        collocations=False,
        contour_width=0,      # 🚫 不再绘制外层轮廓
        contour_color=None
    ).generate_from_frequencies(counter)

    # 展示
    plt.figure(figsize=(8, 8))
    plt.imshow(wc, interpolation="bilinear")
    plt.axis("off")
    plt.title(f"{poet}诗集（二字词人物词云）", fontsize=18)
    plt.tight_layout()
    plt.show()

    # 保存
    out_path = rf"D:\pythonproject66666\pythonProject\{poet}_人物词云.png"
    wc.to_file(out_path)
    print(f"✅ 已保存：{out_path}")

print("✅ 全部人物词云生成完成（无外轮廓版）！")
