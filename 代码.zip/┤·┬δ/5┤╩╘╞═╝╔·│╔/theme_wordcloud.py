import json
import re
from collections import defaultdict, Counter
from wordcloud import WordCloud
import matplotlib.pyplot as plt

# ===== 配置 =====
file_path = r"D:\pythonproject66666\pythonProject\poems_jieba_merged.json"
themes = ["爱情婚姻", "咏史怀古", "羁旅思乡", "山水田园", "交友送别", "边塞战争"]
font_path = r"C:\Windows\Fonts\STKAITI.TTF" # 根据你的系统改：Windows 常用 msyh.ttc，mac/linux 请写相应路径

# 可调整的停用词（示例，可扩展）
stopwords = {
    "之", "其", "也", "于", "不", "无", "人", "我", "你", "他", "此", "已", "为",
    "有", "且", "若", "且", "者", "中", "若", "来", "去"
}

# 用于判断“纯中文”（过滤掉包含英数字或标点的 token）
_cn_re = re.compile(r'^[\u4e00-\u9fff]{2}$')  # 精确匹配两个汉字

# ===== 读取 JSON =====
with open(file_path, "r", encoding="utf-8") as f:
    data = json.load(f)

# ===== 按主题统计二字词频 =====
theme_counters = {t: Counter() for t in themes}

for item in data:
    theme = item.get("theme", "")
    if theme not in themes:
        continue
    seg = item.get("segmented_poem_jieba") or item.get("segmented") or ""
    # 先把竖线替成空格、再切分
    tokens = seg.replace("|", " ").split()
    for tok in tokens:
        tok = tok.strip()
        if not tok:
            continue
        # 只保留恰好两个中文字符的 token，并排除停用词
        if _cn_re.match(tok) and tok not in stopwords:
            theme_counters[theme][tok] += 1

# ===== 生成词云（按频率）=====
for theme, counter in theme_counters.items():
    if not counter:
        print(f"注意：主题 `{theme}` 没有符合条件的二字词，跳过。")
        continue

    print(f"正在为主题 `{theme}` 生成词云，独特二字词数：{len(counter)}，总词频：{sum(counter.values())}")

    # 生成词云（使用频率字典）
    wc = WordCloud(
        font_path=font_path,
        width=500,
        height=500,
        background_color="white",
        max_words=200,
        collocations=False,
        max_font_size=100,  # ← 最大字号
        min_font_size=15,  # ← 最小字号（可选）
        relative_scaling=0.4,  # ← 词频对字号影响
        scale=6  # ← 提高清晰度（选配）
    ).generate_from_frequencies(counter)

    # 显示
    plt.figure(figsize=(10, 8))
    plt.imshow(wc, interpolation="bilinear")
    plt.axis("off")
    plt.title(f"{theme}（仅二字词）", fontsize=18)
    plt.tight_layout()
    plt.show()

    # 保存
    out_fname = f"{theme}_2char_wordcloud.png"
    wc.to_file(out_fname)
    print(f"已保存：{out_fname}")

print("✅ 完成（每个题材的二字词词云已生成并保存）。")
