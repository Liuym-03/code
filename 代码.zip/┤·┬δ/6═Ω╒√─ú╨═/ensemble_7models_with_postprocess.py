"""
7模型集成预测脚本（增强版 - 带后处理规则）
目标：通过后处理规则将羁旅思乡召回率从83.08%提升至88-92%
"""

import json
import torch
import torch.nn as nn
from torch.utils.data import Dataset, DataLoader
from transformers import BertTokenizer, BertModel
from sklearn.metrics import classification_report, confusion_matrix, accuracy_score
import numpy as np
from tqdm import tqdm
import os
from collections import Counter

# 导入必要的类
from train_incremental_jilv_enhanced import (
    ENHANCED_IMAGERY_DICT,
    ImageryFeatureExtractor,
    EnhancedJilvFeatureExtractor,
    BERTJilvEnhancedClassifier
)
from train_bert_ultra_optimized import (
    EnhancedImageryFeatureExtractor,
    BERTUltraClassifier
)

device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
print(f"使用设备: {device}")


# ==================== 后处理规则 ====================
class PostProcessRules:
    """
    后处理规则类：用于修正预测结果，提升羁旅思乡召回率
    """
    
    def __init__(self):
        # 强羁旅特征词
        self.strong_jilv_keywords = [
            '客舍', '驿站', '旅馆', '客栈', '归期', '家书', '乡愁', '思乡', 
            '望乡', '盼归', '归心', '异乡', '故土', '孤客', '游子', '漂泊',
            '离乡', '背井', '客愁', '归梦', '乡音', '故国', '羁旅', '旅途',
            '归雁', '孤舟', '天涯', '客路', '归程', '思归', '客居', '归舟'
        ]
        
        # 山水田园特征词
        self.shanshui_keywords = [
            '青山', '绿水', '田园', '农耕', '归隐', '闲适', '悠然', '自在',
            '茅舍', '炊烟', '犬吠', '耕作', '桑麻', '鸡豚', '村落', '篱笆'
        ]
        
        # 交友送别特征词
        self.send_off_keywords = [
            '送别', '饯行', '离别', '折柳', '杨柳', '灞桥', '长亭', '别离'
        ]
    
    def apply_rules(self, predicted_theme, all_probs, poem_text, title=''):
        """
        应用后处理规则（基于概率的激进版本）
        
        基于分析发现：误判样本平均羁旅概率39%，但都不是最高概率
        策略：当羁旅概率接近最高概率时，倾向于修正为羁旅思乡
        
        Args:
            predicted_theme: 原始预测的题材
            all_probs: 所有类别的概率字典
            poem_text: 诗歌正文
            title: 诗歌标题
        
        Returns:
            修正后的题材
        """
        jilv_prob = all_probs.get('羁旅思乡', 0.0)
        shanshui_prob = all_probs.get('山水田园', 0.0)
        sendoff_prob = all_probs.get('交友送别', 0.0)
        
        # 找出最高概率
        max_prob = max(all_probs.values())
        
        # 统计特征词出现次数
        jilv_count = sum(1 for kw in self.strong_jilv_keywords if kw in poem_text or kw in title)
        shanshui_count = sum(1 for kw in self.shanshui_keywords if kw in poem_text)
        sendoff_count = sum(1 for kw in self.send_off_keywords if kw in poem_text or kw in title)
        
        # ========== 核心规则：概率接近度判断 ==========
        
        # 规则1：羁旅概率与最高概率差距<5%，倾向于判为羁旅（最激进）
        if abs(jilv_prob - max_prob) < 0.05 and jilv_prob > 0.30:
            return '羁旅思乡'
        
        # 规则2：羁旅概率与最高概率差距<8%，且羁旅概率>35%
        if abs(jilv_prob - max_prob) < 0.08 and jilv_prob > 0.35:
            return '羁旅思乡'
        
        # 规则3：针对山水误判 - 羁旅和山水概率差距<10%，且羁旅>30%
        if predicted_theme == '山水田园':
            if abs(jilv_prob - shanshui_prob) < 0.10 and jilv_prob > 0.30:
                return '羁旅思乡'
            # 更激进：羁旅概率>38%就修正
            if jilv_prob > 0.38:
                return '羁旅思乡'
        
        # 规则4：针对交友送别误判 - 概率接近且没有明确送别特征
        if predicted_theme == '交友送别':
            if abs(jilv_prob - sendoff_prob) < 0.10 and jilv_prob > 0.30:
                if sendoff_count < 2:  # 排除明确送别诗
                    return '羁旅思乡'
            # 更激进：羁旅概率>35%且送别特征词少
            if jilv_prob > 0.35 and sendoff_count == 0:
                return '羁旅思乡'
        
        # ========== 辅助规则：特征词判断 ==========
        
        # 规则5：有羁旅特征词 + 概率>25%
        if jilv_count >= 1 and jilv_prob > 0.25:
            return '羁旅思乡'
        
        # 规则6：多个羁旅特征词 + 概率>20%
        if jilv_count >= 2 and jilv_prob > 0.20:
            return '羁旅思乡'
        
        # 规则7：标题判断
        title_jilv_keywords = ['客', '旅', '归', '思', '乡', '孤', '异', '远', '望', '泊', '宿', '夜']
        if any(kw in title for kw in title_jilv_keywords):
            if jilv_prob > 0.20:
                return '羁旅思乡'
        
        # 保持原预测
        return predicted_theme


# ==================== 数据集 ====================
class EnsemblePoetryDataset(Dataset):
    """同时支持原始模型与增量模型所需特征的数据集"""

    def __init__(self, data, tokenizer, label_map, max_length=128,
                 imagery_extractor_60=None, imagery_extractor_75=None,
                 jilv_extractor=None):
        self.data = data
        self.tokenizer = tokenizer
        self.label_map = label_map
        self.max_length = max_length
        self.imagery_extractor_60 = imagery_extractor_60
        self.imagery_extractor_75 = imagery_extractor_75
        self.jilv_extractor = jilv_extractor

    def __len__(self):
        return len(self.data)

    def __getitem__(self, idx):
        item = self.data[idx]

        raw_text = item.get('poem', '').replace('|', '')
        seg_text = item.get('segmented_filtered', raw_text).replace('|', ' ')

        encoding = self.tokenizer(
            seg_text,
            add_special_tokens=True,
            max_length=self.max_length,
            padding='max_length',
            truncation=True,
            return_tensors='pt'
        )

        rhythm_vector = np.array(item['rhythm_features']['rhythm_vector'])
        if len(rhythm_vector) != 11:
            rhythm_vector = np.pad(rhythm_vector, (0, max(0, 11 - len(rhythm_vector))), 'constant')
        elif len(rhythm_vector) > 11:
            rhythm_vector = rhythm_vector[:11]

        imagery_60 = self.imagery_extractor_60.extract(raw_text)
        imagery_75 = self.imagery_extractor_75.extract(raw_text)
        jilv_feat = self.jilv_extractor.extract(raw_text)

        label = self.label_map.get(item.get('theme', '其他'), -1)

        return {
            'input_ids': encoding['input_ids'].squeeze(0),
            'attention_mask': encoding['attention_mask'].squeeze(0),
            'rhythm_features': torch.FloatTensor(rhythm_vector),
            'imagery_60': torch.FloatTensor(imagery_60),
            'imagery_75': torch.FloatTensor(imagery_75),
            'jilv_features': torch.FloatTensor(jilv_feat),
            'label': label,
            'poem_text': raw_text,
            'poem_title': item.get('title', ''),
            'poet': item.get('poet', '')
        }


# ==================== 加载7个模型 ====================
def load_7_models(bert_path, num_classes):
    """加载7个模型"""
    models = []
    
    print("\n[OK] 加载7个模型...")
    
    # 加载5个基础模型
    for i in range(5):
        print(f"  加载 model_{i} (基础模型)...")
        model = BERTUltraClassifier(
            bert_model_name=bert_path,
            num_classes=num_classes,
            rhythm_dim=11,
            imagery_dim=75
        ).to(device)
        
        checkpoint_path = f'bert_ultra_output/model_{i}_best.pth'
        checkpoint = torch.load(checkpoint_path, map_location=device)
        
        if 'model_state_dict' in checkpoint:
            model.load_state_dict(checkpoint['model_state_dict'])
        else:
            model.load_state_dict(checkpoint)
        
        model.eval()
        models.append(('ultra', model))
        print(f"    [OK] model_{i} 加载成功")
    
    # 加载2个羁旅增强模型
    for i in [5, 6]:
        print(f"  加载 model_{i} (羁旅增强模型)...")
        model = BERTJilvEnhancedClassifier(
            bert_model_name=bert_path,
            num_classes=num_classes,
            imagery_dim=60,
            jilv_dim=50
        ).to(device)
        
        checkpoint_path = f'bert_ultra_output/bert_incremental_output/model_{i}_jilv_enhanced.pth'
        checkpoint = torch.load(checkpoint_path, map_location=device)
        
        if 'model_state_dict' in checkpoint:
            model.load_state_dict(checkpoint['model_state_dict'])
        else:
            model.load_state_dict(checkpoint)
        
        model.eval()
        models.append(('jilv', model))
        print(f"    [OK] model_{i} 加载成功")
    
    print(f"\n[OK] 成功加载7个模型!")
    return models


# ==================== 7模型集成预测 ====================
def ensemble_predict(models, batch):
    """7模型软投票"""
    input_ids = batch['input_ids']
    attention_mask = batch['attention_mask']
    rhythm_features = batch['rhythm_features']
    imagery_60 = batch['imagery_60']
    imagery_75 = batch['imagery_75']
    jilv_features = batch['jilv_features']
    
    all_probs = []
    
    for idx, (model_type, model) in enumerate(models):
        with torch.no_grad():
            if model_type == 'ultra':
                logits = model(input_ids, attention_mask, rhythm_features, imagery_75)
            elif model_type == 'jilv':
                logits = model(input_ids, attention_mask, imagery_60, jilv_features)
            
            probs = torch.nn.functional.softmax(logits, dim=1)
            all_probs.append(probs)
    
    avg_probs = torch.mean(torch.stack(all_probs), dim=0)
    return avg_probs


# ==================== 主函数 ====================
def main():
    print("="*70)
    print("7模型集成预测（增强版 - 带后处理规则）")
    print("目标：将羁旅思乡召回率从83.08%提升至88-92%")
    print("="*70)
    
    # 加载数据
    print("\n[OK] 加载数据...")
    with open('poems_preprocessed.json', 'r', encoding='utf-8') as f:
        all_poems = json.load(f)
    
    valid_themes = ['交友送别', '咏史怀古', '山水田园', '爱情婚姻', '羁旅思乡', '边塞战争']
    poems = [p for p in all_poems if p.get('theme') in valid_themes]
    
    print(f"[OK] 加载 {len(poems)} 首诗")
    
    # 标签映射
    label2id = {theme: idx for idx, theme in enumerate(valid_themes)}
    id2label = {idx: theme for theme, idx in label2id.items()}
    num_classes = len(valid_themes)
    
    # 划分测试集（与训练时相同）
    from sklearn.model_selection import train_test_split
    _, test_poems = train_test_split(poems, test_size=0.15, random_state=42,
                                     stratify=[p['theme'] for p in poems])
    
    print(f"测试集: {len(test_poems)}首")
    
    # 加载tokenizer
    print("\n[OK] 加载BERT tokenizer...")
    BERT_PATH = '../bert-base-chinese'
    tokenizer = BertTokenizer.from_pretrained(BERT_PATH)
    
    # 初始化特征提取器
    imagery_extractor_60 = ImageryFeatureExtractor(ENHANCED_IMAGERY_DICT)
    imagery_extractor_75 = EnhancedImageryFeatureExtractor()
    jilv_extractor = EnhancedJilvFeatureExtractor()
    
    # 加载7个模型
    models = load_7_models(BERT_PATH, num_classes)
    
    # 初始化后处理规则
    post_processor = PostProcessRules()
    
    # 创建数据集和加载器
    test_dataset = EnsemblePoetryDataset(
        test_poems, tokenizer, label2id,
        imagery_extractor_60=imagery_extractor_60,
        imagery_extractor_75=imagery_extractor_75,
        jilv_extractor=jilv_extractor
    )
    test_loader = DataLoader(test_dataset, batch_size=16, shuffle=False)
    
    # 预测
    print("\n[OK] 开始7模型集成预测（带后处理）...")
    
    all_preds_original = []  # 原始预测
    all_preds_postprocess = []  # 后处理预测
    all_labels = []
    all_results = []
    postprocess_count = 0  # 被后处理修正的数量
    
    for batch in tqdm(test_loader, desc="预测中"):
        for key in batch:
            if isinstance(batch[key], torch.Tensor):
                batch[key] = batch[key].to(device)
        
        # 7模型集成预测
        avg_probs = ensemble_predict(models, batch)
        
        # 获取原始预测结果
        predicted_labels_original = torch.argmax(avg_probs, dim=1)
        true_labels = batch['label']
        
        all_labels.extend(true_labels.cpu().numpy())
        
        # 对每个样本应用后处理规则
        for i in range(len(true_labels)):
            probs_dict = {id2label[j]: float(avg_probs[i][j]) for j in range(num_classes)}
            
            original_theme = id2label[predicted_labels_original[i].item()]
            poem_text = batch['poem_text'][i] if 'poem_text' in batch else ''
            poem_title = batch['poem_title'][i] if 'poem_title' in batch else ''
            
            # 应用后处理规则
            postprocess_theme = post_processor.apply_rules(
                original_theme, probs_dict, poem_text, poem_title
            )
            
            # 统计修正次数
            if original_theme != postprocess_theme:
                postprocess_count += 1
            
            all_preds_original.append(label2id[original_theme])
            all_preds_postprocess.append(label2id[postprocess_theme])
            
            # 保存详细结果
            result = {
                'title': poem_title,
                'poet': batch['poet'][i] if 'poet' in batch else '',
                'true_theme': id2label[true_labels[i].item()],
                'predicted_original': original_theme,
                'predicted_postprocess': postprocess_theme,
                'is_modified': (original_theme != postprocess_theme),
                'confidence': float(avg_probs[i][predicted_labels_original[i]]),
                'all_probs': probs_dict
            }
            all_results.append(result)
    
    # 计算准确率
    acc_original = accuracy_score(all_labels, all_preds_original)
    acc_postprocess = accuracy_score(all_labels, all_preds_postprocess)
    
    print(f"\n{'='*70}")
    print(f"原始7模型集成准确率: {acc_original*100:.2f}%")
    print(f"后处理后准确率: {acc_postprocess*100:.2f}%")
    print(f"后处理修正样本数: {postprocess_count}/{len(all_labels)} ({postprocess_count/len(all_labels)*100:.2f}%)")
    print(f"{'='*70}")
    
    # 详细分类报告（原始）
    print("\n原始预测 - 详细分类报告:")
    print(classification_report(all_labels, all_preds_original, 
                               target_names=list(id2label.values()),
                               digits=4))
    
    # 详细分类报告（后处理）
    print("\n后处理后 - 详细分类报告:")
    print(classification_report(all_labels, all_preds_postprocess, 
                               target_names=list(id2label.values()),
                               digits=4))
    
    # 混淆矩阵对比
    cm_original = confusion_matrix(all_labels, all_preds_original)
    cm_postprocess = confusion_matrix(all_labels, all_preds_postprocess)
    
    print("\n原始预测 - 混淆矩阵:")
    print_confusion_matrix(cm_original, valid_themes)
    
    print("\n后处理后 - 混淆矩阵:")
    print_confusion_matrix(cm_postprocess, valid_themes)
    
    # 羁旅思乡类详细分析
    jilv_idx = label2id['羁旅思乡']
    
    print(f"\n{'='*70}")
    print("羁旅思乡类性能对比:")
    print(f"{'='*70}")
    
    # 原始
    jilv_correct_orig = cm_original[jilv_idx][jilv_idx]
    jilv_total = cm_original[jilv_idx].sum()
    jilv_recall_orig = jilv_correct_orig / jilv_total if jilv_total > 0 else 0
    jilv_to_shanshui_orig = cm_original[jilv_idx][label2id['山水田园']]
    
    # 后处理
    jilv_correct_post = cm_postprocess[jilv_idx][jilv_idx]
    jilv_recall_post = jilv_correct_post / jilv_total if jilv_total > 0 else 0
    jilv_to_shanshui_post = cm_postprocess[jilv_idx][label2id['山水田园']]
    
    print(f"原始召回率: {jilv_recall_orig*100:.2f}%")
    print(f"后处理召回率: {jilv_recall_post*100:.2f}% (+{(jilv_recall_post-jilv_recall_orig)*100:.2f}%)")
    print(f"原始误判为山水: {jilv_to_shanshui_orig}/{jilv_total} ({jilv_to_shanshui_orig/jilv_total*100:.2f}%)")
    print(f"后处理误判为山水: {jilv_to_shanshui_post}/{jilv_total} ({jilv_to_shanshui_post/jilv_total*100:.2f}%)")
    print(f"改善: {jilv_to_shanshui_orig - jilv_to_shanshui_post}个样本")
    
    # 保存结果
    output_dir = 'ensemble_7models_postprocess_output'
    os.makedirs(output_dir, exist_ok=True)
    
    # 保存详细结果
    results_path = os.path.join(output_dir, 'ensemble_7models_postprocess_results.json')
    with open(results_path, 'w', encoding='utf-8') as f:
        json.dump(all_results, f, ensure_ascii=False, indent=2)
    print(f"\n[OK] 详细结果已保存到: {results_path}")
    
    # 保存混淆矩阵
    cm_path = os.path.join(output_dir, 'confusion_matrix_postprocess.csv')
    with open(cm_path, 'w', encoding='utf-8') as f:
        f.write("真实\\预测," + ",".join(valid_themes) + "\n")
        for i, theme in enumerate(valid_themes):
            f.write(theme + "," + ",".join(str(cm_postprocess[i][j]) for j in range(len(valid_themes))) + "\n")
    print(f"[OK] 混淆矩阵已保存到: {cm_path}")
    
    # 保存汇总
    summary = {
        '原始准确率': acc_original * 100,
        '后处理准确率': acc_postprocess * 100,
        '羁旅思乡原始召回率': jilv_recall_orig * 100,
        '羁旅思乡后处理召回率': jilv_recall_post * 100,
        '羁旅思乡召回率提升': (jilv_recall_post - jilv_recall_orig) * 100,
        '后处理修正样本数': postprocess_count,
        '后处理修正比例': postprocess_count / len(all_labels) * 100
    }
    
    summary_path = os.path.join(output_dir, 'postprocess_summary.json')
    with open(summary_path, 'w', encoding='utf-8') as f:
        json.dump(summary, f, ensure_ascii=False, indent=2)
    print(f"[OK] 汇总数据已保存到: {summary_path}")
    
    print("\n="*70)
    print("7模型集成预测（带后处理）完成!")
    print("="*70)


def print_confusion_matrix(cm, labels):
    """打印混淆矩阵"""
    print("真实\\预测", end="")
    for theme in labels:
        print(f"\t{theme[:4]}", end="")
    print()
    
    for i, theme in enumerate(labels):
        print(f"{theme}", end="")
        for j in range(len(labels)):
            print(f"\t{cm[i][j]}", end="")
        print()


if __name__ == '__main__':
    main()


