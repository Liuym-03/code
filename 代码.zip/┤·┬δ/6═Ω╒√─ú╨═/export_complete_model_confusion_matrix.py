"""
导出完整模型（7模型集成+后处理）的混淆矩阵为Origin可读取格式
"""

import json
import numpy as np
from sklearn.metrics import confusion_matrix
import os

# 加载后处理结果
print("="*70)
print("完整模型（7模型集成+后处理）混淆矩阵导出")
print("="*70)

results_path = 'ensemble_7models_postprocess_output/ensemble_7models_postprocess_results.json'
print(f"\n[1/5] 加载结果文件: {results_path}")

with open(results_path, 'r', encoding='utf-8') as f:
    results = json.load(f)

print(f"[OK] 已加载 {len(results)} 个预测结果")

# 提取真实标签和预测标签
valid_themes = ['交友送别', '咏史怀古', '山水田园', '爱情婚姻', '羁旅思乡', '边塞战争']
label2id = {theme: idx for idx, theme in enumerate(valid_themes)}

true_labels = []
pred_labels = []

for result in results:
    true_theme = result['true_theme']
    pred_theme = result['predicted_postprocess']  # 使用后处理后的预测
    
    if true_theme in valid_themes and pred_theme in valid_themes:
        true_labels.append(label2id[true_theme])
        pred_labels.append(label2id[pred_theme])

print(f"[OK] 提取了 {len(true_labels)} 个有效样本")

# 计算混淆矩阵
print("\n[2/5] 计算混淆矩阵...")
cm = confusion_matrix(true_labels, pred_labels)
print(f"[OK] 混淆矩阵形状: {cm.shape}")

# 输出目录
output_dir = 'complete_model_confusion_matrix_output'
os.makedirs(output_dir, exist_ok=True)

# ========== 格式1：标准CSV格式 ==========
print("\n[3/5] 导出格式1: 标准CSV格式")
csv_path = os.path.join(output_dir, 'complete_model_confusion_matrix.csv')

with open(csv_path, 'w', encoding='utf-8') as f:
    # 写入表头
    f.write("真实\\预测," + ",".join(valid_themes) + "\n")
    
    # 写入数据
    for i, theme in enumerate(valid_themes):
        row_data = [str(cm[i][j]) for j in range(len(valid_themes))]
        f.write(theme + "," + ",".join(row_data) + "\n")

print(f"[OK] 已保存: {csv_path}")

# ========== 格式2：Origin矩阵格式（带标签） ==========
print("\n[4/5] 导出格式2: Origin矩阵格式")
origin_path = os.path.join(output_dir, 'complete_model_confusion_matrix_origin.txt')

with open(origin_path, 'w', encoding='utf-8') as f:
    # Origin可以直接识别的矩阵格式
    # 第一行：列标签
    f.write("\t" + "\t".join(valid_themes) + "\n")
    
    # 数据行：行标签 + 数据
    for i, theme in enumerate(valid_themes):
        row_data = [str(cm[i][j]) for j in range(len(valid_themes))]
        f.write(theme + "\t" + "\t".join(row_data) + "\n")

print(f"[OK] 已保存: {origin_path}")

# ========== 格式3：归一化混淆矩阵（百分比） ==========
print("\n[5/5] 导出格式3: 归一化混淆矩阵（百分比）")

# 按行归一化（每行的真实样本总数）
cm_normalized = cm.astype('float') / cm.sum(axis=1)[:, np.newaxis] * 100

normalized_csv_path = os.path.join(output_dir, 'complete_model_confusion_matrix_normalized.csv')

with open(normalized_csv_path, 'w', encoding='utf-8') as f:
    # 写入表头
    f.write("真实\\预测," + ",".join(valid_themes) + "\n")
    
    # 写入数据（保留2位小数）
    for i, theme in enumerate(valid_themes):
        row_data = [f"{cm_normalized[i][j]:.2f}" for j in range(len(valid_themes))]
        f.write(theme + "," + ",".join(row_data) + "\n")

print(f"[OK] 已保存: {normalized_csv_path}")

# ========== 格式4：详细统计信息（JSON） ==========
print("\n[附加] 生成详细统计信息...")

summary = {
    "模型名称": "完整模型（7模型集成+后处理）",
    "测试样本数": len(true_labels),
    "类别数": len(valid_themes),
    "类别列表": valid_themes,
    "混淆矩阵": cm.tolist(),
    "各类别统计": {}
}

for i, theme in enumerate(valid_themes):
    true_count = cm[i].sum()  # 该类别真实样本数
    pred_correct = cm[i][i]   # 正确预测数
    
    # 计算该类别的精确率和召回率
    precision = cm[i][i] / max(cm[:, i].sum(), 1) * 100  # 预测为该类的正确率
    recall = cm[i][i] / max(cm[i].sum(), 1) * 100        # 真实为该类的识别率
    
    summary["各类别统计"][theme] = {
        "真实样本数": int(true_count),
        "正确预测数": int(pred_correct),
        "召回率": round(recall, 2),
        "精确率": round(precision, 2)
    }

summary_path = os.path.join(output_dir, 'complete_model_confusion_matrix_summary.json')
with open(summary_path, 'w', encoding='utf-8') as f:
    json.dump(summary, f, ensure_ascii=False, indent=2)

print(f"[OK] 已保存: {summary_path}")

# ========== 打印混淆矩阵预览 ==========
print("\n" + "="*70)
print("完整模型混淆矩阵预览:")
print("="*70)
print("\n真实\\预测", end="")
for theme in valid_themes:
    print(f"\t{theme[:4]}", end="")
print()

for i, theme in enumerate(valid_themes):
    print(f"{theme}", end="")
    for j in range(len(valid_themes)):
        print(f"\t{cm[i][j]}", end="")
    print()

print("\n" + "="*70)
print("文件导出完成!")
print("="*70)
print(f"\n输出目录: {output_dir}/")
print(f"  - complete_model_confusion_matrix.csv (标准CSV)")
print(f"  - complete_model_confusion_matrix_origin.txt (Origin矩阵格式)")
print(f"  - complete_model_confusion_matrix_normalized.csv (归一化百分比)")
print(f"  - complete_model_confusion_matrix_summary.json (详细统计)")
print("\n[提示] 可直接将.csv或.txt文件导入Origin进行绘图")
print("="*70)


