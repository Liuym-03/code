"""
羁旅思乡类深度增强 - 增量训练脚本
基于现有5个模型，训练2个羁旅思乡深度增强模型，组成7模型集成

优化措施：
1. 羁旅思乡意象词库：50 → 150个
2. 增强羁旅与山水区分特征（离别情感+时空距离+归乡意愿）
3. 数据增强：过采样到2000首 + 500合成样本
4. Focal Loss gamma=2.5，羁旅思乡类权重×1.5
"""

import json
import torch
import torch.nn as nn
import torch.nn.functional as F
from torch.utils.data import Dataset, DataLoader
from torch.optim import AdamW
from transformers import BertTokenizer, BertModel, get_cosine_schedule_with_warmup
from sklearn.model_selection import train_test_split
from sklearn.metrics import classification_report, confusion_matrix, accuracy_score
import numpy as np
from tqdm import tqdm
import os
import random
from collections import Counter
import sys

# 设置随机种子
def set_seed(seed=42):
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(seed)

set_seed(42)

# ==================== 1. 扩展羁旅思乡意象词库到150个 ====================
ENHANCED_IMAGERY_DICT = {
    '交友送别': [
        '送别', '离别', '相送', '饯行', '握手', '挥泪', '惜别', '分手',
        '道别', '告别', '辞行', '远行', '征途', '归期', '折柳', '阳关',
        '长亭', '短亭', '别离', '分袂', '握别', '话别', '送行', '践行'
    ],
    
    '咏史怀古': [
        '古迹', '遗址', '故宫', '废墟', '碑碣', '陵墓', '古城', '兴亡',
        '盛衰', '古今', '往事', '前朝', '旧事', '史迹', '汉唐', '秦汉',
        '六朝', '三国', '古人', '先贤', '英雄', '豪杰', '王侯', '将相'
    ],
    
    '山水田园': [
        '山水', '田园', '溪流', '峰峦', '林泉', '农舍', '桑麻', '耕作',
        '播种', '收获', '牧童', '渔翁', '茅舍', '竹篱', '村落', '炊烟',
        '鸡犬', '桑田', '稻香', '麦浪', '菜畦', '篱笆', '井台', '池塘'
    ],
    
    '爱情婚姻': [
        '相思', '情郎', '佳人', '红颜', '美人', '郎君', '夫君', '恩爱',
        '缠绵', '幽会', '约会', '信物', '定情', '婚姻', '闺怨', '思妇',
        '征夫', '离恨', '春闺', '独守', '望夫', '盼归', '泪痕', '愁眉'
    ],
    
    '羁旅思乡': [
        # 第一部分：基础羁旅词（30个）
        '客舍', '旅馆', '孤客', '归心', '家书', '游子', '异乡', '故土',
        '旅途', '归雁', '乡愁', '孤舟', '天涯', '羁旅', '思归',
        '客路', '归期', '乡音', '故国', '客愁', '归梦', '乡关',
        '旅人', '归程', '思乡', '客居', '归舟', '乡土', '故园', '客地',
        
        # 第二部分：驿站客栈类（20个）
        '驿站', '客栈', '旅店', '驿馆', '客舍', '旅舍', '征途', '驿路',
        '客房', '旅次', '驿亭', '客窗', '旅枕', '驿马', '客梦', '旅夜',
        '驿楼', '客思', '旅情', '驿使',
        
        # 第三部分：故土家园类（20个）
        '故土', '故乡', '故园', '故里', '故国', '故居', '故地', '故城',
        '桑梓', '田园', '家园', '家乡', '家山', '家书', '家信', '家人',
        '乡里', '乡村', '乡邻', '乡井',
        
        # 第四部分：离别孤独类（20个）
        '离乡', '背井', '漂泊', '流浪', '离家', '远方', '他乡', '外乡',
        '孤独', '孤单', '孤寂', '孤零', '寂寞', '寂寥', '凄凉', '凄清',
        '清冷', '冷清', '荒凉', '萧索',
        
        # 第五部分：归乡意愿类（20个）
        '归去', '归来', '归还', '归乡', '归里', '归家', '还乡', '还家',
        '回乡', '回家', '返乡', '返家', '省亲', '归宁', '还归', '复归',
        '思归', '欲归', '盼归', '望归',
        
        # 第六部分：时空距离类（20个）
        '千里', '万里', '天涯', '海角', '遥远', '远隔', '相隔', '阻隔',
        '长途', '远道', '迢迢', '遥遥', '漫漫', '悠悠', '绵绵', '经年',
        '数载', '多年', '久别', '长别',
        
        # 第七部分：情感表达类（20个）
        '思念', '怀念', '追忆', '回忆', '梦回', '梦见', '梦里', '梦中',
        '泪眼', '泪痕', '泪下', '泪湿', '愁绪', '愁怀', '愁肠', '愁云',
        '悲凉', '悲苦', '悲戚', '悲怆'
    ],
    
    '边塞战争': [
        '边塞', '关隘', '烽火', '战场', '征战', '戍守', '军营', '铁马',
        '金戈', '刀剑', '弓箭', '战鼓', '号角', '军旗', '沙场', '关山',
        '胡笳', '羌笛', '征衣', '戍楼', '烽烟', '战马', '征夫', '戍卒'
    ]
}

print(f"羁旅思乡意象词库已扩展至: {len(ENHANCED_IMAGERY_DICT['羁旅思乡'])}个")

# ==================== 2. 增强羁旅与山水区分特征 ====================
class EnhancedJilvFeatureExtractor:
    """羁旅思乡深度特征提取器（含山水区分特征）"""
    
    def __init__(self):
        # 离别情感强度词
        self.separation_emotion_words = [
            '离', '别', '分', '去', '远', '隔', '断', '绝', '失', '逝',
            '泪', '泣', '哭', '悲', '愁', '恨', '怨', '叹', '悔', '痛',
            '伤', '心碎', '肠断', '魂断', '梦断', '情断', '思断', '意断'
        ]
        
        # 时空距离感词（强调距离）
        self.spatial_distance_words = [
            '千里', '万里', '天涯', '海角', '遥远', '迢迢', '遥遥', '漫漫',
            '悠悠', '绵绵', '远隔', '相隔', '阻隔', '长途', '远道'
        ]
        
        self.temporal_distance_words = [
            '经年', '数载', '多年', '久别', '长别', '永别', '终身', '一生',
            '岁月', '年华', '光阴', '时光', '日月', '春秋', '寒暑'
        ]
        
        # 归乡意愿强度词（强调回归）
        self.return_desire_words = [
            '归', '还', '回', '返', '复', '重', '再', '复归', '还归',
            '思归', '欲归', '盼归', '望归', '念归', '怀归', '梦归'
        ]
        
        self.home_reference_words = [
            '故乡', '故园', '故里', '故国', '故土', '家乡', '家园', '家山',
            '桑梓', '田园', '乡关', '乡土', '乡里', '乡井'
        ]
        
        # 山水田园特征词（用于对比）
        self.nature_words = [
            '山', '水', '溪', '泉', '林', '树', '竹', '花', '草', '云',
            '雾', '雨', '风', '月', '日', '星', '鸟', '鱼', '虫', '兽'
        ]
        
        self.pastoral_words = [
            '田', '园', '农', '耕', '种', '收', '牧', '渔', '樵', '舍',
            '村', '庄', '麦', '稻', '桑', '麻', '鸡', '犬', '牛', '羊'
        ]
        
        # 客居漂泊词（羁旅独有）
        self.wandering_words = [
            '客', '旅', '游', '羁', '漂', '浮', '流', '徙', '迁', '移',
            '寄', '托', '依', '投', '宿', '停', '驻', '留', '滞', '困'
        ]
    
    def extract(self, poem_text):
        """提取50维羁旅-山水区分特征"""
        features = []
        text_len = len(poem_text) + 1
        
        # ===== 第一组：离别情感强度（10维）=====
        sep_count = sum(1 for w in self.separation_emotion_words if w in poem_text)
        sep_density = sep_count / text_len
        
        features.extend([
            sep_count,  # 离别词数量
            sep_density,  # 离别词密度
            1 if sep_count >= 3 else 0,  # 强离别情感
            1 if '泪' in poem_text or '泣' in poem_text else 0,  # 含泪痕
            1 if '愁' in poem_text or '恨' in poem_text else 0,  # 含愁恨
            1 if '离' in poem_text and '别' in poem_text else 0,  # 离别组合
            1 if '悲' in poem_text or '伤' in poem_text else 0,  # 悲伤情感
            sep_count * sep_density,  # 离别强度积
            min(sep_count / 5, 1.0),  # 归一化离别分
            1 if sep_count >= 5 else 0  # 极强离别
        ])
        
        # ===== 第二组：时空距离感（10维）=====
        spatial_count = sum(1 for phrase in self.spatial_distance_words if phrase in poem_text)
        temporal_count = sum(1 for phrase in self.temporal_distance_words if phrase in poem_text)
        total_distance = spatial_count + temporal_count
        
        features.extend([
            spatial_count,  # 空间距离词
            temporal_count,  # 时间距离词
            total_distance,  # 总距离感
            total_distance / 10,  # 归一化距离
            1 if total_distance >= 2 else 0,  # 强距离感
            1 if '千里' in poem_text or '万里' in poem_text else 0,  # 千万里
            1 if '天涯' in poem_text or '海角' in poem_text else 0,  # 天涯海角
            1 if '经年' in poem_text or '久别' in poem_text else 0,  # 时间久
            spatial_count * temporal_count,  # 时空交织
            1 if total_distance >= 3 else 0  # 极强距离
        ])
        
        # ===== 第三组：归乡意愿强度（10维）=====
        return_count = sum(1 for w in self.return_desire_words if w in poem_text)
        home_count = sum(1 for phrase in self.home_reference_words if phrase in poem_text)
        total_return = return_count + home_count
        
        features.extend([
            return_count,  # 归乡词数量
            home_count,  # 家园词数量
            total_return,  # 总归乡意愿
            total_return / text_len,  # 归乡密度
            1 if total_return >= 3 else 0,  # 强归乡意愿
            1 if '归' in poem_text else 0,  # 含归字
            1 if '故乡' in poem_text or '家乡' in poem_text else 0,  # 直接家乡
            1 if '思归' in poem_text or '欲归' in poem_text else 0,  # 思归
            return_count * home_count,  # 归乡交织
            1 if total_return >= 5 else 0  # 极强归乡
        ])
        
        # ===== 第四组：客居漂泊特征（10维）=====
        wander_count = sum(1 for w in self.wandering_words if w in poem_text)
        wander_density = wander_count / text_len
        
        features.extend([
            wander_count,  # 漂泊词数量
            wander_density,  # 漂泊词密度
            1 if wander_count >= 3 else 0,  # 强漂泊感
            1 if '客' in poem_text else 0,  # 含客字
            1 if '旅' in poem_text else 0,  # 含旅字
            1 if '客舍' in poem_text or '旅馆' in poem_text else 0,  # 客居地
            1 if '漂泊' in poem_text or '流浪' in poem_text else 0,  # 漂泊
            wander_count * wander_density,  # 漂泊强度
            min(wander_count / 5, 1.0),  # 归一化漂泊
            1 if wander_count >= 5 else 0  # 极强漂泊
        ])
        
        # ===== 第五组：羁旅-山水区分特征（10维）=====
        nature_count = sum(1 for w in self.nature_words if w in poem_text)
        pastoral_count = sum(1 for w in self.pastoral_words if w in poem_text)
        nature_total = nature_count + pastoral_count
        
        # 关键区分：羁旅诗有山水但更强调人的情感，山水诗强调自然本身
        emotion_ratio = (sep_count + return_count) / (nature_total + 1)  # 情感/自然比
        human_focus = (wander_count + return_count) / (nature_total + 1)  # 人/自然比
        
        features.extend([
            nature_count,  # 自然景物词
            pastoral_count,  # 田园景物词
            emotion_ratio,  # 情感/自然比（羁旅高）
            human_focus,  # 人/自然比（羁旅高）
            1 if emotion_ratio > 0.5 else 0,  # 情感主导
            1 if human_focus > 0.3 else 0,  # 人文主导
            total_distance / (nature_total + 1),  # 距离/自然比
            wander_count / (pastoral_count + 1),  # 漂泊/田园比
            1 if wander_count > pastoral_count else 0,  # 羁旅占优
            1 if (sep_count + return_count) > nature_total else 0  # 情感超景物
        ])
        
        return np.array(features, dtype=np.float32)

# ==================== 意象特征提取器 ====================
class ImageryFeatureExtractor:
    """意象特征提取器（150个羁旅思乡词库）"""
    
    def __init__(self, imagery_dict):
        self.imagery_dict = imagery_dict
    
    def extract(self, poem_text):
        """提取60维意象特征（6类×10维）"""
        features = []
        
        for theme, words in self.imagery_dict.items():
            count = sum(1 for word in words if word in poem_text)
            ratio = count / len(words) if len(words) > 0 else 0
            char_ratio = sum(len(word) for word in words if word in poem_text) / (len(poem_text) + 1)
            
            # 前7个高频词的二值特征
            top_words = words[:7]
            binary_features = [1 if word in poem_text else 0 for word in top_words]
            
            features.extend([count, ratio, char_ratio] + binary_features)
        
        return np.array(features, dtype=np.float32)

# ==================== 3. 增强数据增强（2000首+500合成）====================
def enhanced_data_augmentation_v2(data, target_theme='羁旅思乡', target_count=2000, synthetic_count=500):
    """增强数据增强策略"""
    
    theme_counts = Counter([item['theme'] for item in data])
    jilv_count = theme_counts[target_theme]
    
    print(f"\n{'='*60}")
    print(f"羁旅思乡数据增强策略 v2.0")
    print(f"{'='*60}")
    print(f"原始{target_theme}数据: {jilv_count}首")
    
    jilv_samples = [item for item in data if item['theme'] == target_theme]
    
    # 步骤1：过采样到2000首
    oversample_needed = target_count - jilv_count
    if oversample_needed > 0:
        oversample_count = min(oversample_needed, jilv_count * 3)  # 最多3倍
        oversampled = random.choices(jilv_samples, k=oversample_count)
        data.extend(oversampled)
        print(f"+ 过采样: {oversample_count}首 (目标{target_count}首)")
    
    # 步骤2：生成500首合成样本
    for i in range(synthetic_count):
        # 随机选择2-3首羁旅诗混合
        num_mix = random.randint(2, 3)
        samples = random.sample(jilv_samples, num_mix)
        
        # 混合策略：随机选择每首诗的部分句子
        all_lines = []
        for sample in samples:
            lines = sample['poem'].split('|')
            num_lines = random.randint(2, min(4, len(lines)))
            selected_lines = random.sample(lines, num_lines)
            all_lines.extend(selected_lines)
        
        # 随机打乱并取部分
        random.shuffle(all_lines)
        final_lines = all_lines[:random.randint(6, 10)]
        
        synthetic_poem = {
            'poet': '数据增强',
            'poem': '|'.join(final_lines),
            'dynasty': samples[0].get('dynasty', '唐'),
            'title': f'增强样本_{i+1}',
            'theme': target_theme,
            'segmented_poem_jieba': '|'.join(final_lines)
        }
        
        data.append(synthetic_poem)
    
    print(f"+ 合成样本: {synthetic_count}首")
    
    final_count = Counter([item['theme'] for item in data])[target_theme]
    print(f"+ 最终{target_theme}数据: {final_count}首")
    print(f"{'='*60}\n")
    
    return data

# ==================== 4. Focal Loss with Enhanced Weights ====================
class FocalLossWithClassWeights(nn.Module):
    """Focal Loss with enhanced class weights for 羁旅思乡"""
    
    def __init__(self, alpha=None, gamma=2.5, reduction='mean', jilv_boost=1.5):
        super().__init__()
        self.alpha = alpha
        self.gamma = gamma
        self.reduction = reduction
        self.jilv_boost = jilv_boost
        
        # 羁旅思乡类索引（假设是第4类，索引4）
        self.jilv_idx = 4
    
    def forward(self, inputs, targets):
        ce_loss = F.cross_entropy(inputs, targets, weight=self.alpha, reduction='none')
        pt = torch.exp(-ce_loss)
        focal_loss = ((1 - pt) ** self.gamma) * ce_loss
        
        # 对羁旅思乡类增加权重
        jilv_mask = (targets == self.jilv_idx).float()
        focal_loss = focal_loss * (1.0 + jilv_mask * (self.jilv_boost - 1.0))
        
        if self.reduction == 'mean':
            return focal_loss.mean()
        elif self.reduction == 'sum':
            return focal_loss.sum()
        else:
            return focal_loss

# ==================== BERT数据集 ====================
class BERTPoetryDataset(Dataset):
    def __init__(self, data, tokenizer, label_map, max_length=128,
                 imagery_extractor=None, jilv_extractor=None):
        self.data = data
        self.tokenizer = tokenizer
        self.label_map = label_map
        self.max_length = max_length
        self.imagery_extractor = imagery_extractor
        self.jilv_extractor = jilv_extractor
    
    def __len__(self):
        return len(self.data)
    
    def __getitem__(self, idx):
        item = self.data[idx]
        
        poem_text = item['poem'].replace('|', '')
        encoding = self.tokenizer(
            poem_text,
            max_length=self.max_length,
            padding='max_length',
            truncation=True,
            return_tensors='pt'
        )
        
        imagery_features = self.imagery_extractor.extract(poem_text) if self.imagery_extractor else np.zeros(60)
        jilv_features = self.jilv_extractor.extract(poem_text) if self.jilv_extractor else np.zeros(50)
        
        label = self.label_map[item['theme']]
        
        return {
            'input_ids': encoding['input_ids'].squeeze(0),
            'attention_mask': encoding['attention_mask'].squeeze(0),
            'imagery_features': torch.tensor(imagery_features, dtype=torch.float32),
            'jilv_features': torch.tensor(jilv_features, dtype=torch.float32),
            'label': torch.tensor(label, dtype=torch.long)
        }

# ==================== BERT增强分类器 ====================
class BERTJilvEnhancedClassifier(nn.Module):
    """BERT+羁旅思乡深度特征分类器"""
    
    def __init__(self, bert_model_name='bert-base-chinese', num_classes=6,
                 imagery_dim=60, jilv_dim=50, dropout=0.3):
        super().__init__()
        
        self.bert = BertModel.from_pretrained(bert_model_name)
        self.bert_hidden_size = self.bert.config.hidden_size
        
        # 特征投影
        self.imagery_proj = nn.Linear(imagery_dim, 128)
        self.jilv_proj = nn.Linear(jilv_dim, 128)  # 羁旅特征单独投影
        
        # BiLSTM
        self.lstm = nn.LSTM(
            input_size=self.bert_hidden_size,
            hidden_size=512,
            num_layers=2,
            bidirectional=True,
            batch_first=True,
            dropout=dropout
        )
        
        # Attention
        self.attention = nn.MultiheadAttention(
            embed_dim=1024,
            num_heads=8,
            dropout=dropout,
            batch_first=True
        )
        
        # 分类器（增加羁旅特征维度）
        total_features = 1024 + 128 + 128  # BERT+LSTM + 意象 + 羁旅
        self.classifier = nn.Sequential(
            nn.Linear(total_features, 512),
            nn.BatchNorm1d(512),
            nn.ReLU(),
            nn.Dropout(dropout),
            
            nn.Linear(512, 256),
            nn.BatchNorm1d(256),
            nn.ReLU(),
            nn.Dropout(dropout),
            
            nn.Linear(256, 128),
            nn.BatchNorm1d(128),
            nn.ReLU(),
            nn.Dropout(dropout),
            
            nn.Linear(128, num_classes)
        )
    
    def forward(self, input_ids, attention_mask, imagery_features, jilv_features):
        # BERT编码
        bert_output = self.bert(input_ids=input_ids, attention_mask=attention_mask)
        sequence_output = bert_output.last_hidden_state
        
        # BiLSTM
        lstm_output, _ = self.lstm(sequence_output)
        
        # Self-attention
        attn_output, _ = self.attention(lstm_output, lstm_output, lstm_output)
        
        # 池化
        pooled_output = torch.mean(attn_output, dim=1)
        
        # 特征融合
        imagery_proj = self.imagery_proj(imagery_features)
        jilv_proj = self.jilv_proj(jilv_features)
        
        combined_features = torch.cat([pooled_output, imagery_proj, jilv_proj], dim=1)
        
        # 分类
        logits = self.classifier(combined_features)
        
        return logits

# ==================== 训练和评估函数 ====================
def train_epoch(model, dataloader, criterion, optimizer, scheduler, device, epoch, total_epochs):
    model.train()
    total_loss = 0
    correct = 0
    total = 0
    
    pbar = tqdm(dataloader, desc=f'Epoch {epoch}/{total_epochs} [Train]')
    
    for batch in pbar:
        input_ids = batch['input_ids'].to(device)
        attention_mask = batch['attention_mask'].to(device)
        imagery_features = batch['imagery_features'].to(device)
        jilv_features = batch['jilv_features'].to(device)
        labels = batch['label'].to(device)
        
        optimizer.zero_grad()
        
        outputs = model(input_ids, attention_mask, imagery_features, jilv_features)
        loss = criterion(outputs, labels)
        
        loss.backward()
        torch.nn.utils.clip_grad_norm_(model.parameters(), max_norm=1.0)
        optimizer.step()
        scheduler.step()
        
        total_loss += loss.item()
        _, predicted = torch.max(outputs, 1)
        correct += (predicted == labels).sum().item()
        total += labels.size(0)
        
        pbar.set_postfix({'loss': f'{loss.item():.4f}', 'acc': f'{100*correct/total:.2f}%'})
    
    return total_loss / len(dataloader), 100 * correct / total

def evaluate(model, dataloader, device):
    model.eval()
    correct = 0
    total = 0
    all_preds = []
    all_labels = []
    
    with torch.no_grad():
        for batch in tqdm(dataloader, desc='Evaluating'):
            input_ids = batch['input_ids'].to(device)
            attention_mask = batch['attention_mask'].to(device)
            imagery_features = batch['imagery_features'].to(device)
            jilv_features = batch['jilv_features'].to(device)
            labels = batch['label'].to(device)
            
            outputs = model(input_ids, attention_mask, imagery_features, jilv_features)
            _, predicted = torch.max(outputs, 1)
            
            correct += (predicted == labels).sum().item()
            total += labels.size(0)
            
            all_preds.extend(predicted.cpu().numpy())
            all_labels.extend(labels.cpu().numpy())
    
    accuracy = 100 * correct / total
    return accuracy, all_preds, all_labels

# ==================== 主训练函数 ====================
def train_incremental_model(model_id=5):
    """训练增量模型"""
    
    print("\n" + "="*80)
    print(f"羁旅思乡增强模型训练 - 模型{model_id+1}")
    print("="*80)
    print("优化措施:")
    print("  1. 羁旅思乡意象词库: 150个 (原50个)")
    print("  2. 羁旅-山水区分特征: 50维")
    print("  3. 数据增强: 2000首过采样 + 500合成样本")
    print("  4. Focal Loss gamma=2.5, 羁旅思乡权重×1.5")
    print("="*80 + "\n")
    
    # 参数设置
    BERT_MODEL = 'bert-base-chinese'
    BATCH_SIZE = 16
    EPOCHS = 50
    LR = 2e-5
    DEVICE = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
    
    print(f"设备: {DEVICE}")
    print(f"批大小: {BATCH_SIZE}")
    print(f"训练轮数: {EPOCHS}")
    print(f"学习率: {LR}\n")
    
    # 加载数据
    print("1. 加载预处理数据...")
    with open('poems_preprocessed.json', 'r', encoding='utf-8') as f:
        data = json.load(f)
    print(f"   原始数据: {len(data)}首")
    
    # 题材统计
    theme_counts = Counter([item['theme'] for item in data])
    print("\n   原始题材分布:")
    for theme, count in sorted(theme_counts.items()):
        print(f"     {theme}: {count}首")
    
    # 数据增强
    print("\n2. 应用增强数据增强策略...")
    data = enhanced_data_augmentation_v2(data, target_count=2000, synthetic_count=500)
    
    theme_counts_after = Counter([item['theme'] for item in data])
    print("   增强后题材分布:")
    for theme, count in sorted(theme_counts_after.items()):
        print(f"     {theme}: {count}首")
    
    # 标签映射
    themes = sorted(list(set([item['theme'] for item in data])))
    label_map = {theme: idx for idx, theme in enumerate(themes)}
    idx_to_label = {idx: theme for theme, idx in label_map.items()}
    
    print(f"\n3. 标签映射: {label_map}")
    
    # 特征提取器
    print("\n4. 初始化特征提取器...")
    imagery_extractor = ImageryFeatureExtractor(ENHANCED_IMAGERY_DICT)
    jilv_extractor = EnhancedJilvFeatureExtractor()
    print("   + 意象特征: 60维 (150个羁旅思乡词)")
    print("   + 羁旅特征: 50维 (离别+时空+归乡+漂泊+区分)")
    
    # 数据集划分
    print("\n5. 划分训练集和测试集...")
    train_data, test_data = train_test_split(data, test_size=0.15, random_state=42+model_id, 
                                             stratify=[item['theme'] for item in data])
    print(f"   训练集: {len(train_data)}首")
    print(f"   测试集: {len(test_data)}首")
    
    # BERT tokenizer
    print("\n6. 加载BERT tokenizer...")
    tokenizer = BertTokenizer.from_pretrained(BERT_MODEL)
    
    # 创建数据集
    print("\n7. 创建数据加载器...")
    train_dataset = BERTPoetryDataset(train_data, tokenizer, label_map,
                                     imagery_extractor=imagery_extractor,
                                     jilv_extractor=jilv_extractor)
    test_dataset = BERTPoetryDataset(test_data, tokenizer, label_map,
                                    imagery_extractor=imagery_extractor,
                                    jilv_extractor=jilv_extractor)
    
    train_loader = DataLoader(train_dataset, batch_size=BATCH_SIZE, shuffle=True)
    test_loader = DataLoader(test_dataset, batch_size=BATCH_SIZE)
    
    print(f"   训练批次: {len(train_loader)}")
    print(f"   测试批次: {len(test_loader)}")
    
    # 初始化模型
    print("\n8. 初始化BERT增强模型...")
    model = BERTJilvEnhancedClassifier(
        bert_model_name=BERT_MODEL,
        num_classes=len(themes),
        imagery_dim=60,
        jilv_dim=50,
        dropout=0.3
    ).to(DEVICE)
    
    total_params = sum(p.numel() for p in model.parameters())
    print(f"   模型参数量: {total_params:,}")
    
    # 计算类别权重
    print("\n9. 计算Focal Loss类别权重...")
    theme_counts_train = Counter([item['theme'] for item in train_data])
    class_weights = []
    for theme in themes:
        count = theme_counts_train[theme]
        weight = len(train_data) / (len(themes) * count)
        class_weights.append(weight)
    
    class_weights = torch.FloatTensor(class_weights).to(DEVICE)
    print("   类别权重:", [f"{w:.2f}" for w in class_weights])
    
    # Focal Loss (gamma=2.5, 羁旅思乡权重×1.5)
    criterion = FocalLossWithClassWeights(
        alpha=class_weights,
        gamma=2.5,
        jilv_boost=1.5
    )
    print("   + Focal Loss gamma=2.5")
    print("   + 羁旅思乡类额外权重×1.5")
    
    # 优化器
    print("\n10. 配置优化器和学习率调度...")
    optimizer = AdamW([
        {'params': model.bert.parameters(), 'lr': LR},
        {'params': model.lstm.parameters(), 'lr': LR * 10},
        {'params': model.attention.parameters(), 'lr': LR * 10},
        {'params': model.classifier.parameters(), 'lr': LR * 10},
        {'params': model.imagery_proj.parameters(), 'lr': LR * 10},
        {'params': model.jilv_proj.parameters(), 'lr': LR * 10}
    ], weight_decay=0.01)
    
    total_steps = len(train_loader) * EPOCHS
    scheduler = get_cosine_schedule_with_warmup(
        optimizer,
        num_warmup_steps=int(0.1 * total_steps),
        num_training_steps=total_steps,
        num_cycles=2
    )
    
    # 训练
    print("\n" + "="*80)
    print(f"开始训练模型{model_id+1}...")
    print("="*80 + "\n")
    
    best_acc = 0
    best_epoch = 0
    output_dir = 'bert_incremental_output'
    os.makedirs(output_dir, exist_ok=True)
    
    for epoch in range(1, EPOCHS + 1):
        train_loss, train_acc = train_epoch(model, train_loader, criterion, optimizer, 
                                           scheduler, DEVICE, epoch, EPOCHS)
        test_acc, test_preds, test_labels = evaluate(model, test_loader, DEVICE)
        
        print(f"Epoch {epoch}/{EPOCHS}:")
        print(f"  Train Loss: {train_loss:.4f}, Train Acc: {train_acc:.2f}%")
        print(f"  Test Acc: {test_acc:.2f}%")
        
        if test_acc > best_acc:
            best_acc = test_acc
            best_epoch = epoch
            model_path = os.path.join(output_dir, f'model_{model_id}_jilv_enhanced.pth')
            torch.save({
                'epoch': epoch,
                'model_state_dict': model.state_dict(),
                'optimizer_state_dict': optimizer.state_dict(),
                'accuracy': best_acc,
                'label_map': label_map
            }, model_path)
            print(f"  + 保存最佳模型: {best_acc:.2f}%")
        
        print()
    
    print("="*80)
    print(f"模型{model_id+1}训练完成！")
    print(f"最佳测试准确率: {best_acc:.2f}% (Epoch {best_epoch})")
    print("="*80 + "\n")
    
    # 最终评估
    print("最终评估...")
    model_path = os.path.join(output_dir, f'model_{model_id}_jilv_enhanced.pth')
    checkpoint = torch.load(model_path)
    model.load_state_dict(checkpoint['model_state_dict'])
    
    test_acc, test_preds, test_labels = evaluate(model, test_loader, DEVICE)
    
    print("\n分类报告:")
    print(classification_report(test_labels, test_preds, target_names=themes, digits=4))
    
    print("\n混淆矩阵:")
    cm = confusion_matrix(test_labels, test_preds)
    print(cm)
    
    return best_acc

# ==================== 主函数 ====================
def main():
    """主函数"""
    import argparse
    
    parser = argparse.ArgumentParser()
    parser.add_argument('--model_id', type=int, default=5, help='模型ID (5或6)')
    args = parser.parse_args()
    
    print("\n" + "="*80)
    print("羁旅思乡深度增强 - 增量训练系统")
    print("="*80)
    print("优化措施:")
    print("  + 羁旅思乡意象词库: 50 -> 150个")
    print("  + 羁旅-山水区分特征: 50维增强特征")
    print("  + 数据增强: 2000首过采样 + 500合成样本")
    print("  + Focal Loss gamma: 2.0 -> 2.5")
    print("  + 羁旅思乡类权重: x1.5")
    print("="*80 + "\n")
    
    # 训练模型
    accuracy = train_incremental_model(model_id=args.model_id)
    
    print("\n" + "="*80)
    print("训练完成！")
    print(f"模型{args.model_id+1}准确率: {accuracy:.2f}%")
    print("="*80)
    print("\n建议:")
    print("1. 训练第二个增量模型: python train_incremental_jilv_enhanced.py --model_id 6")
    print("2. 将2个新模型与现有5个模型组合进行7模型集成预测")
    print("3. 预期集成准确率: 84-86%")
    print("="*80 + "\n")

if __name__ == '__main__':
    main()

