"""
参数分析实验2: BiLSTM Layers 层数分析
对应论文中的折线图分析实验

实验设置:
- BiLSTM Layers: [1, 2, 3, 4, 5]
- 其他参数保持不变
- 每个层数配置训练一个完整模型
- 记录测试集的准确率、精确率、召回率、F1分数
- 记录训练时间，体现计算效率差异
"""

import json
import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F
from torch.utils.data import Dataset, DataLoader
from transformers import BertTokenizer, BertModel
from sklearn.model_selection import train_test_split
from sklearn.metrics import classification_report, accuracy_score
from tqdm import tqdm
import os
import sys
import time

# 导入原始训练脚本中的类和函数
sys.path.append(os.path.dirname(os.path.abspath(__file__)))
from train_bert_ultra_optimized import (
    EnhancedImageryFeatureExtractor,
    FocalLoss,
    device
)

print("="*70)
print("参数分析实验2: BiLSTM Layers 层数影响分析")
print("="*70)


# ==================== 修改后的模型类 ====================
class BERTUltraClassifier_LayersAnalysis(nn.Module):
    """
    BERT超级分类器 - BiLSTM层数分析版本
    可以动态设置LSTM层数
    """
    def __init__(self, bert_model_name, num_classes, rhythm_dim=11, imagery_dim=75, num_lstm_layers=2):
        super().__init__()
        
        # BERT
        self.bert = BertModel.from_pretrained(bert_model_name)
        self.bert_hidden_size = self.bert.config.hidden_size
        
        # 特征投影
        self.rhythm_proj = nn.Linear(rhythm_dim, 128)
        self.imagery_proj = nn.Linear(imagery_dim, 128)
        
        # BiLSTM - 可变层数
        # 注意: 当layers>1时，才使用dropout
        lstm_dropout = 0.3 if num_lstm_layers > 1 else 0.0
        
        self.lstm = nn.LSTM(
            input_size=self.bert_hidden_size,
            hidden_size=512,
            num_layers=num_lstm_layers,  # ← 可变层数
            bidirectional=True,
            batch_first=True,
            dropout=lstm_dropout
        )
        
        # Self-Attention
        self.attention = nn.MultiheadAttention(
            embed_dim=1024,
            num_heads=8,
            dropout=0.3,
            batch_first=True
        )
        
        # 分类器 - 保持固定配置
        # 正确顺序: Linear → BatchNorm → ReLU → Dropout
        self.classifier = nn.Sequential(
            nn.Linear(1024 + 128 + 128, 512),
            nn.BatchNorm1d(512),      # ← BatchNorm在前
            nn.ReLU(),
            nn.Dropout(0.5),          # ← Dropout在后
            
            nn.Linear(512, 256),
            nn.BatchNorm1d(256),      # ← BatchNorm在前
            nn.ReLU(),
            nn.Dropout(0.4),          # ← Dropout在后
            
            nn.Linear(256, 128),
            nn.BatchNorm1d(128),      # ← BatchNorm在前
            nn.ReLU(),
            nn.Dropout(0.3),          # ← Dropout在后
            
            nn.Linear(128, num_classes)
        )
    
    def forward(self, input_ids, attention_mask, rhythm_features, imagery_features):
        bert_output = self.bert(input_ids=input_ids, attention_mask=attention_mask)
        sequence_output = bert_output.last_hidden_state
        
        lstm_output, _ = self.lstm(sequence_output)
        attn_output, _ = self.attention(lstm_output, lstm_output, lstm_output)
        pooled_output = attn_output.mean(dim=1)
        
        rhythm_feat = self.rhythm_proj(rhythm_features)
        imagery_feat = self.imagery_proj(imagery_features)
        
        fused_features = torch.cat([pooled_output, rhythm_feat, imagery_feat], dim=1)
        logits = self.classifier(fused_features)
        
        return logits


# ==================== 数据集类 ====================
class PoetryDataset(Dataset):
    def __init__(self, data, tokenizer, label_map, imagery_extractor, max_length=128):
        self.data = data
        self.tokenizer = tokenizer
        self.label_map = label_map
        self.max_length = max_length
        self.imagery_extractor = imagery_extractor
    
    def __len__(self):
        return len(self.data)
    
    def __getitem__(self, idx):
        item = self.data[idx]
        
        raw_text = item.get('poem', '').replace('|', '')
        seg_text = item.get('segmented_filtered', raw_text).replace('|', ' ')
        
        encoding = self.tokenizer(
            seg_text,
            add_special_tokens=True,
            max_length=self.max_length,
            padding='max_length',
            truncation=True,
            return_tensors='pt'
        )
        
        rhythm_vector = np.array(item['rhythm_features']['rhythm_vector'])
        if len(rhythm_vector) != 11:
            rhythm_vector = np.pad(rhythm_vector, (0, max(0, 11 - len(rhythm_vector))), 'constant')
        
        imagery_features = self.imagery_extractor.extract(raw_text)
        
        label = self.label_map.get(item.get('theme', '其他'), -1)
        
        return {
            'input_ids': encoding['input_ids'].squeeze(0),
            'attention_mask': encoding['attention_mask'].squeeze(0),
            'rhythm_features': torch.FloatTensor(rhythm_vector),
            'imagery_features': torch.FloatTensor(imagery_features),
            'label': label
        }


# ==================== 训练和评估函数 ====================
def train_and_evaluate(num_lstm_layers, train_poems, test_poems, bert_path, label2id, id2label):
    """
    训练并评估指定LSTM层数的模型
    """
    print(f"\n{'='*70}")
    print(f"BiLSTM Layers = {num_lstm_layers}")
    print(f"{'='*70}")
    
    # 初始化
    tokenizer = BertTokenizer.from_pretrained(bert_path)
    imagery_extractor = EnhancedImageryFeatureExtractor()
    
    # 数据集
    train_dataset = PoetryDataset(train_poems, tokenizer, label2id, imagery_extractor)
    test_dataset = PoetryDataset(test_poems, tokenizer, label2id, imagery_extractor)
    
    train_loader = DataLoader(train_dataset, batch_size=32, shuffle=True)
    test_loader = DataLoader(test_dataset, batch_size=32, shuffle=False)
    
    # 模型
    model = BERTUltraClassifier_LayersAnalysis(
        bert_model_name=bert_path,
        num_classes=len(label2id),
        num_lstm_layers=num_lstm_layers  # ← 设置LSTM层数
    ).to(device)
    
    # 统计模型参数量
    total_params = sum(p.numel() for p in model.parameters())
    trainable_params = sum(p.numel() for p in model.parameters() if p.requires_grad)
    print(f"模型参数量: {total_params:,} (可训练: {trainable_params:,})")
    
    # 计算类别权重
    from collections import Counter
    theme_counts = Counter([p['theme'] for p in train_poems])
    weights = [1.0 / theme_counts[id2label[i]] for i in range(len(label2id))]
    weights = torch.FloatTensor(weights).to(device)
    weights = weights / weights.sum() * len(weights)
    
    # 损失和优化器
    criterion = FocalLoss(alpha=weights, gamma=2.0)
    optimizer = torch.optim.AdamW(model.parameters(), lr=2e-5, weight_decay=0.01)
    
    # 学习率调度器 (warmup + 余弦退火)
    epochs = 50  # 增加到50轮
    warmup_epochs = 5
    total_steps = len(train_loader) * epochs
    warmup_steps = len(train_loader) * warmup_epochs
    
    from torch.optim.lr_scheduler import LambdaLR
    def lr_lambda(current_step):
        if current_step < warmup_steps:
            # Warmup阶段：线性增长
            return float(current_step) / float(max(1, warmup_steps))
        # Warmup后：余弦退火
        progress = float(current_step - warmup_steps) / float(max(1, total_steps - warmup_steps))
        return max(0.1, 0.5 * (1.0 + np.cos(np.pi * progress)))
    
    scheduler = LambdaLR(optimizer, lr_lambda)
    
    best_acc = 0.0
    total_training_time = 0.0
    current_step = 0
    
    for epoch in range(epochs):
        model.train()
        train_loss = 0.0
        epoch_start_time = time.time()
        
        for batch in tqdm(train_loader, desc=f"Epoch {epoch+1}/{epochs}", leave=False):
            input_ids = batch['input_ids'].to(device)
            attention_mask = batch['attention_mask'].to(device)
            rhythm_features = batch['rhythm_features'].to(device)
            imagery_features = batch['imagery_features'].to(device)
            labels = batch['label'].to(device)
            
            optimizer.zero_grad()
            logits = model(input_ids, attention_mask, rhythm_features, imagery_features)
            loss = criterion(logits, labels)
            loss.backward()
            optimizer.step()
            scheduler.step()  # 更新学习率
            
            train_loss += loss.item()
            current_step += 1
        
        epoch_time = time.time() - epoch_start_time
        total_training_time += epoch_time
        
        # 评估
        model.eval()
        all_preds = []
        all_labels = []
        
        with torch.no_grad():
            for batch in test_loader:
                input_ids = batch['input_ids'].to(device)
                attention_mask = batch['attention_mask'].to(device)
                rhythm_features = batch['rhythm_features'].to(device)
                imagery_features = batch['imagery_features'].to(device)
                labels = batch['label'].to(device)
                
                logits = model(input_ids, attention_mask, rhythm_features, imagery_features)
                preds = torch.argmax(logits, dim=1)
                
                all_preds.extend(preds.cpu().numpy())
                all_labels.extend(labels.cpu().numpy())
        
        acc = accuracy_score(all_labels, all_preds)
        
        if acc > best_acc:
            best_acc = acc
        
        if (epoch + 1) % 5 == 0:
            print(f"  Epoch {epoch+1}/{epochs} - Loss: {train_loss/len(train_loader):.4f}, "
                  f"Acc: {acc*100:.2f}%, Time: {epoch_time:.1f}s")
    
    avg_epoch_time = total_training_time / epochs
    print(f"\n最终测试准确率: {best_acc*100:.2f}%")
    print(f"平均每轮训练时间: {avg_epoch_time:.1f}秒")
    print(f"总训练时间: {total_training_time/60:.1f}分钟")
    
    # 最终评估
    model.eval()
    all_preds = []
    all_labels = []
    
    with torch.no_grad():
        for batch in test_loader:
            input_ids = batch['input_ids'].to(device)
            attention_mask = batch['attention_mask'].to(device)
            rhythm_features = batch['rhythm_features'].to(device)
            imagery_features = batch['imagery_features'].to(device)
            labels = batch['label'].to(device)
            
            logits = model(input_ids, attention_mask, rhythm_features, imagery_features)
            preds = torch.argmax(logits, dim=1)
            
            all_preds.extend(preds.cpu().numpy())
            all_labels.extend(labels.cpu().numpy())
    
    # 分类报告
    report_dict = classification_report(all_labels, all_preds, 
                                       target_names=list(id2label.values()),
                                       output_dict=True, zero_division=0)
    
    accuracy = report_dict['accuracy'] * 100
    precision = report_dict['weighted avg']['precision'] * 100
    recall = report_dict['weighted avg']['recall'] * 100
    f1_score = report_dict['weighted avg']['f1-score'] * 100
    
    return {
        'num_lstm_layers': num_lstm_layers,
        'accuracy': accuracy,
        'precision': precision,
        'recall': recall,
        'f1_score': f1_score,
        'total_params': total_params,
        'trainable_params': trainable_params,
        'avg_epoch_time': avg_epoch_time,
        'total_training_time': total_training_time / 60,  # 转为分钟
        'report': report_dict
    }


# ==================== 主函数 ====================
def main():
    print("\n[1/4] 加载数据...")
    
    with open('poems_preprocessed.json', 'r', encoding='utf-8') as f:
        all_poems = json.load(f)
    
    valid_themes = ['交友送别', '咏史怀古', '山水田园', '爱情婚姻', '羁旅思乡', '边塞战争']
    poems = [p for p in all_poems if p.get('theme') in valid_themes]
    
    print(f"[OK] 加载 {len(poems)} 首诗")
    
    # 标签映射
    label2id = {theme: idx for idx, theme in enumerate(valid_themes)}
    id2label = {idx: theme for theme, idx in label2id.items()}
    
    # 划分数据集
    train_poems, test_poems = train_test_split(
        poems, test_size=0.15, random_state=42,
        stratify=[p['theme'] for p in poems]
    )
    
    print(f"训练集: {len(train_poems)}首, 测试集: {len(test_poems)}首")
    
    # BiLSTM层数列表
    num_layers_list = [1, 2, 3, 4, 5]
    
    print(f"\n[2/4] 开始参数分析实验...")
    print(f"将测试 {len(num_layers_list)} 个不同的BiLSTM层数配置")
    print(f"BiLSTM Layers: {num_layers_list}")
    
    # BERT路径
    bert_path = '../bert-base-chinese'
    
    # 存储结果
    results = []
    
    # 逐个训练
    for i, num_layers in enumerate(num_layers_list, 1):
        print(f"\n{'#'*70}")
        print(f"实验进度: {i}/{len(num_layers_list)}")
        print(f"{'#'*70}")
        
        result = train_and_evaluate(
            num_layers, train_poems, test_poems,
            bert_path, label2id, id2label
        )
        
        results.append(result)
        
        print(f"\n[结果] BiLSTM Layers={num_layers}")
        print(f"  准确率: {result['accuracy']:.2f}%")
        print(f"  精确率: {result['precision']:.2f}%")
        print(f"  召回率: {result['recall']:.2f}%")
        print(f"  F1分数: {result['f1_score']:.2f}%")
        print(f"  模型参数量: {result['total_params']:,}")
        print(f"  平均训练时间: {result['avg_epoch_time']:.1f}秒/轮")
    
    # 保存结果
    print(f"\n[3/4] 保存实验结果...")
    
    output_dir = 'parameter_analysis_results'
    os.makedirs(output_dir, exist_ok=True)
    
    # 保存JSON
    with open(f'{output_dir}/bilstm_layers_analysis_results.json', 'w', encoding='utf-8') as f:
        json.dump(results, f, ensure_ascii=False, indent=2)
    
    # 生成表格（CSV）
    with open(f'{output_dir}/bilstm_layers_analysis_table.csv', 'w', encoding='utf-8') as f:
        f.write("num_layers,accuracy,precision,recall,f1_score,total_params,avg_epoch_time\n")
        for r in results:
            f.write(f"{r['num_lstm_layers']},{r['accuracy']:.2f},{r['precision']:.2f},"
                   f"{r['recall']:.2f},{r['f1_score']:.2f},"
                   f"{r['total_params']},{r['avg_epoch_time']:.2f}\n")
    
    print(f"[OK] 结果已保存到: {output_dir}/")
    
    # 打印汇总表格
    print(f"\n[4/4] 实验结果汇总表格:")
    print("="*90)
    print(f"{'Layers':<10} {'Accuracy':<12} {'Precision':<12} {'Recall':<12} {'F1-Score':<12} {'Time(s/epoch)':<15}")
    print("-"*90)
    for r in results:
        print(f"{r['num_lstm_layers']:<10} {r['accuracy']:<12.2f} {r['precision']:<12.2f} "
              f"{r['recall']:<12.2f} {r['f1_score']:<12.2f} {r['avg_epoch_time']:<15.1f}")
    print("="*90)
    
    # 找出最优层数
    best_result = max(results, key=lambda x: x['f1_score'])
    print(f"\n最优BiLSTM层数: {best_result['num_lstm_layers']}")
    print(f"对应F1分数: {best_result['f1_score']:.2f}%")
    print(f"平均训练时间: {best_result['avg_epoch_time']:.1f}秒/轮")
    
    # 分析层数与性能的关系
    print(f"\n层数-性能分析:")
    for r in results:
        print(f"  {r['num_lstm_layers']}层: F1={r['f1_score']:.2f}%, "
              f"时间={r['avg_epoch_time']:.1f}s, "
              f"参数量={r['total_params']:,}")
    
    print("\n实验完成!")


if __name__ == '__main__':
    main()

