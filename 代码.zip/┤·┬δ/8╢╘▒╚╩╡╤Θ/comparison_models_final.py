"""
古诗题材分类对比实验 - 最终版（4个对比模型）

对比模型：
1. BERT-TextCNN
2. BERT-BiLSTM（修复版，添加注意力池化）
3. BERT-TextCNN-BiLSTM
4. BiGRU-CNN

数据集：poems_jieba_merged.json
"""

import json
import torch
import torch.nn as nn
import torch.optim as optim
from torch.utils.data import Dataset, DataLoader
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score, precision_recall_fscore_support
from transformers import BertTokenizer, BertModel
import random
import time
from collections import Counter

# 设置随机种子
def set_global_seed(seed=42):
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)
    torch.backends.cudnn.deterministic = True
    torch.backends.cudnn.benchmark = False

set_global_seed(42)

device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
print(f"使用设备: {device}")

# 配置
BERT_PATH = './bert-base-chinese'
MAX_LEN = 128
BATCH_SIZE = 16
NUM_EPOCHS = 30
LEARNING_RATE_BERT = 2e-5
LEARNING_RATE_OTHER = 5e-4


# ==================== Focal Loss ====================
class FocalLoss(nn.Module):
    """Focal Loss用于处理类别不平衡"""
    def __init__(self, alpha=None, gamma=2.5, reduction='mean'):
        super(FocalLoss, self).__init__()
        self.alpha = alpha
        self.gamma = gamma
        self.reduction = reduction
    
    def forward(self, inputs, targets):
        ce_loss = nn.functional.cross_entropy(inputs, targets, weight=self.alpha, reduction='none')
        pt = torch.exp(-ce_loss)
        focal_loss = ((1 - pt) ** self.gamma) * ce_loss
        
        if self.reduction == 'mean':
            return focal_loss.mean()
        elif self.reduction == 'sum':
            return focal_loss.sum()
        else:
            return focal_loss


# ==================== 数据加载 ====================
def load_data(file_path):
    """加载poems_jieba_merged.json数据"""
    with open(file_path, encoding='utf-8') as f:
        data = json.load(f)
    
    poems = []
    themes = []
    
    for item in data:
        if not item.get('poem') or not item.get('theme'):
            continue
        
        poems.append(item['poem'])
        themes.append(item['theme'])
    
    print(f"加载数据: {len(poems)} 首诗")
    
    # 统计类别分布
    theme_counts = Counter(themes)
    print("\n类别分布:")
    for theme, count in sorted(theme_counts.items(), key=lambda x: -x[1]):
        print(f"  {theme}: {count} ({count/len(themes)*100:.1f}%)")
    
    # 创建标签映射
    unique_themes = sorted(list(set(themes)))
    theme2id = {theme: idx for idx, theme in enumerate(unique_themes)}
    id2theme = {idx: theme for theme, idx in theme2id.items()}
    
    labels = [theme2id[theme] for theme in themes]
    
    return poems, labels, theme2id, id2theme


# ==================== Dataset类 ====================
class PoetryDataset(Dataset):
    """BERT数据集"""
    def __init__(self, poems, labels, tokenizer, max_len):
        self.poems = poems
        self.labels = labels
        self.tokenizer = tokenizer
        self.max_len = max_len
    
    def __len__(self):
        return len(self.poems)
    
    def __getitem__(self, idx):
        poem = self.poems[idx]
        label = self.labels[idx]
        
        encoding = self.tokenizer(
            poem,
            add_special_tokens=True,
            max_length=self.max_len,
            padding='max_length',
            truncation=True,
            return_tensors='pt'
        )
        
        return {
            'input_ids': encoding['input_ids'].squeeze(0),
            'attention_mask': encoding['attention_mask'].squeeze(0),
            'label': torch.tensor(label, dtype=torch.long)
        }


# ==================== 模型1: BERT-TextCNN ====================
class BERTTextCNN(nn.Module):
    """BERT + TextCNN模型"""
    def __init__(self, num_classes, bert_path, hidden_dim=256, dropout=0.3):
        super(BERTTextCNN, self).__init__()
        
        # BERT编码器
        self.bert = BertModel.from_pretrained(bert_path)
        bert_dim = self.bert.config.hidden_size  # 768
        
        # 冻结部分BERT参数
        for i, (name, param) in enumerate(self.bert.named_parameters()):
            if i < 100:
                param.requires_grad = False
        
        # TextCNN: 多尺度卷积
        self.convs = nn.ModuleList([
            nn.Conv1d(bert_dim, hidden_dim, kernel_size=k, padding=k//2)
            for k in [2, 3, 4, 5]
        ])
        
        self.relu = nn.ReLU()
        self.dropout = nn.Dropout(dropout)
        
        # 分类器
        self.fc = nn.Sequential(
            nn.Linear(hidden_dim * 4, hidden_dim),
            nn.BatchNorm1d(hidden_dim),
            nn.ReLU(),
            nn.Dropout(dropout),
            nn.Linear(hidden_dim, num_classes)
        )
    
    def forward(self, input_ids, attention_mask):
        # BERT编码 [batch, seq_len, 768]
        bert_output = self.bert(input_ids=input_ids, attention_mask=attention_mask)
        hidden_states = bert_output.last_hidden_state
        
        # 转置为 [batch, 768, seq_len] 供CNN使用
        hidden_states = hidden_states.transpose(1, 2)
        
        # 多尺度卷积 + 全局最大池化
        conv_outputs = []
        for conv in self.convs:
            conv_out = self.relu(conv(hidden_states))  # [batch, hidden_dim, seq_len]
            pooled = torch.max(conv_out, dim=2)[0]     # [batch, hidden_dim]
            conv_outputs.append(pooled)
        
        # 拼接所有卷积特征
        features = torch.cat(conv_outputs, dim=1)  # [batch, hidden_dim*4]
        features = self.dropout(features)
        
        # 分类
        logits = self.fc(features)
        return logits


# ==================== 模型2: BERT-BiLSTM（修复版）====================
class BERTBiLSTM_Fixed(nn.Module):
    """BERT + BiLSTM模型（添加注意力池化）"""
    def __init__(self, num_classes, bert_path, hidden_dim=256, num_layers=2, dropout=0.2):
        super(BERTBiLSTM_Fixed, self).__init__()
        
        # BERT编码器
        self.bert = BertModel.from_pretrained(bert_path)
        bert_dim = self.bert.config.hidden_size  # 768
        
        # 冻结部分BERT参数
        for i, (name, param) in enumerate(self.bert.named_parameters()):
            if i < 100:
                param.requires_grad = False
        
        # BiLSTM
        self.bilstm = nn.LSTM(
            bert_dim, 
            hidden_dim, 
            num_layers=num_layers,
            batch_first=True,
            bidirectional=True,
            dropout=dropout if num_layers > 1 else 0
        )
        
        # ✨ 注意力机制（关键改进）
        self.attention = nn.Linear(hidden_dim * 2, 1)
        
        self.dropout = nn.Dropout(dropout)
        
        # 分类器
        self.fc = nn.Sequential(
            nn.Linear(hidden_dim * 2, hidden_dim),
            nn.BatchNorm1d(hidden_dim),
            nn.ReLU(),
            nn.Dropout(dropout),
            nn.Linear(hidden_dim, num_classes)
        )
    
    def forward(self, input_ids, attention_mask):
        # BERT编码 [batch, seq_len, 768]
        bert_output = self.bert(input_ids=input_ids, attention_mask=attention_mask)
        hidden_states = bert_output.last_hidden_state
        
        # BiLSTM [batch, seq_len, hidden_dim*2]
        lstm_out, _ = self.bilstm(hidden_states)
        
        # ✨ 注意力池化（改进点）
        attention_weights = torch.softmax(
            self.attention(lstm_out).squeeze(-1), dim=1
        )  # [batch, seq_len]
        
        # 加权求和
        features = torch.bmm(
            attention_weights.unsqueeze(1), lstm_out
        ).squeeze(1)  # [batch, hidden_dim*2]
        
        features = self.dropout(features)
        
        # 分类
        logits = self.fc(features)
        return logits


# ==================== 模型3: BERT-TextCNN-BiLSTM ====================
class BERTTextCNNBiLSTM(nn.Module):
    """BERT + TextCNN + BiLSTM联合模型"""
    def __init__(self, num_classes, bert_path, hidden_dim=256, dropout=0.3):
        super(BERTTextCNNBiLSTM, self).__init__()
        
        # BERT编码器
        self.bert = BertModel.from_pretrained(bert_path)
        bert_dim = self.bert.config.hidden_size  # 768
        
        # 冻结部分BERT参数
        for i, (name, param) in enumerate(self.bert.named_parameters()):
            if i < 100:
                param.requires_grad = False
        
        # TextCNN分支
        self.convs = nn.ModuleList([
            nn.Conv1d(bert_dim, hidden_dim, kernel_size=k, padding=k//2)
            for k in [2, 3, 4]
        ])
        
        # BiLSTM分支
        self.bilstm = nn.LSTM(
            bert_dim, 
            hidden_dim, 
            num_layers=2,
            batch_first=True,
            bidirectional=True,
            dropout=dropout
        )
        
        self.relu = nn.ReLU()
        self.dropout = nn.Dropout(dropout)
        
        # 分类器 (CNN特征 + LSTM特征)
        self.fc = nn.Sequential(
            nn.Linear(hidden_dim * 3 + hidden_dim * 2, hidden_dim),
            nn.BatchNorm1d(hidden_dim),
            nn.ReLU(),
            nn.Dropout(dropout),
            nn.Linear(hidden_dim, num_classes)
        )
    
    def forward(self, input_ids, attention_mask):
        # BERT编码 [batch, seq_len, 768]
        bert_output = self.bert(input_ids=input_ids, attention_mask=attention_mask)
        hidden_states = bert_output.last_hidden_state
        
        # ===== TextCNN分支 =====
        hidden_cnn = hidden_states.transpose(1, 2)  # [batch, 768, seq_len]
        conv_outputs = []
        for conv in self.convs:
            conv_out = self.relu(conv(hidden_cnn))
            pooled = torch.max(conv_out, dim=2)[0]
            conv_outputs.append(pooled)
        cnn_features = torch.cat(conv_outputs, dim=1)  # [batch, hidden_dim*3]
        
        # ===== BiLSTM分支 =====
        lstm_out, (h_n, c_n) = self.bilstm(hidden_states)
        forward_hidden = h_n[-2, :, :]
        backward_hidden = h_n[-1, :, :]
        lstm_features = torch.cat([forward_hidden, backward_hidden], dim=1)  # [batch, hidden_dim*2]
        
        # ===== 特征融合 =====
        features = torch.cat([cnn_features, lstm_features], dim=1)
        features = self.dropout(features)
        
        # 分类
        logits = self.fc(features)
        return logits


# ==================== 模型4: BiGRU-CNN ====================
class BiGRU_CNN(nn.Module):
    """
    BiGRU+CNN模型
    
    架构：
    1. BERT预训练模型获取词向量（多通道特征表示）
    2. BiGRU提取全局上下文特征
    3. 多尺度CNN提取局部特征
    4. 特征融合 + 分类器
    """
    def __init__(self, num_classes, bert_path, 
                 gru_hidden_dim=256, 
                 cnn_hidden_dim=256,
                 num_gru_layers=2,
                 dropout=0.3):
        super(BiGRU_CNN, self).__init__()
        
        # BERT编码器（多通道特征表示）
        self.bert = BertModel.from_pretrained(bert_path)
        bert_dim = self.bert.config.hidden_size  # 768
        
        # 冻结部分BERT参数
        for i, (name, param) in enumerate(self.bert.named_parameters()):
            if i < 100:
                param.requires_grad = False
        
        # ===== BiGRU分支：提取全局上下文特征 =====
        self.bigru = nn.GRU(
            bert_dim,
            gru_hidden_dim,
            num_layers=num_gru_layers,
            batch_first=True,
            bidirectional=True,
            dropout=dropout if num_gru_layers > 1 else 0
        )
        
        # GRU注意力池化
        self.gru_attention = nn.Linear(gru_hidden_dim * 2, 1)
        
        # ===== CNN分支：提取局部特征 =====
        # 多尺度卷积核（2,3,4,5-gram）
        self.convs = nn.ModuleList([
            nn.Conv1d(bert_dim, cnn_hidden_dim, kernel_size=k, padding=k//2)
            for k in [2, 3, 4, 5]
        ])
        
        self.relu = nn.ReLU()
        self.dropout = nn.Dropout(dropout)
        
        # ===== 特征融合层 =====
        # GRU特征: gru_hidden_dim*2, CNN特征: cnn_hidden_dim*4
        fusion_dim = gru_hidden_dim * 2 + cnn_hidden_dim * 4
        
        self.fusion = nn.Sequential(
            nn.Linear(fusion_dim, fusion_dim // 2),
            nn.BatchNorm1d(fusion_dim // 2),
            nn.ReLU(),
            nn.Dropout(dropout)
        )
        
        # ===== 分类器 =====
        self.classifier = nn.Sequential(
            nn.Linear(fusion_dim // 2, 256),
            nn.BatchNorm1d(256),
            nn.ReLU(),
            nn.Dropout(dropout),
            nn.Linear(256, num_classes)
        )
    
    def forward(self, input_ids, attention_mask):
        # BERT编码：多通道特征向量化表示
        bert_output = self.bert(input_ids=input_ids, attention_mask=attention_mask)
        hidden_states = bert_output.last_hidden_state  # [batch, seq_len, 768]
        
        # ===== BiGRU分支：全局上下文特征提取 =====
        gru_out, _ = self.bigru(hidden_states)  # [batch, seq_len, gru_hidden*2]
        
        # 注意力池化（全局特征）
        attention_weights = torch.softmax(
            self.gru_attention(gru_out).squeeze(-1), dim=1
        )  # [batch, seq_len]
        gru_features = torch.bmm(
            attention_weights.unsqueeze(1), gru_out
        ).squeeze(1)  # [batch, gru_hidden*2]
        
        # ===== CNN分支：局部特征提取 =====
        hidden_cnn = hidden_states.transpose(1, 2)  # [batch, 768, seq_len]
        
        cnn_features = []
        for conv in self.convs:
            conv_out = self.relu(conv(hidden_cnn))  # [batch, cnn_hidden, seq_len]
            pooled = torch.max(conv_out, dim=2)[0]   # [batch, cnn_hidden]
            cnn_features.append(pooled)
        
        cnn_features = torch.cat(cnn_features, dim=1)  # [batch, cnn_hidden*4]
        
        # ===== 特征融合 =====
        combined_features = torch.cat([gru_features, cnn_features], dim=1)
        fused_features = self.fusion(combined_features)
        fused_features = self.dropout(fused_features)
        
        # ===== 分类 =====
        logits = self.classifier(fused_features)
        
        return logits


# ==================== 训练和评估函数 ====================
def train_epoch(model, dataloader, optimizer, criterion, device):
    """训练一个epoch"""
    model.train()
    total_loss = 0
    all_preds = []
    all_labels = []
    
    for batch in dataloader:
        input_ids = batch['input_ids'].to(device)
        attention_mask = batch['attention_mask'].to(device)
        labels = batch['label'].to(device)
        
        optimizer.zero_grad()
        
        logits = model(input_ids, attention_mask)
        loss = criterion(logits, labels)
        
        loss.backward()
        torch.nn.utils.clip_grad_norm_(model.parameters(), max_norm=1.0)
        optimizer.step()
        
        total_loss += loss.item()
        
        preds = torch.argmax(logits, dim=1).cpu().numpy()
        all_preds.extend(preds)
        all_labels.extend(labels.cpu().numpy())
    
    avg_loss = total_loss / len(dataloader)
    accuracy = accuracy_score(all_labels, all_preds)
    
    return avg_loss, accuracy


def evaluate(model, dataloader, criterion, device):
    """评估模型"""
    model.eval()
    total_loss = 0
    all_preds = []
    all_labels = []
    
    with torch.no_grad():
        for batch in dataloader:
            input_ids = batch['input_ids'].to(device)
            attention_mask = batch['attention_mask'].to(device)
            labels = batch['label'].to(device)
            
            logits = model(input_ids, attention_mask)
            loss = criterion(logits, labels)
            
            total_loss += loss.item()
            
            preds = torch.argmax(logits, dim=1).cpu().numpy()
            all_preds.extend(preds)
            all_labels.extend(labels.cpu().numpy())
    
    avg_loss = total_loss / len(dataloader)
    accuracy = accuracy_score(all_labels, all_preds)
    precision, recall, f1, _ = precision_recall_fscore_support(
        all_labels, all_preds, average='macro', zero_division=0
    )
    
    return avg_loss, accuracy, precision, recall, f1


def train_model(model_name, model, train_loader, val_loader, optimizer, criterion, scheduler, num_epochs, device):
    """通用训练函数"""
    print(f"\n{'='*60}")
    print(f"开始训练: {model_name}")
    print(f"{'='*60}")
    
    best_val_acc = 0
    best_metrics = None
    patience_counter = 0
    patience = 5
    
    start_time = time.time()
    
    for epoch in range(num_epochs):
        epoch_start = time.time()
        
        # 训练
        train_loss, train_acc = train_epoch(model, train_loader, optimizer, criterion, device)
        
        # 验证
        val_loss, val_acc, val_prec, val_rec, val_f1 = evaluate(model, val_loader, criterion, device)
        
        epoch_time = time.time() - epoch_start
        
        print(f"Epoch [{epoch+1}/{num_epochs}] ({epoch_time:.1f}s)")
        print(f"  Train Loss: {train_loss:.4f}, Train Acc: {train_acc:.4f}")
        print(f"  Val Loss: {val_loss:.4f}, Val Acc: {val_acc:.4f}")
        print(f"  Val Prec: {val_prec:.4f}, Val Rec: {val_rec:.4f}, Val F1: {val_f1:.4f}")
        
        if val_acc > best_val_acc:
            best_val_acc = val_acc
            best_metrics = {
                'accuracy': val_acc,
                'precision': val_prec,
                'recall': val_rec,
                'f1': val_f1
            }
            torch.save(model.state_dict(), f'{model_name}_best.pth')
            print(f"  >> 保存最佳模型 (Val Acc: {val_acc:.4f})")
            patience_counter = 0
        else:
            patience_counter += 1
        
        if scheduler:
            scheduler.step()
        
        # 早停
        if patience_counter >= patience:
            print(f"\n早停触发！验证准确率{patience}个epoch未提升")
            break
    
    total_time = time.time() - start_time
    print(f"\n训练完成! 总耗时: {total_time/60:.1f}分钟")
    print(f"最佳验证准确率: {best_val_acc:.4f}")
    
    return best_metrics


# ==================== 主程序 ====================
def main():
    print("\n" + "="*80)
    print(" 古诗题材分类对比实验 - 最终版（4个模型）")
    print("="*80)
    
    # 1. 加载数据
    print("\n[1/6] 加载数据...")
    poems, labels, theme2id, id2theme = load_data('poems_jieba_merged.json')
    num_classes = len(theme2id)
    
    # 划分数据集
    X_temp, X_test, y_temp, y_test = train_test_split(
        list(range(len(poems))), labels, test_size=0.15, random_state=42, stratify=labels
    )
    X_train, X_val, y_train, y_val = train_test_split(
        X_temp, y_temp, test_size=0.15/(1-0.15), random_state=42, stratify=y_temp
    )
    
    print(f"训练集: {len(X_train)}, 验证集: {len(X_val)}, 测试集: {len(X_test)}")
    
    # 2. 计算类别权重
    print("\n[2/6] 计算类别权重...")
    class_counts = Counter(y_train)
    total_samples = len(y_train)
    class_weights = []
    for i in range(num_classes):
        count = class_counts.get(i, 1)
        weight = total_samples / (num_classes * count)
        class_weights.append(weight)
    
    class_weights = torch.FloatTensor(class_weights).to(device)
    print(f"类别权重: {class_weights.cpu().numpy()}")
    
    # 3. 准备数据加载器
    print("\n[3/6] 准备数据加载器...")
    tokenizer = BertTokenizer.from_pretrained(BERT_PATH)
    
    train_poems = [poems[i] for i in X_train]
    val_poems = [poems[i] for i in X_val]
    
    train_dataset = PoetryDataset(train_poems, y_train, tokenizer, MAX_LEN)
    val_dataset = PoetryDataset(val_poems, y_val, tokenizer, MAX_LEN)
    
    train_loader = DataLoader(train_dataset, batch_size=BATCH_SIZE, shuffle=True)
    val_loader = DataLoader(val_dataset, batch_size=BATCH_SIZE, shuffle=False)
    
    # 创建Focal Loss
    criterion = FocalLoss(alpha=class_weights, gamma=2.5)
    
    # 存储所有结果
    all_results = {}
    
    # ========== 模型1: BERT-TextCNN ==========
    print("\n[4/6] 训练模型1: BERT-TextCNN")
    model1 = BERTTextCNN(num_classes, BERT_PATH).to(device)
    
    bert_params1 = []
    other_params1 = []
    for name, param in model1.named_parameters():
        if 'bert' in name:
            bert_params1.append(param)
        else:
            other_params1.append(param)
    
    optimizer1 = optim.AdamW([
        {'params': bert_params1, 'lr': LEARNING_RATE_BERT},
        {'params': other_params1, 'lr': LEARNING_RATE_OTHER}
    ])
    scheduler1 = optim.lr_scheduler.CosineAnnealingLR(optimizer1, T_max=NUM_EPOCHS)
    
    metrics1 = train_model('BERT-TextCNN', model1, train_loader, val_loader, 
                          optimizer1, criterion, scheduler1, NUM_EPOCHS, device)
    all_results['BERT-TextCNN'] = metrics1
    
    # ========== 模型2: BERT-BiLSTM（修复版）==========
    print("\n[5/6] 训练模型2: BERT-BiLSTM（修复版）")
    model2 = BERTBiLSTM_Fixed(num_classes, BERT_PATH).to(device)
    
    bert_params2 = []
    other_params2 = []
    for name, param in model2.named_parameters():
        if 'bert' in name:
            bert_params2.append(param)
        else:
            other_params2.append(param)
    
    optimizer2 = optim.AdamW([
        {'params': bert_params2, 'lr': LEARNING_RATE_BERT},
        {'params': other_params2, 'lr': LEARNING_RATE_OTHER}
    ])
    scheduler2 = optim.lr_scheduler.CosineAnnealingLR(optimizer2, T_max=NUM_EPOCHS)
    
    metrics2 = train_model('BERT-BiLSTM', model2, train_loader, val_loader,
                          optimizer2, criterion, scheduler2, NUM_EPOCHS, device)
    all_results['BERT-BiLSTM'] = metrics2
    
    # ========== 模型3: BERT-TextCNN-BiLSTM ==========
    print("\n[6/6] 训练模型3: BERT-TextCNN-BiLSTM")
    model3 = BERTTextCNNBiLSTM(num_classes, BERT_PATH).to(device)
    
    bert_params3 = []
    other_params3 = []
    for name, param in model3.named_parameters():
        if 'bert' in name:
            bert_params3.append(param)
        else:
            other_params3.append(param)
    
    optimizer3 = optim.AdamW([
        {'params': bert_params3, 'lr': LEARNING_RATE_BERT},
        {'params': other_params3, 'lr': LEARNING_RATE_OTHER}
    ])
    scheduler3 = optim.lr_scheduler.CosineAnnealingLR(optimizer3, T_max=NUM_EPOCHS)
    
    metrics3 = train_model('BERT-TextCNN-BiLSTM', model3, train_loader, val_loader,
                          optimizer3, criterion, scheduler3, NUM_EPOCHS, device)
    all_results['BERT-TextCNN-BiLSTM'] = metrics3
    
    # ========== 模型4: BiGRU-CNN ==========
    print("\n[7/6] 训练模型4: BiGRU-CNN")
    model4 = BiGRU_CNN(num_classes, BERT_PATH).to(device)
    
    bert_params4 = []
    other_params4 = []
    for name, param in model4.named_parameters():
        if 'bert' in name:
            bert_params4.append(param)
        else:
            other_params4.append(param)
    
    optimizer4 = optim.AdamW([
        {'params': bert_params4, 'lr': LEARNING_RATE_BERT},
        {'params': other_params4, 'lr': LEARNING_RATE_OTHER}
    ])
    scheduler4 = optim.lr_scheduler.CosineAnnealingLR(optimizer4, T_max=NUM_EPOCHS)
    
    metrics4 = train_model('BiGRU-CNN', model4, train_loader, val_loader,
                          optimizer4, criterion, scheduler4, NUM_EPOCHS, device)
    all_results['BiGRU-CNN'] = metrics4
    
    # ========== 保存结果 ==========
    print("\n" + "="*80)
    print(" 所有模型训练完成！")
    print("="*80)
    
    # 打印汇总表格
    print("\n对比实验结果汇总：")
    print("-" * 80)
    print(f"{'模型':<30} {'准确率':>12} {'精确率':>12} {'召回率':>12} {'F1分数':>12}")
    print("-" * 80)
    
    for model_name in ['BERT-TextCNN', 'BERT-BiLSTM', 'BERT-TextCNN-BiLSTM', 'BiGRU-CNN']:
        m = all_results[model_name]
        print(f"{model_name:<30} {m['accuracy']*100:>11.2f}% {m['precision']*100:>11.2f}% "
              f"{m['recall']*100:>11.2f}% {m['f1']*100:>11.2f}%")
    print("-" * 80)
    
    # 保存为JSON
    with open('comparison_results_final.json', 'w', encoding='utf-8') as f:
        json.dump(all_results, f, ensure_ascii=False, indent=2)
    
    # 生成Origin格式数据
    with open('comparison_results_final_for_origin.csv', 'w', encoding='utf-8') as f:
        f.write("模型,准确率,精确率,召回率,F1分数\n")
        for model_name in ['BERT-TextCNN', 'BERT-BiLSTM', 'BERT-TextCNN-BiLSTM', 'BiGRU-CNN']:
            m = all_results[model_name]
            f.write(f"{model_name},{m['accuracy']*100:.2f},{m['precision']*100:.2f},"
                   f"{m['recall']*100:.2f},{m['f1']*100:.2f}\n")
    
    print("\n>> 结果已保存:")
    print("  - comparison_results_final.json")
    print("  - comparison_results_final_for_origin.csv")
    print("  - BERT-TextCNN_best.pth")
    print("  - BERT-BiLSTM_best.pth")
    print("  - BERT-TextCNN-BiLSTM_best.pth")
    print("  - BiGRU-CNN_best.pth")


if __name__ == '__main__':
    main()

