"""
导出4个对比模型的混淆矩阵数据，格式适用于Origin绘图软件
模型: BERT-TextCNN-BiLSTM, BERT-TextCNN, BiGRU-CNN, BERT-BiLSTM
"""

import json
import torch
import torch.nn as nn
import numpy as np
from torch.utils.data import Dataset, DataLoader
from transformers import BertModel, BertTokenizer
from sklearn.model_selection import train_test_split
from sklearn.metrics import confusion_matrix, accuracy_score, precision_recall_fscore_support
from tqdm import tqdm
import os

# 设置设备
device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
print(f"使用设备: {device}")

# 配置
BERT_PATH = './bert-base-chinese'
MAX_LEN = 128


# ==================== 模型定义 ====================
class BERTTextCNN(nn.Module):
    """BERT + TextCNN"""
    def __init__(self, num_classes, bert_path, hidden_dim=256, dropout=0.3):
        super(BERTTextCNN, self).__init__()
        
        self.bert = BertModel.from_pretrained(bert_path)
        bert_dim = self.bert.config.hidden_size
        
        for i, (name, param) in enumerate(self.bert.named_parameters()):
            if i < 100:
                param.requires_grad = False
        
        self.convs = nn.ModuleList([
            nn.Conv1d(bert_dim, hidden_dim, kernel_size=k, padding=k//2)
            for k in [2, 3, 4, 5]
        ])
        
        self.relu = nn.ReLU()
        self.dropout = nn.Dropout(dropout)
        
        self.fc = nn.Sequential(
            nn.Linear(hidden_dim * 4, hidden_dim),
            nn.BatchNorm1d(hidden_dim),
            nn.ReLU(),
            nn.Dropout(dropout),
            nn.Linear(hidden_dim, num_classes)
        )
    
    def forward(self, input_ids, attention_mask):
        bert_output = self.bert(input_ids=input_ids, attention_mask=attention_mask)
        hidden_states = bert_output.last_hidden_state
        hidden_cnn = hidden_states.transpose(1, 2)
        
        conv_outputs = []
        for conv in self.convs:
            conv_out = self.relu(conv(hidden_cnn))
            pooled = torch.max(conv_out, dim=2)[0]
            conv_outputs.append(pooled)
        
        features = torch.cat(conv_outputs, dim=1)
        features = self.dropout(features)
        
        logits = self.fc(features)
        return logits


class BERTBiLSTM_Fixed(nn.Module):
    """BERT + BiLSTM (Fixed with Attention)"""
    def __init__(self, num_classes, bert_path, hidden_dim=256, num_layers=2, dropout=0.2):
        super(BERTBiLSTM_Fixed, self).__init__()
        
        self.bert = BertModel.from_pretrained(bert_path)
        bert_dim = self.bert.config.hidden_size
        
        for i, (name, param) in enumerate(self.bert.named_parameters()):
            if i < 100:
                param.requires_grad = False
        
        self.bilstm = nn.LSTM(
            bert_dim,
            hidden_dim,
            num_layers=num_layers,
            batch_first=True,
            bidirectional=True,
            dropout=dropout if num_layers > 1 else 0
        )
        
        self.attention = nn.Linear(hidden_dim * 2, 1)
        
        self.fc = nn.Sequential(
            nn.Linear(hidden_dim * 2, hidden_dim),
            nn.BatchNorm1d(hidden_dim),
            nn.ReLU(),
            nn.Dropout(dropout),
            nn.Linear(hidden_dim, num_classes)
        )
    
    def forward(self, input_ids, attention_mask):
        bert_output = self.bert(input_ids=input_ids, attention_mask=attention_mask)
        hidden_states = bert_output.last_hidden_state
        
        lstm_out, _ = self.bilstm(hidden_states)
        
        attention_weights = torch.softmax(self.attention(lstm_out).squeeze(-1), dim=1)
        features = torch.bmm(attention_weights.unsqueeze(1), lstm_out).squeeze(1)
        
        logits = self.fc(features)
        return logits


class BERTTextCNNBiLSTM(nn.Module):
    """BERT + TextCNN + BiLSTM"""
    def __init__(self, num_classes, bert_path, hidden_dim=256, dropout=0.3):
        super(BERTTextCNNBiLSTM, self).__init__()
        
        self.bert = BertModel.from_pretrained(bert_path)
        bert_dim = self.bert.config.hidden_size
        
        for i, (name, param) in enumerate(self.bert.named_parameters()):
            if i < 100:
                param.requires_grad = False
        
        # TextCNN分支 (3个卷积核)
        self.convs = nn.ModuleList([
            nn.Conv1d(bert_dim, hidden_dim, kernel_size=k, padding=k//2)
            for k in [2, 3, 4]
        ])
        
        # BiLSTM分支
        self.bilstm = nn.LSTM(
            bert_dim,
            hidden_dim,
            num_layers=2,
            batch_first=True,
            bidirectional=True,
            dropout=dropout
        )
        
        self.relu = nn.ReLU()
        self.dropout = nn.Dropout(dropout)
        
        # 分类器 (CNN特征 + LSTM特征)
        self.fc = nn.Sequential(
            nn.Linear(hidden_dim * 3 + hidden_dim * 2, hidden_dim),
            nn.BatchNorm1d(hidden_dim),
            nn.ReLU(),
            nn.Dropout(dropout),
            nn.Linear(hidden_dim, num_classes)
        )
    
    def forward(self, input_ids, attention_mask):
        bert_output = self.bert(input_ids=input_ids, attention_mask=attention_mask)
        hidden_states = bert_output.last_hidden_state
        
        # TextCNN特征
        hidden_cnn = hidden_states.transpose(1, 2)
        conv_outputs = []
        for conv in self.convs:
            conv_out = self.relu(conv(hidden_cnn))
            pooled = torch.max(conv_out, dim=2)[0]
            conv_outputs.append(pooled)
        cnn_features = torch.cat(conv_outputs, dim=1)
        
        # BiLSTM特征 (平均池化)
        lstm_out, _ = self.bilstm(hidden_states)
        lstm_features = torch.mean(lstm_out, dim=1)
        
        # 特征融合
        features = torch.cat([cnn_features, lstm_features], dim=1)
        features = self.dropout(features)
        
        logits = self.fc(features)
        return logits


class BiGRU_CNN(nn.Module):
    """BiGRU + CNN"""
    def __init__(self, num_classes, bert_path, gru_hidden_dim=256, cnn_hidden_dim=256, 
                 num_gru_layers=2, dropout=0.3):
        super(BiGRU_CNN, self).__init__()
        
        self.bert = BertModel.from_pretrained(bert_path)
        bert_dim = self.bert.config.hidden_size
        
        for i, (name, param) in enumerate(self.bert.named_parameters()):
            if i < 100:
                param.requires_grad = False
        
        # BiGRU分支
        self.bigru = nn.GRU(
            bert_dim,
            gru_hidden_dim,
            num_layers=num_gru_layers,
            batch_first=True,
            bidirectional=True,
            dropout=dropout if num_gru_layers > 1 else 0
        )
        self.gru_attention = nn.Linear(gru_hidden_dim * 2, 1)
        
        # CNN分支
        self.convs = nn.ModuleList([
            nn.Conv1d(bert_dim, cnn_hidden_dim, kernel_size=k, padding=k//2)
            for k in [2, 3, 4, 5]
        ])
        
        self.relu = nn.ReLU()
        self.dropout = nn.Dropout(dropout)
        
        # 特征融合层
        fusion_dim = gru_hidden_dim * 2 + cnn_hidden_dim * 4
        self.fusion = nn.Sequential(
            nn.Linear(fusion_dim, fusion_dim // 2),
            nn.BatchNorm1d(fusion_dim // 2),
            nn.ReLU(),
            nn.Dropout(dropout)
        )
        
        # 分类器
        self.classifier = nn.Sequential(
            nn.Linear(fusion_dim // 2, 256),
            nn.BatchNorm1d(256),
            nn.ReLU(),
            nn.Dropout(dropout),
            nn.Linear(256, num_classes)
        )
    
    def forward(self, input_ids, attention_mask):
        # BERT编码
        bert_output = self.bert(input_ids=input_ids, attention_mask=attention_mask)
        hidden_states = bert_output.last_hidden_state
        
        # BiGRU分支
        gru_out, _ = self.bigru(hidden_states)
        attention_weights = torch.softmax(self.gru_attention(gru_out).squeeze(-1), dim=1)
        gru_features = torch.bmm(attention_weights.unsqueeze(1), gru_out).squeeze(1)
        
        # CNN分支
        hidden_cnn = hidden_states.transpose(1, 2)
        cnn_features = []
        for conv in self.convs:
            conv_out = self.relu(conv(hidden_cnn))
            pooled = torch.max(conv_out, dim=2)[0]
            cnn_features.append(pooled)
        cnn_features = torch.cat(cnn_features, dim=1)
        
        # 特征融合
        combined_features = torch.cat([gru_features, cnn_features], dim=1)
        fused_features = self.fusion(combined_features)
        fused_features = self.dropout(fused_features)
        
        # 分类
        logits = self.classifier(fused_features)
        
        return logits


# ==================== 数据集类 ====================
class ComparisonDataset(Dataset):
    """对比模型数据集"""
    def __init__(self, poems, labels, tokenizer, max_length=128):
        self.poems = poems
        self.labels = labels
        self.tokenizer = tokenizer
        self.max_length = max_length
    
    def __len__(self):
        return len(self.poems)
    
    def __getitem__(self, idx):
        poem = self.poems[idx]
        label = self.labels[idx]
        
        encoding = self.tokenizer(
            poem,
            max_length=self.max_length,
            padding='max_length',
            truncation=True,
            return_tensors='pt'
        )
        
        return {
            'input_ids': encoding['input_ids'].squeeze(0),
            'attention_mask': encoding['attention_mask'].squeeze(0),
            'label': torch.tensor(label, dtype=torch.long)
        }


# ==================== 评估函数 ====================
def evaluate_model(model, test_loader, id2theme):
    """评估模型并返回预测结果"""
    model.eval()
    
    all_preds = []
    all_labels = []
    
    with torch.no_grad():
        for batch in tqdm(test_loader, desc="评估中"):
            input_ids = batch['input_ids'].to(device)
            attention_mask = batch['attention_mask'].to(device)
            labels = batch['label'].to(device)
            
            outputs = model(input_ids, attention_mask)
            preds = torch.argmax(outputs, dim=1)
            
            all_preds.extend(preds.cpu().numpy())
            all_labels.extend(labels.cpu().numpy())
    
    return np.array(all_preds), np.array(all_labels)


def export_confusion_matrix(model_name, true_labels, pred_labels, themes, output_dir):
    """导出单个模型的混淆矩阵"""
    
    print(f"\n导出 {model_name} 的混淆矩阵...")
    
    # 计算混淆矩阵
    cm = confusion_matrix(true_labels, pred_labels)
    
    # 创建模型专属目录
    model_dir = os.path.join(output_dir, model_name.replace('-', '_'))
    os.makedirs(model_dir, exist_ok=True)
    
    # 1. CSV格式（Origin可直接导入）
    csv_file = os.path.join(model_dir, f'{model_name}_confusion_matrix.csv')
    with open(csv_file, 'w', encoding='utf-8-sig') as f:
        f.write('真实\\预测,' + ','.join(themes) + '\n')
        for i, theme in enumerate(themes):
            f.write(theme + ',' + ','.join(map(str, cm[i])) + '\n')
    
    print(f"  + CSV: {csv_file}")
    
    # 2. Origin矩阵格式
    origin_file = os.path.join(model_dir, f'{model_name}_confusion_matrix_origin.txt')
    with open(origin_file, 'w', encoding='utf-8-sig') as f:
        f.write('\t' + '\t'.join(themes) + '\n')
        for i, theme in enumerate(themes):
            f.write(theme + '\t' + '\t'.join(map(str, cm[i])) + '\n')
    
    print(f"  + Origin格式: {origin_file}")
    
    # 3. 归一化混淆矩阵
    cm_normalized = cm.astype('float') / cm.sum(axis=1)[:, np.newaxis] * 100
    normalized_csv = os.path.join(model_dir, f'{model_name}_confusion_matrix_normalized.csv')
    with open(normalized_csv, 'w', encoding='utf-8-sig') as f:
        f.write('真实\\预测,' + ','.join(themes) + '\n')
        for i, theme in enumerate(themes):
            f.write(theme + ',' + ','.join([f'{val:.2f}' for val in cm_normalized[i]]) + '\n')
    
    print(f"  + 归一化: {normalized_csv}")
    
    # 4. 计算指标
    accuracy = accuracy_score(true_labels, pred_labels)
    precision, recall, f1, _ = precision_recall_fscore_support(true_labels, pred_labels, average='weighted')
    
    # 5. 统计摘要
    summary = {
        '模型名称': model_name,
        '题材列表': themes,
        '混淆矩阵': cm.tolist(),
        '归一化混淆矩阵(%)': cm_normalized.tolist(),
        '每类样本数': [int(cm[i].sum()) for i in range(len(themes))],
        '每类准确率(%)': [float(cm_normalized[i][i]) for i in range(len(themes))],
        '总体准确率(%)': float(accuracy * 100),
        'Precision': float(precision),
        'Recall': float(recall),
        'F1-Score': float(f1)
    }
    
    summary_file = os.path.join(model_dir, f'{model_name}_summary.json')
    with open(summary_file, 'w', encoding='utf-8') as f:
        json.dump(summary, f, ensure_ascii=False, indent=2)
    
    print(f"  + 摘要: {summary_file}")
    
    # 打印混淆矩阵预览
    print(f"\n{model_name} 混淆矩阵预览:")
    print("真实\\预测   ", end="")
    for theme in themes:
        print(f"{theme[:4]:>8s}", end=" ")
    print()
    print("-" * 80)
    
    for i, theme in enumerate(themes):
        print(f"{theme:8s} ", end="")
        for j in range(len(themes)):
            print(f"{cm[i][j]:8d}", end=" ")
        print(f" ({cm_normalized[i][i]:.1f}%)")
    
    print(f"\n总体准确率: {accuracy * 100:.2f}%")
    print(f"Precision: {precision:.4f}, Recall: {recall:.4f}, F1-Score: {f1:.4f}")
    
    return cm, accuracy


# ==================== 主函数 ====================
def main():
    print("="*80)
    print(" 导出4个对比模型的混淆矩阵")
    print("="*80)
    
    # 加载数据
    print("\n1. 加载数据...")
    data_path = 'poems_jieba_merged.json'
    with open(data_path, 'r', encoding='utf-8') as f:
        data = json.load(f)
    
    # 创建标签映射
    unique_themes = sorted(list(set([item['theme'] for item in data])))
    label_map = {theme: idx for idx, theme in enumerate(unique_themes)}
    id2theme = {idx: theme for theme, idx in label_map.items()}
    num_classes = len(unique_themes)
    
    print(f"   数据总量: {len(data)}")
    print(f"   类别数量: {num_classes}")
    print(f"   类别列表: {unique_themes}")
    
    # 划分数据集
    _, test_data = train_test_split(data, test_size=0.15, random_state=42,
                                     stratify=[item['theme'] for item in data])
    
    test_poems = [item['poem'] for item in test_data]
    test_labels = [label_map[item['theme']] for item in test_data]
    
    print(f"   测试集样本: {len(test_data)}")
    
    # 加载tokenizer
    tokenizer = BertTokenizer.from_pretrained(BERT_PATH)
    test_dataset = ComparisonDataset(test_poems, test_labels, tokenizer, MAX_LEN)
    test_loader = DataLoader(test_dataset, batch_size=32, shuffle=False)
    
    # 定义4个模型
    models_info = [
        ('BERT-TextCNN-BiLSTM', BERTTextCNNBiLSTM, 'duibishiyan999999999/BERT-TextCNN-BiLSTM_best.pth', 
         {'num_classes': num_classes, 'bert_path': BERT_PATH, 'hidden_dim': 256, 'dropout': 0.3}),
        
        ('BERT-TextCNN', BERTTextCNN, 'duibishiyan999999999/BERT-TextCNN_best.pth',
         {'num_classes': num_classes, 'bert_path': BERT_PATH, 'hidden_dim': 256, 'dropout': 0.3}),
        
        ('BiGRU-CNN', BiGRU_CNN, 'duibishiyan999999999/BiGRU-CNN_best.pth',
         {'num_classes': num_classes, 'bert_path': BERT_PATH, 'gru_hidden_dim': 256,
          'cnn_hidden_dim': 256, 'num_gru_layers': 2, 'dropout': 0.3}),
        
        ('BERT-BiLSTM', BERTBiLSTM_Fixed, 'duibishiyan999999999/BERT-BiLSTM-Fixed_best_fixed.pth',
         {'num_classes': num_classes, 'bert_path': BERT_PATH, 'hidden_dim': 256,
          'num_layers': 2, 'dropout': 0.2})
    ]
    
    output_dir = 'confusion_matrices'
    os.makedirs(output_dir, exist_ok=True)
    
    all_results = {}
    
    # 逐个模型评估
    for i, (model_name, model_class, model_path, model_params) in enumerate(models_info):
        print(f"\n{'='*80}")
        print(f" [{i+1}/4] 处理 {model_name}")
        print(f"{'='*80}")
        
        # 加载模型
        print(f"\n2. 加载模型: {model_path}")
        model = model_class(**model_params)
        
        checkpoint = torch.load(model_path, map_location=device, weights_only=False)
        if 'model_state_dict' in checkpoint:
            model.load_state_dict(checkpoint['model_state_dict'])
        elif 'model' in checkpoint:
            model.load_state_dict(checkpoint['model'])
        else:
            model.load_state_dict(checkpoint)
        
        model.to(device)
        print("   模型加载成功!")
        
        # 评估
        print(f"\n3. 评估模型...")
        pred_labels, true_labels = evaluate_model(model, test_loader, id2theme)
        
        # 导出混淆矩阵
        print(f"\n4. 导出混淆矩阵...")
        cm, accuracy = export_confusion_matrix(
            model_name, true_labels, pred_labels, unique_themes, output_dir
        )
        
        all_results[model_name] = {
            'accuracy': float(accuracy),
            'confusion_matrix': cm.tolist()
        }
        
        # 释放内存
        del model
        torch.cuda.empty_cache()
        import gc
        gc.collect()
    
    # 保存汇总结果
    print(f"\n{'='*80}")
    print(" 保存汇总结果")
    print(f"{'='*80}")
    
    summary_all = {
        '模型列表': [info[0] for info in models_info],
        '模型结果': all_results,
        '类别列表': unique_themes
    }
    
    summary_all_file = os.path.join(output_dir, 'all_models_summary.json')
    with open(summary_all_file, 'w', encoding='utf-8') as f:
        json.dump(summary_all, f, ensure_ascii=False, indent=2)
    
    print(f"\n汇总文件: {summary_all_file}")
    
    # 打印所有模型的准确率对比
    print(f"\n{'='*80}")
    print(" 模型准确率对比")
    print(f"{'='*80}")
    
    for model_name in all_results:
        acc = all_results[model_name]['accuracy']
        print(f"  {model_name:25s}: {acc*100:.2f}%")
    
    print(f"\n{'='*80}")
    print(" 导出完成!")
    print(f"{'='*80}")
    print(f"\n所有文件保存在: {output_dir}/")
    print("\n每个模型的文件:")
    print("  - <模型名>_confusion_matrix.csv (Origin可直接导入)")
    print("  - <模型名>_confusion_matrix_origin.txt (Origin矩阵格式)")
    print("  - <模型名>_confusion_matrix_normalized.csv (归一化百分比)")
    print("  - <模型名>_summary.json (统计摘要)")
    
    print("\n" + "="*80)
    print(" Origin绘图指南")
    print("="*80)
    print("""
在Origin中绘制混淆矩阵热图:
  1. 打开Origin软件
  2. File -> Import -> Single ASCII...
  3. 选择对应模型的 *_confusion_matrix.csv 文件
  4. 导入后选中数据(不含表头)
  5. Plot -> Contour -> Heat Map
  6. 调整颜色方案和标签大小
    """)


if __name__ == '__main__':
    main()

