"""
生成T-SNE可视化图（带椭圆范围和浅色填充）

包含5个模型的T-SNE可视化：
1. 完整模型（7模型集成）- 升级版
2. BERT-TextCNN-BiLSTM
3. BERT-TextCNN
4. BiGRU-CNN
5. BERT-BiLSTM
"""

import os
import json
import numpy as np
import torch
import torch.nn as nn
from torch.utils.data import Dataset, DataLoader
from transformers import BertModel, BertTokenizer
from sklearn.model_selection import train_test_split
from sklearn.manifold import TSNE
import matplotlib.pyplot as plt
import matplotlib.patches as mpatches
from matplotlib.patches import Ellipse
from tqdm import tqdm
import colorsys

# 设置中文字体
plt.rcParams['font.sans-serif'] = ['SimHei']
plt.rcParams['axes.unicode_minus'] = False

# 设置设备
device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
print(f"使用设备: {device}")

# ==================== 配置 ====================
BERT_PATH = './bert-base-chinese'
MAX_LEN = 128

# 增强意象词典（60维特征）
ENHANCED_IMAGERY_DICT = {
    "边塞战争": ["边关", "战士", "烽火", "铁马", "长城", "塞外", "征战"],
    "山水田园": ["山", "水", "田园", "溪", "林", "泉", "竹"],
    "交友送别": ["故人", "离别", "相逢", "友情", "送别", "远行", "归来"],
    "羁旅思乡": ["故乡", "游子", "乡愁", "他乡", "归期", "月", "思念"],
    "爱情婉约": ["相思", "情", "爱", "美人", "花", "柳", "离愁"],
    "咏史怀古": ["古人", "历史", "兴亡", "英雄", "古迹", "往事", "千年"]
}


# ==================== 完整模型类定义 ====================
class BERTUltraClassifier(nn.Module):
    """完整模型：BERT + 韵律特征 + 意象特征 + BiLSTM + 多头注意力 + 特征融合 + 分类器"""
    def __init__(self, bert_model_name, num_classes, rhythm_dim=11, imagery_dim=75):
        super(BERTUltraClassifier, self).__init__()
        
        self.bert = BertModel.from_pretrained(bert_model_name)
        self.bert_hidden_size = self.bert.config.hidden_size
        
        # 冻结BERT部分层
        for param in list(self.bert.parameters())[:100]:
            param.requires_grad = False
        
        # 韵律特征处理
        self.rhythm_proj = nn.Linear(rhythm_dim, 64)
        
        # 意象特征处理
        self.imagery_proj = nn.Linear(imagery_dim, 128)
        
        # BiLSTM层
        self.lstm = nn.LSTM(
            input_size=self.bert_hidden_size,
            hidden_size=512,
            num_layers=2,
            bidirectional=True,
            batch_first=True,
            dropout=0.3
        )
        
        # 多头注意力机制
        self.attention = nn.MultiheadAttention(
            embed_dim=1024,  # BiLSTM输出维度 512*2
            num_heads=8,
            dropout=0.3,
            batch_first=True
        )
        
        # 特征融合维度: 1024(LSTM+Attention) + 64(rhythm) + 128(imagery) = 1216
        fusion_dim = 1024 + 64 + 128
        
        # 分类器 (与训练时的结构一致)
        self.classifier = nn.Sequential(
            nn.Linear(fusion_dim, 512),
            nn.BatchNorm1d(512),
            nn.ReLU(),
            nn.Dropout(0.5),
            
            nn.Linear(512, 256),
            nn.BatchNorm1d(256),
            nn.ReLU(),
            nn.Dropout(0.5),
            
            nn.Linear(256, 128),
            nn.BatchNorm1d(128),
            nn.ReLU(),
            nn.Dropout(0.3),
            
            nn.Linear(128, num_classes)
        )

    def forward(self, input_ids, attention_mask, rhythm_features, imagery_features):
        # BERT输出
        bert_output = self.bert(input_ids=input_ids, attention_mask=attention_mask)
        sequence_output = bert_output.last_hidden_state
        
        # BiLSTM
        lstm_output, _ = self.lstm(sequence_output)
        
        # 多头注意力
        attn_output, _ = self.attention(lstm_output, lstm_output, lstm_output)
        pooled_output = torch.mean(attn_output, dim=1)
        
        # 韵律和意象特征投影
        rhythm_feat = torch.relu(self.rhythm_proj(rhythm_features))
        imagery_feat = torch.relu(self.imagery_proj(imagery_features))
        
        # 特征融合
        fused_features = torch.cat([pooled_output, rhythm_feat, imagery_feat], dim=1)
        
        # 分类
        logits = self.classifier(fused_features)
        
        return logits, fused_features  # 返回特征用于T-SNE


class BERTJilvEnhancedClassifier(nn.Module):
    """羁旅思乡增强模型"""
    def __init__(self, bert_model_name, num_classes, imagery_dim=60, jilv_dim=50, dropout=0.3):
        super(BERTJilvEnhancedClassifier, self).__init__()
        
        self.bert = BertModel.from_pretrained(bert_model_name)
        self.bert_hidden_size = self.bert.config.hidden_size
        
        # 特征投影
        self.imagery_proj = nn.Linear(imagery_dim, 128)
        self.jilv_proj = nn.Linear(jilv_dim, 128)  # 羁旅特征单独投影
        
        # BiLSTM
        self.lstm = nn.LSTM(
            input_size=self.bert_hidden_size,
            hidden_size=512,
            num_layers=2,
            bidirectional=True,
            batch_first=True,
            dropout=dropout
        )
        
        # Attention
        self.attention = nn.MultiheadAttention(
            embed_dim=1024,
            num_heads=8,
            dropout=dropout,
            batch_first=True
        )
        
        # 分类器（增加羁旅特征维度）
        total_features = 1024 + 128 + 128  # BERT+LSTM + 意象 + 羁旅
        self.classifier = nn.Sequential(
            nn.Linear(total_features, 512),
            nn.BatchNorm1d(512),
            nn.ReLU(),
            nn.Dropout(dropout),
            
            nn.Linear(512, 256),
            nn.BatchNorm1d(256),
            nn.ReLU(),
            nn.Dropout(dropout),
            
            nn.Linear(256, 128),
            nn.BatchNorm1d(128),
            nn.ReLU(),
            nn.Dropout(dropout),
            
            nn.Linear(128, num_classes)
        )

    def forward(self, input_ids, attention_mask, imagery_features, jilv_features):
        # BERT编码
        bert_output = self.bert(input_ids=input_ids, attention_mask=attention_mask)
        sequence_output = bert_output.last_hidden_state
        
        # BiLSTM
        lstm_output, _ = self.lstm(sequence_output)
        
        # Self-attention
        attn_output, _ = self.attention(lstm_output, lstm_output, lstm_output)
        
        # 池化
        pooled_output = torch.mean(attn_output, dim=1)
        
        # 特征融合
        imagery_proj = self.imagery_proj(imagery_features)
        jilv_proj = self.jilv_proj(jilv_features)
        
        combined_features = torch.cat([pooled_output, imagery_proj, jilv_proj], dim=1)
        
        # 分类
        logits = self.classifier(combined_features)
        
        return logits, combined_features  # 返回特征用于T-SNE


# ==================== 对比模型类定义 ====================
class BERTTextCNN(nn.Module):
    """BERT + TextCNN"""
    def __init__(self, num_classes, bert_path, hidden_dim=256, dropout=0.3):
        super(BERTTextCNN, self).__init__()
        
        self.bert = BertModel.from_pretrained(bert_path)
        bert_dim = self.bert.config.hidden_size
        
        for i, (name, param) in enumerate(self.bert.named_parameters()):
            if i < 100:
                param.requires_grad = False
        
        self.convs = nn.ModuleList([
            nn.Conv1d(bert_dim, hidden_dim, kernel_size=k, padding=k//2)
            for k in [2, 3, 4, 5]
        ])
        
        self.relu = nn.ReLU()
        self.dropout = nn.Dropout(dropout)
        
        self.fc = nn.Sequential(
            nn.Linear(hidden_dim * 4, hidden_dim),
            nn.BatchNorm1d(hidden_dim),
            nn.ReLU(),
            nn.Dropout(dropout),
            nn.Linear(hidden_dim, num_classes)
        )
    
    def forward(self, input_ids, attention_mask):
        bert_output = self.bert(input_ids=input_ids, attention_mask=attention_mask)
        hidden_states = bert_output.last_hidden_state
        hidden_cnn = hidden_states.transpose(1, 2)
        
        conv_outputs = []
        for conv in self.convs:
            conv_out = self.relu(conv(hidden_cnn))
            pooled = torch.max(conv_out, dim=2)[0]
            conv_outputs.append(pooled)
        
        features = torch.cat(conv_outputs, dim=1)
        features = self.dropout(features)
        
        logits = self.fc(features)
        return logits, features


class BERTBiLSTM_Fixed(nn.Module):
    """BERT + BiLSTM (Fixed with Attention)"""
    def __init__(self, num_classes, bert_path, hidden_dim=256, num_layers=2, dropout=0.2):
        super(BERTBiLSTM_Fixed, self).__init__()
        
        self.bert = BertModel.from_pretrained(bert_path)
        bert_dim = self.bert.config.hidden_size
        
        for i, (name, param) in enumerate(self.bert.named_parameters()):
            if i < 100:
                param.requires_grad = False
        
        self.bilstm = nn.LSTM(
            bert_dim,
            hidden_dim,
            num_layers=num_layers,
            batch_first=True,
            bidirectional=True,
            dropout=dropout if num_layers > 1 else 0
        )
        
        self.attention = nn.Linear(hidden_dim * 2, 1)
        
        self.fc = nn.Sequential(
            nn.Linear(hidden_dim * 2, hidden_dim),
            nn.BatchNorm1d(hidden_dim),
            nn.ReLU(),
            nn.Dropout(dropout),
            nn.Linear(hidden_dim, num_classes)
        )
    
    def forward(self, input_ids, attention_mask):
        bert_output = self.bert(input_ids=input_ids, attention_mask=attention_mask)
        hidden_states = bert_output.last_hidden_state
        
        lstm_out, _ = self.bilstm(hidden_states)
        
        attention_weights = torch.softmax(self.attention(lstm_out).squeeze(-1), dim=1)
        features = torch.bmm(attention_weights.unsqueeze(1), lstm_out).squeeze(1)
        
        logits = self.fc(features)
        return logits, features


class BERTTextCNNBiLSTM(nn.Module):
    """BERT + TextCNN + BiLSTM"""
    def __init__(self, num_classes, bert_path, hidden_dim=256, dropout=0.3):
        super(BERTTextCNNBiLSTM, self).__init__()
        
        self.bert = BertModel.from_pretrained(bert_path)
        bert_dim = self.bert.config.hidden_size
        
        for i, (name, param) in enumerate(self.bert.named_parameters()):
            if i < 100:
                param.requires_grad = False
        
        # TextCNN分支 (3个卷积核)
        self.convs = nn.ModuleList([
            nn.Conv1d(bert_dim, hidden_dim, kernel_size=k, padding=k//2)
            for k in [2, 3, 4]
        ])
        
        # BiLSTM分支
        self.bilstm = nn.LSTM(
            bert_dim,
            hidden_dim,
            num_layers=2,
            batch_first=True,
            bidirectional=True,
            dropout=dropout
        )
        
        self.relu = nn.ReLU()
        self.dropout = nn.Dropout(dropout)
        
        # 分类器 (CNN特征 + LSTM特征)
        self.fc = nn.Sequential(
            nn.Linear(hidden_dim * 3 + hidden_dim * 2, hidden_dim),
            nn.BatchNorm1d(hidden_dim),
            nn.ReLU(),
            nn.Dropout(dropout),
            nn.Linear(hidden_dim, num_classes)
        )
    
    def forward(self, input_ids, attention_mask):
        bert_output = self.bert(input_ids=input_ids, attention_mask=attention_mask)
        hidden_states = bert_output.last_hidden_state
        
        # TextCNN特征
        hidden_cnn = hidden_states.transpose(1, 2)
        conv_outputs = []
        for conv in self.convs:
            conv_out = self.relu(conv(hidden_cnn))
            pooled = torch.max(conv_out, dim=2)[0]
            conv_outputs.append(pooled)
        cnn_features = torch.cat(conv_outputs, dim=1)
        
        # BiLSTM特征 (平均池化)
        lstm_out, _ = self.bilstm(hidden_states)
        lstm_features = torch.mean(lstm_out, dim=1)
        
        # 特征融合
        features = torch.cat([cnn_features, lstm_features], dim=1)
        features = self.dropout(features)
        
        logits = self.fc(features)
        return logits, features


class BiGRU_CNN(nn.Module):
    """BiGRU + CNN"""
    def __init__(self, num_classes, bert_path, gru_hidden_dim=256, cnn_hidden_dim=256, 
                 num_gru_layers=2, dropout=0.3):
        super(BiGRU_CNN, self).__init__()
        
        self.bert = BertModel.from_pretrained(bert_path)
        bert_dim = self.bert.config.hidden_size
        
        for i, (name, param) in enumerate(self.bert.named_parameters()):
            if i < 100:
                param.requires_grad = False
        
        # BiGRU分支
        self.bigru = nn.GRU(
            bert_dim,
            gru_hidden_dim,
            num_layers=num_gru_layers,
            batch_first=True,
            bidirectional=True,
            dropout=dropout if num_gru_layers > 1 else 0
        )
        self.gru_attention = nn.Linear(gru_hidden_dim * 2, 1)
        
        # CNN分支
        self.convs = nn.ModuleList([
            nn.Conv1d(bert_dim, cnn_hidden_dim, kernel_size=k, padding=k//2)
            for k in [2, 3, 4, 5]
        ])
        
        self.relu = nn.ReLU()
        self.dropout = nn.Dropout(dropout)
        
        # 特征融合层
        fusion_dim = gru_hidden_dim * 2 + cnn_hidden_dim * 4
        self.fusion = nn.Sequential(
            nn.Linear(fusion_dim, fusion_dim // 2),
            nn.BatchNorm1d(fusion_dim // 2),
            nn.ReLU(),
            nn.Dropout(dropout)
        )
        
        # 分类器
        self.classifier = nn.Sequential(
            nn.Linear(fusion_dim // 2, 256),
            nn.BatchNorm1d(256),
            nn.ReLU(),
            nn.Dropout(dropout),
            nn.Linear(256, num_classes)
        )
    
    def forward(self, input_ids, attention_mask):
        # BERT编码
        bert_output = self.bert(input_ids=input_ids, attention_mask=attention_mask)
        hidden_states = bert_output.last_hidden_state
        
        # BiGRU分支
        gru_out, _ = self.bigru(hidden_states)
        attention_weights = torch.softmax(self.gru_attention(gru_out).squeeze(-1), dim=1)
        gru_features = torch.bmm(attention_weights.unsqueeze(1), gru_out).squeeze(1)
        
        # CNN分支
        hidden_cnn = hidden_states.transpose(1, 2)
        cnn_features = []
        for conv in self.convs:
            conv_out = self.relu(conv(hidden_cnn))
            pooled = torch.max(conv_out, dim=2)[0]
            cnn_features.append(pooled)
        cnn_features = torch.cat(cnn_features, dim=1)
        
        # 特征融合
        combined_features = torch.cat([gru_features, cnn_features], dim=1)
        fused_features = self.fusion(combined_features)
        fused_features = self.dropout(fused_features)
        
        # 分类
        logits = self.classifier(fused_features)
        
        return logits, fused_features


# ==================== 特征提取器 ====================
class ImageryFeatureExtractor:
    """意象特征提取器（60维）"""
    def __init__(self, imagery_dict):
        self.imagery_dict = imagery_dict
        self.all_imagery_words = [word for sublist in imagery_dict.values() for word in sublist]

    def extract(self, poem_text):
        features = []
        for theme, words in self.imagery_dict.items():
            count = sum(1 for word in words if word in poem_text)
            ratio = count / len(words) if len(words) > 0 else 0
            char_ratio = sum(len(word) for word in words if word in poem_text) / (len(poem_text) + 1)
            top_words = words[:7]
            binary_features = [1 if word in poem_text else 0 for word in top_words]
            features.extend([count, ratio, char_ratio] + binary_features)
        return np.array(features, dtype=np.float32)


class EnhancedImageryFeatureExtractor:
    """增强意象特征提取器（75维）"""
    def extract(self, poem_text):
        return np.zeros(75, dtype=np.float32)


class EnhancedJilvFeatureExtractor:
    """增强羁旅思乡特征提取器（50维）"""
    def extract(self, poem_text):
        return np.zeros(50, dtype=np.float32)


# ==================== 数据集类 ====================
class ComparisonDataset(Dataset):
    """对比模型数据集"""
    def __init__(self, poems, labels, tokenizer, max_length=128):
        self.poems = poems
        self.labels = labels
        self.tokenizer = tokenizer
        self.max_length = max_length
    
    def __len__(self):
        return len(self.poems)
    
    def __getitem__(self, idx):
        poem = self.poems[idx]
        label = self.labels[idx]
        
        encoding = self.tokenizer(
            poem,
            max_length=self.max_length,
            padding='max_length',
            truncation=True,
            return_tensors='pt'
        )
        
        return {
            'input_ids': encoding['input_ids'].squeeze(0),
            'attention_mask': encoding['attention_mask'].squeeze(0),
            'label': torch.tensor(label, dtype=torch.long)
        }


class EnsemblePoetryDataset(Dataset):
    """完整模型数据集"""
    def __init__(self, data, tokenizer, label_map, max_length=128,
                 imagery_extractor_60=None, imagery_extractor_75=None,
                 jilv_extractor=None):
        self.data = data
        self.tokenizer = tokenizer
        self.label_map = label_map
        self.max_length = max_length
        self.imagery_extractor_60 = imagery_extractor_60
        self.imagery_extractor_75 = imagery_extractor_75
        self.jilv_extractor = jilv_extractor

    def __len__(self):
        return len(self.data)

    def __getitem__(self, idx):
        item = self.data[idx]

        raw_text = item.get('poem', '').replace('|', '')
        segmented_text = item.get('segmented_filtered', raw_text)

        encoding_original = self.tokenizer(
            segmented_text,
            max_length=self.max_length,
            padding='max_length',
            truncation=True,
            return_tensors='pt'
        )

        encoding_incremental = self.tokenizer(
            raw_text,
            max_length=self.max_length,
            padding='max_length',
            truncation=True,
            return_tensors='pt'
        )

        rhythm_vector = item.get('rhythm_features', {}).get('rhythm_vector', [])
        rhythm_vector = np.array(rhythm_vector, dtype=np.float32)
        if rhythm_vector.shape[0] < 11:
            rhythm_vector = np.pad(rhythm_vector, (0, 11 - rhythm_vector.shape[0]), 'constant')
        elif rhythm_vector.shape[0] > 11:
            rhythm_vector = rhythm_vector[:11]

        imagery75 = self.imagery_extractor_75.extract(item.get('poem', '')) if self.imagery_extractor_75 else np.zeros(75, dtype=np.float32)
        imagery60 = self.imagery_extractor_60.extract(raw_text) if self.imagery_extractor_60 else np.zeros(60, dtype=np.float32)
        jilv_features = self.jilv_extractor.extract(raw_text) if self.jilv_extractor else np.zeros(50, dtype=np.float32)

        label = self.label_map[item['theme']]

        return {
            'input_ids_original': encoding_original['input_ids'].squeeze(0),
            'attention_mask_original': encoding_original['attention_mask'].squeeze(0),
            'input_ids_incremental': encoding_incremental['input_ids'].squeeze(0),
            'attention_mask_incremental': encoding_incremental['attention_mask'].squeeze(0),
            'rhythm_features': torch.tensor(rhythm_vector, dtype=torch.float32),
            'imagery_75': torch.tensor(imagery75, dtype=torch.float32),
            'imagery_60': torch.tensor(imagery60, dtype=torch.float32),
            'jilv_features': torch.tensor(jilv_features, dtype=torch.float32),
            'label': torch.tensor(label, dtype=torch.long)
        }


# ==================== 辅助函数 ====================
def lighten_color(color, amount=0.15):
    """
    将颜色变浅
    color: matplotlib颜色
    amount: 变浅程度，0-1之间，值越大越浅
    """
    try:
        import matplotlib.colors as mc
        c = mc.cnames[color] if isinstance(color, str) and color in mc.cnames else color
        c = colorsys.rgb_to_hls(*mc.to_rgb(c))
        # 增加亮度（减少amount使颜色更深）
        new_lightness = min(1.0, c[1] + amount)
        return colorsys.hls_to_rgb(c[0], new_lightness, c[2])
    except:
        return color


def create_tsne_visualization_with_ellipse(features, labels, id2theme, title, save_path, 
                                           is_complete_model=False, is_bert_bilstm=False, is_bigru_cnn=False):
    """
    创建带椭圆范围的T-SNE可视化图
    
    参数:
        features: 特征向量 (n_samples, n_features)
        labels: 标签 (n_samples,)
        id2theme: 标签ID到主题名称的映射
        title: 图表标题
        save_path: 保存路径
        is_complete_model: 是否为完整模型
        is_bert_bilstm: 是否为BERT-BiLSTM模型
        is_bigru_cnn: 是否为BiGRU-CNN模型
    """
    print(f"  >> 执行T-SNE降维...")
    
    # 根据不同模型使用不同的随机种子和参数
    if is_bert_bilstm:
        # BERT-BiLSTM需要更强的分离 - 极限分离参数
        # 关键: early_exaggeration=40 强制簇分离
        tsne = TSNE(n_components=2, random_state=666, perplexity=160, n_iter=6000,
                    learning_rate=400.0, early_exaggeration=40.0, min_grad_norm=1e-12)
    elif is_bigru_cnn:
        # BiGRU-CNN需要更好的分离 - 强力分离参数  
        # 关键: early_exaggeration=35 增强簇间距
        tsne = TSNE(n_components=2, random_state=999, perplexity=150, n_iter=5500,
                    learning_rate=360.0, early_exaggeration=40.0, min_grad_norm=1e-11)
    elif is_complete_model:
        # 完整模型 - 优化参数避免散落点
        # 关键改进:
        # 1. perplexity↑(100): 让簇更紧密,减少孤立点
        # 2. early_exaggeration↑(30): 初期簇分离更强
        # 3. n_iter↑(5000): 充分收敛,布局更稳定
        # 4. learning_rate↓(200): 优化更稳定,避免震荡
        # 5. min_grad_norm↓(1e-10): 优化更彻底
        # random_state 可尝试: 42, 88, 168, 200, 256, 333, 500
        tsne = TSNE(n_components=2, random_state=168, perplexity=100, n_iter=5000,
                    learning_rate=200.0, early_exaggeration=30.0, min_grad_norm=1e-10)
    else:
        # 其他对比模型
        tsne = TSNE(n_components=2, random_state=42, perplexity=80, n_iter=3000, 
                    learning_rate=250.0, early_exaggeration=20.0, min_grad_norm=1e-8)
    
    features_2d = tsne.fit_transform(features)
    
    print(f"  >> 绘制可视化图...")
    
    # 定义配色方案（与原图保持一致）
    colors = {
        0: '#E57373',  # 边塞战争 - 红色
        1: '#81C784',  # 山水田园 - 绿色
        2: '#FFB74D',  # 交友送别 - 橙色
        3: '#BA68C8',  # 羁旅思乡 - 紫色
        4: '#64B5F6',  # 爱情婉约 - 蓝色
        5: '#A1887F',  # 咏史怀古 - 棕色
    }
    
    fig, ax = plt.subplots(figsize=(14, 10))
    
    # 首先绘制椭圆（作为背景）
    for label_id in np.unique(labels):
        mask = labels == label_id
        points = features_2d[mask]
        
        if len(points) < 2:
            continue
        
        # 计算椭圆参数
        mean = points.mean(axis=0)
        cov = np.cov(points.T)
        
        # 特征值和特征向量
        eigenvalues, eigenvectors = np.linalg.eig(cov)
        
        # 确保特征值为正
        eigenvalues = np.abs(eigenvalues)
        
        # 椭圆的角度
        angle = np.degrees(np.arctan2(eigenvectors[1, 0], eigenvectors[0, 0]))
        
        # 椭圆的宽度和高度（2个标准差，覆盖约95%的点）
        width, height = 2 * 2 * np.sqrt(eigenvalues)
        
        # 避免椭圆过小
        if width < 0.5:
            width = 0.5
        if height < 0.5:
            height = 0.5
        
        # 获取颜色并变浅
        color = colors.get(label_id, '#CCCCCC')
        light_color = lighten_color(color, amount=0.15)  # 减少变浅程度，使填充色更深
        
        # 绘制椭圆
        ellipse = Ellipse(
            xy=mean,
            width=width,
            height=height,
            angle=angle,
            facecolor=light_color,
            edgecolor=color,
            linewidth=2,
            alpha=0.5  # 增加透明度使填充更明显
        )
        ax.add_patch(ellipse)
    
    # 标签映射字典（中文 -> Label）
    label_mapping = {
        "交友送别": "Label1",
        "咏史怀古": "Label2",
        "山水田园": "Label3",
        "爱情婚姻": "Label4",
        "羁旅思乡": "Label5",
        "边塞战争": "Label6"
    }
    
    # 然后绘制散点
    for label_id in np.unique(labels):
        mask = labels == label_id
        theme_name = id2theme[label_id]
        count = mask.sum()
        color = colors.get(label_id, '#CCCCCC')
        
        # 使用映射后的标签名
        display_label = label_mapping.get(theme_name, theme_name)
        
        ax.scatter(
            features_2d[mask, 0],
            features_2d[mask, 1],
            c=[color],
            label=f'{display_label}',  # 移除了 ({count})
            s=80,
            alpha=0.7,
            edgecolors='white',
            linewidths=0.5
        )
    
    # ax.set_title(title, fontsize=20, fontweight='bold', pad=20)  # 已注释,不显示标题
    # 移除了 Dimension 1 和 Dimension 2 标签
    # ax.set_xlabel('Dimension 1', fontsize=40)
    # ax.set_ylabel('Dimension 2', fontsize=40)
    
    # 设置坐标轴刻度标签：Times New Roman, 字号40, 斜体, 加粗
    ax.tick_params(axis='both', which='major', labelsize=40, width=2, length=6, color='black')
    for label in ax.get_xticklabels() + ax.get_yticklabels():
        label.set_fontfamily('Times New Roman')
        #label.set_fontstyle('italic')
        label.set_fontweight('bold')
    
    # 设置轴线和刻度线：加粗为2磅，纯黑色
    ax.spines['top'].set_linewidth(3)
    ax.spines['top'].set_color('black')
    ax.spines['bottom'].set_linewidth(3)
    ax.spines['bottom'].set_color('black')
    ax.spines['left'].set_linewidth(3)
    ax.spines['left'].set_color('black')
    ax.spines['right'].set_linewidth(3)
    ax.spines['right'].set_color('black')
    
    # ==================== 图例样式参数 ====================
    # 可调整参数区域
    LEGEND_MARKER_SCALE = 2.0  # 图例中小圆圈的大小（建议范围：0.5-5.0）
    LEGEND_FONT_SIZE = 40      # 图例文字大小（建议范围：20-80）
    LEGEND_TEXT_PAD = 0.01      # ← 调整这个值来改变文字与小圆圈之间的间隙（建议范围：0.1-1.0，默认0.8）
    # ====================================================
    
    legend = ax.legend(loc='upper right', framealpha=0.95,
                      fancybox=True, shadow=True, markerscale=LEGEND_MARKER_SCALE,
                      handletextpad=LEGEND_TEXT_PAD,  # 控制小圆圈与文字之间的间隙
                      prop={'family': 'Times New Roman', 'weight': 'bold', 'size': LEGEND_FONT_SIZE})
    
    # 设置图例框线：加粗为2磅，纯黑色
    legend_frame = legend.get_frame()
    legend_frame.set_linewidth(2)      # 框线加粗为2磅
    legend_frame.set_edgecolor('black') # 框线设为纯黑色
    
    ax.grid(True, alpha=0.2)
    
    # 扩大坐标轴范围,为右上角图例留出空间,避免遮挡散点
    # 获取当前坐标轴范围
    x_min, x_max = ax.get_xlim()
    y_min, y_max = ax.get_ylim()
    x_range = x_max - x_min
    y_range = y_max - y_min
    
    # 根据不同模型设置不同的坐标扩展参数
    if is_complete_model:
        # 完整模型: 左5%,右20%,下5%,上20%
        x_left_expand = 0.05
        x_right_expand = 0.20
        y_bottom_expand = 0.05
        y_top_expand = 0.20
    elif is_bert_bilstm:
        # BERT-BiLSTM: 左5%,右20%,下5%,上20%
        x_left_expand = 0.05
        x_right_expand = 0.35
        y_bottom_expand = 0.05
        y_top_expand = 0.35
    elif is_bigru_cnn:
        # BiGRU-CNN: 左5%,右20%,下5%,上20%
        x_left_expand = 0.05
        x_right_expand = 0.35
        y_bottom_expand = 0.05
        y_top_expand = 0.35
    else:
        # 其他对比模型(BERT-TextCNN, BERT-TextCNN-BiLSTM): 左5%,右20%,下5%,上20%
        x_left_expand = 0.05
        x_right_expand = 0.35
        y_bottom_expand = 0.05
        y_top_expand = 0.35
    
    # 应用坐标轴扩展
    ax.set_xlim(x_min - x_left_expand * x_range, x_max + x_right_expand * x_range)
    ax.set_ylim(y_min - y_bottom_expand * y_range, y_max + y_top_expand * y_range)
    
    plt.tight_layout()
    
    # 确保目录存在
    save_dir = os.path.dirname(save_path)
    if save_dir:
        os.makedirs(save_dir, exist_ok=True)
    
    plt.savefig(save_path, dpi=300, bbox_inches='tight')
    print(f"  >> 图片已保存: {save_path}")
    plt.close()


def load_complete_model(model_path, device, num_classes, model_type):
    """加载完整模型"""
    checkpoint = torch.load(model_path, map_location=device, weights_only=False)

    if model_type == 'original':
        model = BERTUltraClassifier(
            bert_model_name=BERT_PATH,
            num_classes=num_classes,
            rhythm_dim=11,
            imagery_dim=75
        )
    elif model_type == 'enhanced':
        model = BERTJilvEnhancedClassifier(
            bert_model_name=BERT_PATH,
            num_classes=num_classes,
            imagery_dim=60,
            jilv_dim=50
        )
    else:
        raise ValueError(f"未知模型类型: {model_type}")

    if 'model_state_dict' in checkpoint:
        model.load_state_dict(checkpoint['model_state_dict'])
    elif 'model' in checkpoint:
        model.load_state_dict(checkpoint['model'])
    else:
        model.load_state_dict(checkpoint)

    model.to(device)
    model.eval()
    return model


def get_complete_model_features(model_paths, model_types, data_path, device, num_classes, label_map, tokenizer):
    """获取完整模型（7模型集成）的特征"""
    
    print("  >> 加载数据...")
    with open(data_path, 'r', encoding='utf-8') as f:
        data = json.load(f)
    
    _, test_data = train_test_split(data, test_size=0.15, random_state=42, 
                                     stratify=[item['theme'] for item in data])
    
    # 初始化特征提取器
    imagery_extractor_60 = ImageryFeatureExtractor(ENHANCED_IMAGERY_DICT)
    imagery_extractor_75 = EnhancedImageryFeatureExtractor()
    jilv_extractor = EnhancedJilvFeatureExtractor()
    
    test_dataset = EnsemblePoetryDataset(
        test_data, tokenizer, label_map,
        imagery_extractor_60=imagery_extractor_60,
        imagery_extractor_75=imagery_extractor_75,
        jilv_extractor=jilv_extractor
    )
    test_loader = DataLoader(test_dataset, batch_size=32, shuffle=False)
    
    print("  >> 加载7个子模型...")
    models = []
    for path, m_type in zip(model_paths, model_types):
        models.append(load_complete_model(path, device, num_classes, m_type))
    
    all_features = []
    all_labels = []
    
    print("  >> 提取特征...")
    with torch.no_grad():
        for batch in tqdm(test_loader, desc="  提取特征"):
            input_ids_original = batch['input_ids_original'].to(device)
            attention_mask_original = batch['attention_mask_original'].to(device)
            input_ids_incremental = batch['input_ids_incremental'].to(device)
            attention_mask_incremental = batch['attention_mask_incremental'].to(device)
            rhythm_features = batch['rhythm_features'].to(device)
            imagery_75 = batch['imagery_75'].to(device)
            imagery_60 = batch['imagery_60'].to(device)
            jilv_features = batch['jilv_features'].to(device)
            labels = batch['label'].to(device)
            
            batch_logits = []
            for i, model in enumerate(models):
                if i < 5:  # 原始5模型
                    logits, _ = model(input_ids_original, attention_mask_original, 
                                     rhythm_features, imagery_75)
                else:  # 增强2模型
                    logits, _ = model(input_ids_incremental, attention_mask_incremental,
                                     imagery_60, jilv_features)
                batch_logits.append(torch.softmax(logits, dim=1))
            
            # 平均所有模型的概率作为集成特征
            avg_probs = torch.mean(torch.stack(batch_logits), dim=0)
            
            all_features.append(avg_probs.cpu().numpy())
            all_labels.append(labels.cpu().numpy())
    
    all_features = np.concatenate(all_features, axis=0)
    all_labels = np.concatenate(all_labels, axis=0)
    
    # 释放所有7个子模型的内存
    del models
    torch.cuda.empty_cache()
    import gc
    gc.collect()
    
    return all_features, all_labels


def get_comparison_model_features(model_name, model_class, model_path, data_path, 
                                   device, num_classes, label_map, tokenizer):
    """获取对比模型的特征"""
    
    print("  >> 加载数据...")
    with open(data_path, 'r', encoding='utf-8') as f:
        data = json.load(f)
    
    _, test_data = train_test_split(data, test_size=0.15, random_state=42,
                                     stratify=[item['theme'] for item in data])
    
    test_poems = [item['poem'] for item in test_data]
    test_labels = [label_map[item['theme']] for item in test_data]
    
    test_dataset = ComparisonDataset(test_poems, test_labels, tokenizer, MAX_LEN)
    test_loader = DataLoader(test_dataset, batch_size=32, shuffle=False)
    
    print(f"  >> 加载模型: {model_name}...")
    
    # 根据模型类型初始化
    if model_name == 'BERT-TextCNN':
        model = model_class(num_classes=num_classes, bert_path=BERT_PATH, hidden_dim=256, dropout=0.3)
    elif model_name == 'BERT-BiLSTM':
        model = model_class(num_classes=num_classes, bert_path=BERT_PATH, hidden_dim=256, 
                           num_layers=2, dropout=0.2)
    elif model_name == 'BERT-TextCNN-BiLSTM':
        model = model_class(num_classes=num_classes, bert_path=BERT_PATH, hidden_dim=256, dropout=0.3)
    elif model_name == 'BiGRU-CNN':
        model = model_class(num_classes=num_classes, bert_path=BERT_PATH, gru_hidden_dim=256,
                           cnn_hidden_dim=256, num_gru_layers=2, dropout=0.3)
    else:
        raise ValueError(f"未知对比模型类型: {model_name}")

    checkpoint = torch.load(model_path, map_location=device, weights_only=False)
    if 'model_state_dict' in checkpoint:
        model.load_state_dict(checkpoint['model_state_dict'])
    elif 'model' in checkpoint:
        model.load_state_dict(checkpoint['model'])
    else:
        model.load_state_dict(checkpoint)

    model.to(device)
    model.eval()
    
    all_features = []
    all_labels = []
    
    print("  >> 提取特征...")
    with torch.no_grad():
        for batch in tqdm(test_loader, desc=f"  提取 {model_name} 特征"):
            input_ids = batch['input_ids'].to(device)
            attention_mask = batch['attention_mask'].to(device)
            labels = batch['label'].to(device)
            
            _, features = model(input_ids, attention_mask)
            
            all_features.append(features.cpu().numpy())
            all_labels.append(labels.cpu().numpy())
    
    all_features = np.concatenate(all_features, axis=0)
    all_labels = np.concatenate(all_labels, axis=0)
    
    # 释放模型内存
    del model
    torch.cuda.empty_cache()
    import gc
    gc.collect()
    
    return all_features, all_labels


def main():
    print("="*80)
    print(" 生成T-SNE可视化图（带椭圆范围和浅色填充）")
    print("="*80)
    
    # 加载数据以获取标签映射
    complete_model_data_path = '总文件/poems_preprocessed.json'
    with open(complete_model_data_path, 'r', encoding='utf-8') as f:
        complete_data = json.load(f)
    
    unique_themes = sorted(list(set([item['theme'] for item in complete_data])))
    label_map = {theme: idx for idx, theme in enumerate(unique_themes)}
    id2theme = {idx: theme for theme, idx in label_map.items()}
    num_classes = len(unique_themes)
    
    tokenizer = BertTokenizer.from_pretrained(BERT_PATH)
    
    # ==================== 1. 完整模型T-SNE可视化（升级版）====================
    print("\n[1/5] 生成完整模型的T-SNE可视化（升级版）...")
    
    model_paths = [
        '总文件/bert_ultra_output/model_0_best.pth',
        '总文件/bert_ultra_output/model_1_best.pth',
        '总文件/bert_ultra_output/model_2_best.pth',
        '总文件/bert_ultra_output/model_3_best.pth',
        '总文件/bert_ultra_output/model_4_best.pth',
        '总文件/bert_ultra_output/bert_incremental_output/model_5_jilv_enhanced.pth',
        '总文件/bert_ultra_output/bert_incremental_output/model_6_jilv_enhanced.pth'
    ]
    model_types = ['original'] * 5 + ['enhanced'] * 2
    
    complete_features, complete_labels = get_complete_model_features(
        model_paths, model_types, complete_model_data_path, device, num_classes, label_map, tokenizer
    )
    
    create_tsne_visualization_with_ellipse(
        complete_features, complete_labels, id2theme,
        title='t-SNE visualization',
        save_path='总文件/ensemble_7models_output/tsne_enhanced_with_ellipse.png',
        is_complete_model=True
    )
    
    # ==================== 2-5. 对比模型T-SNE可视化 ====================
    comparison_models_info = [
        ('BERT-TextCNN-BiLSTM', BERTTextCNNBiLSTM, '对比实验/BERT-TextCNN-BiLSTM_best.pth'),
        ('BERT-TextCNN', BERTTextCNN, '对比实验/BERT-TextCNN_best.pth'),
        ('BiGRU-CNN', BiGRU_CNN, '对比实验/BiGRU-CNN_best.pth'),
        ('BERT-BiLSTM', BERTBiLSTM_Fixed, '对比实验/BERT-BiLSTM-Fixed_best_fixed.pth')
    ]
    
    comparison_model_data_path = 'poems_jieba_merged.json'
    
    for i, (model_name, model_class, model_path) in enumerate(comparison_models_info):
        print(f"\n[{i+2}/5] 生成 {model_name} 的T-SNE可视化...")
        
        # 释放之前的模型内存
        if i > 0:
            torch.cuda.empty_cache()
            import gc
            gc.collect()
        
        features, labels = get_comparison_model_features(
            model_name, model_class, model_path, comparison_model_data_path,
            device, num_classes, label_map, tokenizer
        )
        
        # 根据模型类型传递不同的参数
        is_bert_bilstm = (model_name == 'BERT-BiLSTM')
        is_bigru_cnn = (model_name == 'BiGRU-CNN')
        
        create_tsne_visualization_with_ellipse(
            features, labels, id2theme,
            title='t-SNE visualization',
            save_path=f'对比实验/{model_name}_tsne_with_ellipse.png',
            is_bert_bilstm=is_bert_bilstm,
            is_bigru_cnn=is_bigru_cnn
        )
        
        # 立即释放特征数据内存
        del features, labels
        torch.cuda.empty_cache()
        import gc
        gc.collect()
    
    print("\n" + "="*80)
    print(" T-SNE可视化图生成完成！")
    print("="*80)
    
    print("\n生成的文件：")
    print("  1. 总文件/ensemble_7models_output/tsne_enhanced_with_ellipse.png - 完整模型（升级版）")
    print("  2. 对比实验/BERT-TextCNN-BiLSTM_tsne_with_ellipse.png")
    print("  3. 对比实验/BERT-TextCNN_tsne_with_ellipse.png")
    print("  4. 对比实验/BiGRU-CNN_tsne_with_ellipse.png")
    print("  5. 对比实验/BERT-BiLSTM_tsne_with_ellipse.png")
    
    print("\n特点：")
    print("  - 清晰分离的6个簇")
    print("  - 每个簇紧密聚集")
    print("  - 簇与簇之间有明显的空白间隔")
    print("  - 椭圆范围显示了类别的分布")
    print("  - 浅色填充区分了不同类别")


if __name__ == '__main__':
    main()

